<?php
// Require the congiguration/database connect script. This must be called before headers are sent!
require_once('inc/config.inc.php');

$pageTitle = 'Category';
require_once('inc/head_elements.inc.php');
?>
<body> 
<div id="mainshell"> 
	<?php require_once('inc/contents/banner_content.inc.php'); ?> 
	<div id="main">
		<?php require_once('inc/contents/login_content.inc.php'); ?> 
		<div class="content"> 
			<?php require_once('inc/contents/category_content.inc.php'); ?> 
		</div> 
		<!-- close content --> 
	</div>
	<!-- close main --> 
	<?php require_once('inc/contents/footer_content.inc.php'); ?> 
</div> 
<!-- close mainshell --> 
</body>
</html>
