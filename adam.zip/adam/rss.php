<?php
// Require the congiguration/database connect script. This must be called before headers are sent!
require_once('inc/config.inc.php');

// DEBUGGING_MODE must be set to FALSE in order to obtain RSS data.
if (DEBUGGING_MODE) {
	echo 'Cannot access RSS. Please try again later.';
	exit();
}

// Send a header indicating to the browser that the content is XML.
header('Content-Type: text/xml; charset=iso-8859-1');

// Set the types of requests to prevent hacking.
if (isset($_REQUEST['q'])) {
	settype($_REQUEST['q'], 'string');
} elseif (isset($_REQUEST['ot'])) {
	settype($_REQUEST['ot'], 'integer');
}

// If a query string exists, search for the 10 most recently entered objects in the search results.
if (isset($_REQUEST['q'])) {
	$sql = 'SELECT * 
	FROM objects, objectTypes 
	WHERE MATCH(
	objects.objectTitle, 
	objects.objectCreator, 
	objects.objectSubject, 
	objects.objectDescription, 
	objects.objectData, 
	objects.objectDate
	) AGAINST(
	"'.addslashes($_REQUEST['q']).'" IN BOOLEAN MODE
	) 
	AND objects.objectTypeID = objectTypes.objectTypeID 
	AND objectTypes.objectTypeActive = 1 
	AND objects.objectActive = 1 
	AND objects.objectPermissionID >= 3 
	ORDER BY objects.objectAdded DESC 
	LIMIT 10';
	
// If an object type ID exists, search for the 10 most recently entered objects belonging to the object type.
} elseif (isset($_REQUEST['ot'])) {
	$sql = 'SELECT * 
	FROM objects, objectTypes 
	WHERE objects.objectTypeID = objectTypes.objectTypeID 
	AND objectTypes.objectTypeActive = 1 
	AND objects.objectActive = 1 
	AND objects.objectPermissionID >= 3 
	AND objectTypes.objectTypeID = '.$_REQUEST['ot'].'
	ORDER BY objects.objectAdded DESC 
	LIMIT 10';
	
// By default get the 10 most recently entered objects.
} else {
	$sql = 'SELECT * 
	FROM objects, objectTypes 
	WHERE objects.objectTypeID = objectTypes.objectTypeID 
	AND objectTypes.objectTypeActive = 1 
	AND objects.objectActive = 1 
	AND objects.objectPermissionID >= 3 
	ORDER BY objects.objectAdded DESC 
	LIMIT 10';
}
$result = $db->dbQuery($sql);

// Build the XML string.
$str .= '<?xml version="1.0" encoding="iso-8859-1"?>
	<rss version="2.0">
		<channel>
			<title>Adaptable Digital Archive Manager</title>
			<link>http://echo.gmu.edu/adam/</link>
			<description>Providing an adaptable digital framework within which you can manage your project\'s assets.</description>';
while ($row = mysql_fetch_assoc($result)) {
	$str .= '
			<item>';
	if ($row['objectTitle']) {
		$str .= '
				<title>'.$row['objectTitle'].'</title>';
	} else {
		$str .= '
				<title>[no title]</title>';
	}
	$str .= '
				<link>http://echo.gmu.edu/adam/object.php?id='.$row['objectID'].'</link>';
	if ($row['objectDescription']) {
		$str .= '
				<description>'.$row['objectDescription'].'</description>';
	} else {
		$str .= '
				<description>[no description]</description>';
	}
	$str .= '
			</item>';
}
$str .= '
		</channel>
	</rss>';

echo $str;
?>