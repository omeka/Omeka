<?php
// Display the object type selection form.
// PROTECTED ACCESS
if (USER_ACCESS_LEVEL <= 20) {
	
	$objectType = new ObjectType;
	$object = new Object;
	
	if ($_POST['submitObject']) {
		$object->ingestObject();
		echo $object->alert;
	}

	echo '<div class="readable">';

	echo '
	<form action="'.$_SERVER['PHP_SELF'].'" method="post" enctype="multipart/form-data">
	<input type="hidden" name="MAX_FILE_SIZE" value="10485760" />';
	// Handle the select object type form.
	if (isset($_POST['submitObjectType'])) {
		if (!$objectType->validateObjectTypeSelectionForm($_POST['objectTypeID'])) {
			echo $objectType->objectTypeSelectionForm;
		} else {
			echo $objectType->getObjectTypeForm($_POST['objectTypeID']);
		}
	// Display the select object type form elements.
	} else {
		echo $objectType->objectTypeSelectionForm;
	}
	echo '</form>';
	
	echo '</div><!-- End readable div -->';
}


?>