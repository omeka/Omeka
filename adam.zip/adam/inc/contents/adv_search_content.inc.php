<?php
$search = new Search;

echo ' 
<div class="searchblock"> 
	<form action="adv_search_results.php" method="post" id="keywordsearch"> 
		<h3>Advanced Search:</h3> 
		<div class="searchrow">
			<strong><label for="search" title="keyword search cipp site">Keywords</label></strong> 
			<input type="text" name="advSearchString" id="search" size="30" maxlength="255" value="" /> 
		</div> 
		<div class="searchrow"> 
			<strong><label for="categories" title="search categories">Select Categories:</label></strong> 
			<select name="advSearchCategoryIDs[]" size="16" multiple="multiple" id="categories" title="category search cipp site">';
				$result = $search->getAllCategories();
				while ($row = mysql_fetch_assoc($result)) {
					echo '<option value="'.$row['objectCategoryID'].'">'.$row['objectCategoryName'].'</option>';
				}
			echo '
			</select> 
		</div>
		<div class="searchrow">
			<strong><label for="objecttype" title="object type">Select Object Type:</label></strong> 
			<select name="advSearchObjectTypeIDs[]" size="8" multiple="multiple" id="objecttype" title="object stype search">';
				$result = $search->getAllObjectTypes();
				while ($row = mysql_fetch_assoc($result)) {
					echo '<option value="'.$row['objectTypeID'].'">'.$row['objectTypeName'].'</option>';
				}
			echo '
			</select> 
		</div> 
		<div class="searchrow">
			<strong><label for="filetype" title="file type">Select File Type:</label> </strong> 
			<select name="advSearchFileTypes[]" size="8" multiple="multiple" id="filetype" title="file type search">';
				$result = $search->getAllFileTypes();
				while ($row = mysql_fetch_assoc($result)) {
					echo '<option value="'.$row['objectFileType'].'">'.$row['objectFileType'].'</option>';
				}
			echo '
			</select> 
		</div>';
			if (USER_ACCESS_LEVEL <= 10) {
				echo '
				<div class="searchrow">
					<strong><label for="user" title="user">Select User:</label> </strong> 
					<select name="advSearchUserIDs[]" size="8" multiple="multiple" id="user" title="user search">';
						$result = $search->getAllUsers();
						while ($row = mysql_fetch_assoc($result)) {
							echo '<option value="'.$row['userID'].'">'.$row['userUsername'].'</option>';
						}
					echo '
					</select> 
				</div>';
			}
			echo '
		<div class="searchrow"> 
			<input type="submit" name="submitAdvSearch" value="search objects" class="btn" /> 
		</div> 
	</form> 
</div> 
<!-- end object search -->';
?>
