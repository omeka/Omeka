<?php
$object = new Object;
$user = new User;

echo '<div class="readable">';

if (USER_ACCESS_LEVEL <= 10) {
	if ($_GET['deactivateObject']) {
		settype($_GET['deactivateObject'], 'integer');
		$object->deactivateObject($_GET['deactivateObject']);
		echo $object->alert;
	} elseif ($_GET['activateObject']) {
		$object->activateObject($_GET['activateObject']);
		echo $object->alert;
	} elseif ($_POST['submitObjectEdit']) {
		$object->editObject();
		echo $object->alert;
	} elseif ($_POST['submitAddObjectNote']) {
		$object->addObjectNote($_GET['id']);
		echo $object->alert;
	} elseif ($_GET['deactivateFile']) {
		settype($_GET['deactivateFile'], 'integer');
		$object->deactivateFile($_GET['deactivateFile']);
		echo $object->alert;
	} elseif ($_GET['activateFile']) {
		settype($_GET['activateFile'], 'integer');
		$object->activateFile($_GET['activateFile']);
		echo $object->alert;
	} elseif ($_GET['deleteObject']) {
		settype($_GET['deleteObject'], 'integer');
		$object->deleteObject($_GET['deleteObject']);
		echo $object->alert;
	} elseif ($_GET['deleteFile']) {
		settype($_GET['deleteFile'], 'integer');
		$object->deleteFile($_GET['deleteFile']);
		echo $object->alert;
	} elseif (isset($_GET['removeAssociations'])) {
		settype($_GET['id'], 'integer');
		$object->removeAssociations($_GET['id']);
		echo $object->alert;
	} elseif ($_POST['submitAssignDropboxFile']) {
		$object->assignDropboxFile($_GET['id']);
		echo $object->alert;
	}
}

if ($object->getObject($_GET['id'])) {
	
	$objectID 					= $object->objectID;
	$objectTypeID 				= $object->objectTypeID;
	$objectPermissionID 		= $object->objectPermissionID;
	$objectUserID 				= $object->objectUserID;
	$objectTitle 				= $object->objectTitle;
	$objectCreator 				= $object->objectCreator;
	$objectSubject 				= $object->objectSubject;
	$objectDescription 			= $object->objectDescription;
	$objectDate 				= $object->objectDate;
	$objectData 				= $object->objectData;
	$objectModified 			= $object->objectModified;
	$objectAdded 				= $object->objectAdded;
	$objectActive 				= $object->objectActive;
	$objectType 				= $object->objectType;
	$objectTypeMetadataDump 	= $object->objectTypeMetadataDump;
	$objectPermission 			= $object->objectPermission;
	$objectUser 				= $object->objectUser;
	$objectMetadata 			= $object->objectMetadata;
	$objectDataTypeMetadata 	= $object->objectDataTypeMetadata;
	$objectFiles 				= $object->objectFiles;
	$objectCategories 			= $object->objectCategories;
	$objectNotes				= $object->objectNotes;
	
	echo '<p>';
	if (USER_ACCESS_LEVEL <= 10) {
		if (isset($_GET['editObject'])) {
			echo '[<a href="'.$_SERVER['PHP_SELF'].'?id='.$objectID.'">return to simple object view</a>]';		
		} else {
			echo '[<a href="'.$_SERVER['PHP_SELF'].'?id='.$objectID.'&editObject">edit this object</a>]';
		}
	}
	echo '</p>';
	
	echo '<div class="rule"><br /></div>';

	if (USER_ACCESS_LEVEL <= 10) {
		if (isset($_GET['editObject'])) {
			echo '
<h3>Edit Object</h3>
<form action="'.$_SERVER['PHP_SELF'].'?id='.$objectID.'" method="post" enctype="multipart/form-data">
<input type="hidden" name="MAX_FILE_SIZE" value="10485760" />
<div class="formElement">
	<div class="inputLabel">Permission Level:</div>
	<select name="objectPermissionID">';
			$result = getPermissions();
			while ($row = mysql_fetch_assoc($result)) {
				if ($row['permissionID'] >= $_SESSION[DB_NAME.'_userID']) {
					echo '<option value="'.$row['permissionID'].'"'; if ($row['permissionID'] == $objectPermission[0]) {echo ' selected';} echo '>'.$row['permissionName'].'</option>';
				}
			}
			echo '
	</select>
</div>';
			echo '
<div class="formElement">
	<input type="submit" name="submitObjectEdit" value="submit changes to this object" class="genSubmit" /> <input type="submit" name="cancel" value="cancel this edit" class="genSubmit" />
</div>';
			echo '
<div class="formElement">
	<div class="inputLabel">Title:</div>
	<div class="instructionText">'.$objectType[5].'</div>
	<textarea name="objectTitle" rows="1" cols="60">'.$objectTitle.'</textarea>
</div>';
			echo '
<div class="formElement">
	<div class="inputLabel">Description:</div>
	<div class="instructionText">'.$objectType[6].'</div>
	<textarea name="objectDescription" rows="8" cols="60">'.$objectDescription.'</textarea>
</div>';
			echo '
<div class="formElement">
	<div class="inputLabel">Creator/Author:</div>
	<div class="instructionText">'.$objectType[7].'</div>
	<textarea name="objectCreator" rows="1" cols="60">'.$objectCreator.'</textarea>
</div>';
			echo '
<div class="formElement">
	<div class="inputLabel">Subject and Keywords:</div>
	<div class="instructionText">'.$objectType[8].'</div>
	<textarea name="objectSubject" rows="1" cols="60">'.$objectSubject.'</textarea>
</div>';
			echo '
<div class="formElement">
	<div class="inputLabel">Date:</div>
	<div class="instructionText">'.$objectType[9].'</div>
	<textarea name="objectDate" rows="1" cols="60">'.$objectDate.'</textarea>
</div>';
			// Iteration starts at -3 for two reasons:
			// 1) Must iterate object metadata 3 times to reach $objectMetadata[2]; and 
			// 2) Must begin retrieving metadata dump at objectTypeMetadataDump[0]
			$i = -3;
			foreach ($objectMetadata as $key => $value) {
				if ($i >= 0) {
					// Follow this rule: objectTypeFieldName = [$i][0]; objectTypeFieldNameDescription = [$i][1]
					echo '
<div class="formElement">
	<div class="inputLabel">'.$objectTypeMetadataDump[$i][0].':</div>';
					if ($objectTypeMetadataDump[$i][1]) {
						echo '
	<div class="instructionText">'.$objectTypeMetadataDump[$i][1].'</div>';
					}
					switch ($objectTypeMetadataDump[$i][2]) {
						case 'textInput':
							echo '<input name="'.$objectDataTypeMetadata[$i + 3]['Field'].'" value="'.prepStr($value, 6).'" size="60" />';
							break;
						case 'textArea':
							echo '<textarea name="'.$objectDataTypeMetadata[$i + 3]['Field'].'" rows="8" cols="60">'.$value.'</textarea>';
							break;
					}
					echo '
</div>';
				}
				$i++;
			}
			echo '
<div class="formElement">
	<div class="inputLabel">Object Raw Data:</div>
	<textarea name="objectData" rows="8" cols="60">'.$objectData.'</textarea>
</div>';
			if (count($objectFiles)) {
				foreach ($objectFiles as $value) {
					echo '
<div class="formElement">
	<div class="inputLabel">File Description for "'.$value[8].'":</div>
	<textarea name="objectFileDescriptionEdit['.$value[0].']" rows="4" cols="60">'.$value[2].'</textarea>
</div>';
				}
			}
			for ($i = 1; $i <= MAX_FILE_UPLOAD; $i++) {
				echo '
<div class="formElement">
	<div class="inputLabel">Upload File:</div> 
	<input type="file" name="'.$i.'" size="60" />
</div>
<div class="formElement">
	<div class="inputLabel">Describe File:</div> 
	<textarea name="objectFileDescription['.$i.']" rows="4" cols="60"></textarea>
</div>';
			}
			echo '
<div class="formElement">
	<input type="submit" name="submitObjectEdit" value="submit changes to this object" class="genSubmit" /> <input type="submit" name="cancel" value="cancel this edit" class="genSubmit" />
	<input type="hidden" name="objectID" value="'.$objectID.'" />
	<input type="hidden" name="objectTypeID" value="'.$objectTypeID.'" />
</div>
</form>';
			echo '<div class="rule"><br /></div>';
		}
	}
	
	echo '<h3>Object Metadata</h3>';
	
	if (USER_ACCESS_LEVEL <= 10) {
		if ($objectActive) {
			echo '<p><span class="alert">This object is active.</span> To deactivate this object, click <strong><a href="'.$_SERVER['PHP_SELF'].'?id='.$objectID.'&deactivateObject='.$objectID.'" class="error">DEACTIVATE</a></strong>.</p>';
		} else {
			echo '<p><span class="error">This object is inactive.</span> To activate this object, click <strong><a href="'.$_SERVER['PHP_SELF'].'?id='.$objectID.'&activateObject='.$objectID.'" class="alert">ACTIVATE</a></strong>.</p>';
		}
	}
	if (USER_ACCESS_LEVEL <= 20) {
		echo '
		<p><strong>Permission Level:</strong><br />
		'.$objectPermission[1].'</p>';
	}
		
	echo '
	<p><strong>Title:</strong><br />
	'.$objectTitle.'</p>';
	
	echo '
	<p><strong>Description:</strong><br />
	'.nl2br($objectDescription).'</p>';
	
	echo '
	<p><strong>Creator/Author:</strong><br />
	'.$objectCreator.'</p>';
	
	echo '
	<p><strong>Subject:</strong><br />
	'.$objectSubject.'</p>';
	
	echo '
	<p><strong>Date:</strong><br />
	'.$objectDate.'</p>';

	// Iteration starts at -3 for two reasons:
	// 1) Must iterate object metadata 3 times to reach $objectMetadata[2]; and 
	// 2) Must begin retrieving metadata dump at objectTypeMetadataDump[0]
	$i = -3;
	foreach ($objectMetadata as $key => $value) {
		if ($i >= 0) {
			// Follow this rule: objectTypeFieldName = [$i][0]; objectTypeFieldNameDescription = [$i][1]
			echo '
			<p><strong>'.$objectTypeMetadataDump[$i][0].':</strong><br />
			'.$value.'</p>';
		}
		$i++;
	}
	
	if (USER_ACCESS_LEVEL <= 10) {
		echo '
		<p><strong>Object Raw Data:</strong><br />
		'.nl2br(truncateString($objectData, 300)).'</p>';
		echo '
		<p><strong>Object Modified:</strong><br />
		'.$objectModified.'</p>';
		
	}
	if (USER_ACCESS_LEVEL <= 20) {
		echo '
		<p><strong>Object Added:</strong><br />
		'.$objectAdded.'</p>';
	}
	
	echo '<div class="rule"><br /></div>';
	echo '<h3>Files Assigned</h3>';
	
	if (count($objectFiles)) {
		echo '<ol>';
		foreach ($objectFiles as $value) {
			echo '
			<li><strong>'.$value[8].'</strong> ('.$value[3].', ';
			// Convert bytes into MB, kB, or B.
			echo humanReadableSize($value[4]);
			echo ')<br />[<a href="'.FILES_URL.$value[1].'" target="_blank">download file</a>]';
			if (USER_ACCESS_LEVEL <= 1) {
				echo ' [<a href="'.$_SERVER['PHP_SELF'].'?id='.$objectID.'&deleteFile='.$value[0].'" onclick="return confirm(\'WARNING! Are you sure you want to delete this file: '.$value[8].'? The file and the file metadata will be unrecoverable. \')">delete file</a>]';
			}
			if (USER_ACCESS_LEVEL <= 10) {
				if ($value[7]) {
					echo ' [<a href="'.$_SERVER['PHP_SELF'].'?id='.$objectID.'&deactivateFile='.$value[0].'" class="error">deactivate file</a>]';
				} else {
					echo ' [<a href="'.$_SERVER['PHP_SELF'].'?id='.$objectID.'&activateFile='.$value[0].'" class="alert">activate file</a>]';
				}
			}
			echo '<br />
			'.$value[2].'</li>';
		}
		echo '</ol>';
	} else {
		echo '<p>[This object has no assigned files.]</p>';
	}
	if (USER_ACCESS_LEVEL <= 10) {
		$dropboxFileArray = $object->getDropboxFiles();
		if (count($dropboxFileArray)) {
			echo '
			<form action="'.$_SERVER['PHP_SELF'].'?id='.$objectID.'" method="post">
			<p>Assign a large file from the file dropbox.</p>
			<div class="formElement">
				<select name="dropboxFileName">';
				foreach ($dropboxFileArray as $value) {
					echo '<option value="'.prepStr($value, 6).'">'.prepStr($value, 6).'</option>';
				}
			echo '
				</select>
				<input type="submit" name="submitAssignDropboxFile" value="assign this file to this object" class="genSubmit" />
			</div>
			</form>';
		} else {
			echo '<p>[There are no files in the file dropbox.]</p>';
		}
	}	
	echo '<div class="rule"><br /></div>';
	echo '<h3>Categories Assigned</h3>';
	
	if (count($objectCategories)) {
		echo '<ol>';
		foreach ($objectCategories as $value) {
			echo '<li><a href="category.php?id='.$value[0].'" class="category">'.$value[1].'</a><br /></li>';
		}
		echo '</ol>';
	} else {
		echo '<p>[This object is unassigned/orphaned (not assigned to any category).]</p>';
	}
	
	echo '<div class="rule"><br /></div>';
	echo '<h3>Object Type Metadata</h3>';
	
	echo '
	<p><strong>'.$objectType[0].'</strong><br />
	[<a href="object_type.php?id='.$objectTypeID.'">view object type</a>]<br />
	'.nl2br($objectType[3]).'</p>';
	
	if (USER_ACCESS_LEVEL <= 10) {
		echo '<div class="rule"><br /></div>';
		echo '<h3>User Metadata</h3>';
		echo '
		<p><strong>Username:</strong><br />
		'.$objectUser[0].'</p>';
		echo '
		<p><strong>Name:</strong><br />
		'.$objectUser[2].', '.$objectUser[1].'</p>';
		echo '
		<p><strong>Email:</strong><br />
		'.$objectUser[3].'</p>';
		echo '
		<p><strong>Institution:</strong><br />
		'.$objectUser[5].'</p>';
	}	
		
	if (USER_ACCESS_LEVEL <= 20) {
		echo '<div class="rule"><br /></div>';
		echo '<h3>Object Notes</h3>';
		if (count($objectNotes)) {
			echo '<ol>';
			foreach ($objectNotes as $value) {
				$user->getUser($value[2]);
				echo '<li><strong>Note entered by '.$user->userArray['userUsername'].' on '.$value[6].'</strong><br />
				'.$value[4].'</li>';
			}
			echo '</ol>';
		}
		echo '
<form action="'.$_SERVER['PHP_SELF'].'?id='.$objectID.'" method="post">
<div class="formElement">
	<div class="inputLabel">Note:</div>
	<div class="instructionText">You may record any notes or comments about this object.</div>
	<textarea name="objectNoteText" rows="8" cols="60"></textarea>
</div>
<div class="formElement">
	<div class="inputLabel">Permission Level:</div>
	<div class="instructionText">This note will be available to users of the selected permission level and all higher permission levels.</div>
	<select name="objectNotePermissionID">';
	$result = getPermissions();
	while ($row = mysql_fetch_assoc($result)) {
		if ($row['permissionID'] >= $_SESSION[DB_NAME.'_userPermissionID']) {
			echo '<option value="'.$row['permissionID'].'">'.$row['permissionName'].'</option>';
		}
	}
	echo '</select>
</div>
<div class="formElement">
	<input type="submit" name="submitAddObjectNote" value="submit note" class="genSubmit" />
</div>
</form>';
	}
	
	if (USER_ACCESS_LEVEL <= 10) {
		echo '<div class="rule"><br /></div>';
		echo '<h3>Object State Changes</h3>';
		echo '<p>To permanently remove this object\'s category associations, click <strong><a href="'.$_SERVER['PHP_SELF'].'?id='.$objectID.'&removeAssociations" onclick="return confirm(\'WARNING! Are you sure you want to permanently remove all object/category associations? \')" class="error">REMOVE ASSOCIATIONS</a></strong></p>';
		if (USER_ACCESS_LEVEL <= 1) {
			echo '<p>To permanently remove this object, click <strong><a href="'.$_SERVER['PHP_SELF'].'?deleteObject='.$objectID.'" onclick="return confirm(\'WARNING! Are you sure you want to permanently delete this object? The metadata of the object will be unrecoverable. \')" class="error">DELETE OBJECT</a></strong>.</p>';
		}
	}

} elseif ($_GET['deleteObject']) {
	echo '<p>[<a href="archive.php">return to the archive</a>]</p>';	
} else {
	echo $object->alert;
}

echo '</div><!-- End readable div -->';
?>