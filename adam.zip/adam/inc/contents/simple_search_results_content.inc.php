<?php
$search = new Search;
$object = new Object;
$category = new Category;
$objectType = new ObjectType;

settype($_GET['page'], 'integer');
if (!$_GET['page']) {
	$_GET['page'] = 1;
}

echo '<h3>Simple Search Results</h3>';

// Display the simple search results if the simple search form was submitted or if the simpleSearchString session exists.
if ($_POST['submitSimpleSearch'] || $_SESSION['simpleSearchString']) {
	// Set the simpleSearchString session if the simple search form was submitted.
	if ($_POST['submitSimpleSearch']) {
		$_SESSION['simpleSearchString'] = trim($_POST['simpleSearchString']);
	}
	echo '<p>You are searching for "'.stripslashes($_SESSION['simpleSearchString']).'"<br />';
	// Display the limited results.
	if ($search->simpleSearch($_SESSION['simpleSearchString'], $_GET['page'])) {
		$totalResults = $search->totalResults;
		$simpleSearchResults = $search->simpleSearchResults;
		echo 'There are <strong>'.$totalResults.'</strong> total results:</p>';
		echo '<div style="text-align: center;">'.pagination($_GET['page'], $totalResults, MAX_UNITS_PER_PAGE, 3, '<a href="'.$_SERVER['PHP_SELF'].'?page=').'</div>';
		echo '<ol start="'.((($_GET['page'] - 1) * MAX_UNITS_PER_PAGE) + 1).'">';
		foreach ($simpleSearchResults as $value) {
			$result = $objectType->getObjectTypes($value['objectTypeID']);
			$row = mysql_fetch_assoc($result);
			$haystack = $value['objectDescription'];
			$needle = $_SESSION['simpleSearchString'];
			echo '<li><a href="object.php?id='.$value['objectID'].'" class="title">';
			if ($value['objectTitle']) {
				echo highlightStr($value['objectTitle'], $needle);
			} else {
				echo '[no title]';
			}
			echo '</a> ('.strtoupper($row['objectTypeName']).')<br />';
			echo highlightStr($haystack, $needle, 90);			
			
			echo '</li>';
		}
		echo '</ol>';
	} else {
		echo $search->alert;
	}
}
?>