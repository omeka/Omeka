<?php
$search = new Search;
$object = new Object;
$category = new Category;
$objectType = new ObjectType;

settype($_GET['page'], 'integer');
if (!$_GET['page']) {
	$_GET['page'] = 1;
}

echo '<h3>Advanced Search Results</h3>';

if (
	$_POST['submitAdvSearch'] 
	|| $_SESSION['advSearchString'] 
	|| $_SESSION['advSearchCategoryIDs'] 
	|| $_SESSION['advSearchObjectTypeIDs'] 
	|| $_SESSION['advSearchFileTypes'] 
	|| $_SESSION['advSearchUserIDs']
	) {
	// Set the advanced search sessions if the advanced search form was submitted.
	if ($_POST['submitAdvSearch']) {
		$_SESSION['advSearchString']		= trim($_POST['advSearchString']);
		$_SESSION['advSearchCategoryIDs']	= $_POST['advSearchCategoryIDs'];
		$_SESSION['advSearchObjectTypeIDs']	= $_POST['advSearchObjectTypeIDs'];
		$_SESSION['advSearchFileTypes']		= $_POST['advSearchFileTypes'];
		$_SESSION['advSearchUserIDs']		= $_POST['advSearchUserIDs'];
	}
		// Display the search parameters.
		echo '
		<p>You are searching for: ';
		if ($_SESSION['advSearchString']) {
			echo '<br />
			<strong>Text:</strong> "'.stripslashes($_SESSION['advSearchString']).'"';
		}
		if (is_array($_SESSION['advSearchCategoryIDs'])) {
			echo '<br />
			<strong>Categories:</strong> ';
			foreach ($_SESSION['advSearchCategoryIDs'] as $categoryID) {
				if ($category->getCategory($categoryID, 1)) {
					$categoryStr .= '"'.$category->objectCategoryName.'" <em>or</em> ';
				}
			}
			echo substr($categoryStr, 0, -13);
		}
		if (is_array($_SESSION['advSearchObjectTypeIDs'])) {
			echo '<br />
			<strong>Object Types:</strong> ';
			foreach ($_SESSION['advSearchObjectTypeIDs'] as $objectTypeID) {
				if ($result = $objectType->getObjectTypes($objectTypeID)) {
					$row = mysql_fetch_assoc($result);
					$objectTypeStr .= '"'.$row['objectTypeName'].'" <em>or</em> ';
				}
			}
			echo substr($objectTypeStr, 0, -13);
		}
		if (is_array($_SESSION['advSearchFileTypes'])) {
			echo '<br />
			<strong>File Types:</strong> ';
			foreach ($_SESSION['advSearchFileTypes'] as $fileType) {
				$fileTypeStr .= '"'.$fileType.'" <em>or</em> ';
			}
			echo substr($fileTypeStr, 0, -13);
		}
		if (is_array($_SESSION['advSearchUserIDs'])) {
			echo '<br />
			<strong>Users:</strong> ';
			foreach ($_SESSION['advSearchUserIDs'] as $userID) {
				if ($user->getUser($userID)) {
					$userStr .= '"'.$user->userArray['userUsername'].'" <em>or</em> ';
				}
			}
			echo substr($userStr, 0, -13);
		}
		echo '</p>';
	
	// Display the limited results, if any.
	if ($search->advancedSearch($_SESSION['advSearchString'], $_SESSION['advSearchCategoryIDs'], $_SESSION['advSearchObjectTypeIDs'], $_SESSION['advSearchFileTypes'], $_SESSION['advSearchUserIDs'], $_GET['page'])) {
		$totalResults		= $search->totalResults;
		$advSearchResults	= $search->advSearchResults;
		
		echo 'There are <strong>'.$totalResults.'</strong> total results:</p>
		<div style="text-align: center;">'.pagination($_GET['page'], $totalResults, MAX_UNITS_PER_PAGE, 3, '<a href="'.$_SERVER['PHP_SELF'].'?page=').'</div>
		<ol start="'.((($_GET['page'] - 1) * MAX_UNITS_PER_PAGE) + 1).'">';
		
		foreach ($advSearchResults as $value) {
			$result = $objectType->getObjectTypes($value['objectTypeID']);
			$row = mysql_fetch_assoc($result);
			echo '<li><a href="object.php?id='.$value['objectID'].'" class="title">';
			if ($value['objectTitle']) {
				if ($_SESSION['advSearchString']) {
					echo highlightStr($value['objectTitle'], $_SESSION['advSearchString']);
				} else {
					echo $value['objectTitle'];
				}
			} else {
				echo '[no title]';
			}
			echo '</a> ('.strtoupper($row['objectTypeName']).')<br />';
			if ($_SESSION['advSearchString']) {
				echo highlightStr($value['objectDescription'], $_SESSION['advSearchString'], 90);
			} else {
				echo truncateString($value['objectDescription'], 180);
			}
			echo '</li>';
		}
		
		echo '</ol>';
	
	} else {
		echo $search->alert;
	}
}
?>