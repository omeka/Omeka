<div id="bannershell"> 
<?php
echo '<div id="banner"';
if (BANNER_IMAGE_URL) {
	$imageData = @getimagesize(BANNER_IMAGE_URL);
	echo ' style="background-image: url('.BANNER_IMAGE_URL.'); background-repeat: no-repeat; height: '.$imageData[1].'px;"';
}
echo '>';
?>

		<div id="bannersearch"> 
			<form action="simple_search_results.php" method="post" id="search"> 
				<p><strong><label for="quick search keywords" title="keyword search site">keywords</label></strong> 
				<input type="text" name="simpleSearchString" id="search" size="12" maxlength="255" value="" /> 
				<input type="submit" name="submitSimpleSearch" value="search" class="btn" /></p> 
				<p><a href="adv_search.php">advanced search</a></p>
				<?php
				if ($_SESSION['simpleSearchString']) {
					echo '<p><a href="simple_search_results.php" class="results">last simple search results</a></p>';
				}
				if (
				$_SESSION['advSearchString'] || 
				$_SESSION['advSearchCategoryIDs'] || 
				$_SESSION['advSearchObjectTypeIDs'] || 
				$_SESSION['advSearchFileTypes'] || 
				$_SESSION['advSearchUserIDs']
				) {
					echo '<p><a href="adv_search_results.php" class="results">last advanced search results</a></p>';
				}
				?>
			</form> 
		</div>
		<!-- end bannersearch --> 
	</div>
	<!-- end banner div --> 
	<div id="navshell"> 
		<ul id="globalnav"> 
<?php 
// home link
if ($_SERVER['SCRIPT_FILENAME'] == ADAM_ROOT_DIRECTORY.'index.php') {
	echo ' ';
} else {
	echo '<li><a href="index.php">home</a></li>';
}

// browse repository link
if ($_SERVER['SCRIPT_FILENAME'] == ADAM_ROOT_DIRECTORY.'archive.php') {
	echo '<li><a href="archive.php" class="on">archive</a></li>';
} else {
	echo '<li><a href="archive.php">archive</a></li>';
}			

// object type link
if ($_SERVER['SCRIPT_FILENAME'] == ADAM_ROOT_DIRECTORY.'object_type.php') {
	echo '<li><a href="object_type.php" class="on">object types</a></li>';
} else {
	echo '<li><a href="object_type.php">object types</a></li>';
}			

// PROTECTED ACCESS
if (USER_ACCESS_LEVEL <= 20) {
	// object entry link
	if ($_SERVER['SCRIPT_FILENAME'] == ADAM_ROOT_DIRECTORY.'object_entry.php') {
		echo '<li><a href="object_entry.php" class="on">enter object</a></li>';
	} else {
		echo '<li><a href="object_entry.php">enter object</a></li>';
	}
}

// PROTECTED ACCESS
if (USER_ACCESS_LEVEL <= 1) {
	// create object type link
	if ($_SERVER['SCRIPT_FILENAME'] == ADAM_ROOT_DIRECTORY.'object_type_create.php') {
		echo '<li><a href="object_type_create.php" class="on">create object type</a></li>';
	} else {
		echo '<li><a href="object_type_create.php">create object type</a></li>';
	}
}	

// PROTECTED ACCESS
if (USER_ACCESS_LEVEL <= 1) {
	// create object type link
	if ($_SERVER['SCRIPT_FILENAME'] == ADAM_ROOT_DIRECTORY.'user_management.php') {
		echo '<li><a href="user_management.php" class="on">manage users</a></li>';
	} else {
		echo '<li><a href="user_management.php">manage users</a></li>';
	}
}	
?> 
		</ul>
		<!-- end globalnav --> 
	</div>
	<!-- end navshell --> 
</div>
<!-- end banner shell -->