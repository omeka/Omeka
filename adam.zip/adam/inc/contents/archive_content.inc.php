<?php
// Instantiate the classes.
$category = new Category;
$objectType = new ObjectType;
$object = new Object;

// Validate the page number for object display.
settype($_GET['page'], 'integer');
if (!$_GET['page']) {
	$_GET['page'] = 1;
}

// PROTECTED ACCESS
if (USER_ACCESS_LEVEL <= 10) {
	// Handle the add category form.
	if ($_POST['submitAdd']) {
		$category->addCategory($_POST['catID'], $_POST['catName']);
		echo $category->alert;
		// Re-build the tree so any changes are automatically displayed.
		$_SESSION[DB_NAME.'_tree'] = $category->buildTree(0);
	// Handle the edit category form.
	} elseif ($_POST['submitEdit']) {
		$category->editCategory($_POST['catID'], $_POST['catName'], FALSE);
		echo $category->alert;
		// Re-build the tree so any changes are automatically displayed.
		$_SESSION[DB_NAME.'_tree'] = $category->buildTree(0);
	// Handle the assign object form.
	} elseif ($_POST['submitOrphanedObjects']) {
		$object->assignOrphanedObjects();
		echo $object->alert;
	} elseif ($_POST['submitAllObjects']) {
		$object->assignAllObjects();
		echo $object->alert;
	} elseif ($_POST['objectTypeID']) {
		$objectType->validateObjectTypeSelectionForm($_POST['objectTypeID']);
		echo $objectType->alert;
	// Order up the category.
	} elseif ($_GET['up']) {
		settype($_GET['up'], 'integer');
		$category->orderUp($_GET['up']);
		echo $category->alert;
		// Re-build the tree so any changes are automatically displayed.
		$_SESSION[DB_NAME.'_tree'] = $category->buildTree(0);
	// Order down the category.
	} elseif ($_GET['down']) {
		settype($_GET['down'], 'integer');
		$category->orderDown($_GET['down']);
		echo $category->alert;
		// Re-build the tree so any changes are automatically displayed.
		$_SESSION[DB_NAME.'_tree'] = $category->buildTree(0);
	// Delete all references to the object.
	} elseif ($_GET['deactivateObject']) {
		settype($_GET['deactivateObject'], 'integer');
		$object->deactivateObject($_GET['deactivateObject']);
		echo $object->alert;
	} elseif ($_GET['activateObject']) {
		settype($_GET['activateObject'], 'integer');
		$object->activateObject($_GET['activateObject']);
		echo $object->alert;
	}
}
// PROTECTED ACCESS
if (USER_ACCESS_LEVEL <= 1) {
	// Delete the category, all subcategories, and all references to assigned objects.
	if ($_GET['deleteCategory']) {
		$category->deleteCategory($_GET['deleteCategory']);
		echo $category->alert;
		// Re-build the tree so any changes are automatically displayed.
		$_SESSION[DB_NAME.'_tree'] = $category->buildTree(0);
	}
}


// $_SESSION['collapse'] and $_SESSION['tree'] are created only upon first visit to the page,
// or when the user resets (collapseTree) all the nodes in the tree. $_SESSION['collapse'] is
// an array containing all category IDs. This indicates that all nodes in the tree are collapsed.
// $_SESSION['tree'] is a multidimentional array that contains all tree node metadata. On
// subsequent visits $_SESSION['tree'] is passed instead of re-building the array using the
// recursive function. (Both of these $_SESSION arrays cut down on processing time -- less queries!)
// Also, unset $_SESSION['cat'] if the user collapses the tree, which will collapse any objects.
if (!isset($_SESSION[DB_NAME.'_collapse']) || isset($_GET['collapseTree'])) {
	$_SESSION[DB_NAME.'_collapse'] = $category->getIDs();
	$_SESSION[DB_NAME.'_tree'] = $category->buildTree(0);
	if (isset($_SESSION[DB_NAME.'_cat'])) {
		unset($_SESSION[DB_NAME.'_cat']);
	}

// Empty the collapse SESSION when the user expands (expandTree) all the nodes in the tree.
} elseif (isset($_GET['expandTree'])) {
	$_SESSION[DB_NAME.'_collapse'] = array();

// If the user wants the category collapsed push the category ID onto $_SESSION['collapse'].
} elseif ($_GET['collapse']) {
	settype($_GET['collapse'], 'integer');
	array_push($_SESSION[DB_NAME.'_collapse'], $_GET['collapse']);

// If the user wants the category expanded take out a category ID from $_SESSION['collapse'].
} elseif ($_GET['expand']) {
	// Have to set the array so as not to pass an empty variable to $_SESSION['collapse'],
	// otherwise it breaks the in_array() functions in the user-defined functions. This is a
	// solution to the "expand all-> collapse -> expand" bug, which breaks the page.
	// Actually, it's always a good idea to set an array before it is called.
	settype($_GET['expand'], 'integer');
	$newCollapse = array();
	foreach ($_SESSION[DB_NAME.'_collapse'] as $value) {
		if ($value != $_GET['expand']) {
			$newCollapse[] = $value;
		}
	}
	$_SESSION[DB_NAME.'_collapse'] = $newCollapse;

// If the user wants to show all objects assigned to the category and all its subcategories, get
// the category array. It builds a multidimentional array starting at the requested node and
// flattens the array so displayTree() can show the objects at the appropriate category.
} elseif ($_GET['showObjects']) {
	// First, unset $_SESSION['cat'] if the user wants to collapse the object list.
	settype($_GET['showObjects'], 'integer');
	if (isset($_SESSION[DB_NAME.'_cat']) && $_GET['showObjects'] == $_SESSION[DB_NAME.'_cat'][0]) {
		unset($_SESSION[DB_NAME.'_cat']);
	} else {
		$showTree = $category->buildTree($_GET['showObjects']);
		if (is_array($showTree)) {
			$_SESSION[DB_NAME.'_cat'] = $category->flattenTree($showTree);
			array_unshift($_SESSION[DB_NAME.'_cat'], $_GET['showObjects']);	
		} else {
			$_SESSION[DB_NAME.'_cat'] = array($_GET['showObjects']);
		}
	}
}

// Begin the category/object type form.
// PROTECTED ACCESS
if (USER_ACCESS_LEVEL <= 10) {
	echo '<form action="'.$_SERVER['PHP_SELF'].'" method="post">';
}

// Display the collapse tree and expand tree links.
echo '
<h3>Browse the Archive</h3>
[<a href="'.$_SERVER['PHP_SELF'].'?collapseTree">collapse all</a>] [<a href="'.$_SERVER['PHP_SELF'].'?expandTree">expand all</a>]</p>';

// Display the hierarchical tree, with control panel.
echo $category->displayTree($_SESSION[DB_NAME.'_tree'], 0, $_SESSION[DB_NAME.'_collapse'], $_GET['add'], $_GET['edit'], $_SESSION[DB_NAME.'_cat']);

// Display the submit button for assigning objects to categories.
if (USER_ACCESS_LEVEL <= 10) {
	echo '
	<div class="formElement">
		<input type="submit" name="submitAllObjects" value="assign previously assigned objects to categories" class="genSubmit" />
	</div>';
}

// Display the assign orphaned object form.
	echo '
	<div class="rule"><br /></div>
	<h3>Unassigned/Orphaned Objects</h3>';
	$result = $object->getOrphanedObjects();
	if (mysql_num_rows($result)) {
		echo '
		<p>The following objects are not assigned to a category:</p>
		<ol>';
		while ($row = mysql_fetch_assoc($result)) {
			echo '<li>';
			if (USER_ACCESS_LEVEL <= 10) {
				echo '<input type="checkbox" name="orphanedObjectIDs[]" value="'.$row['objectID'].'" />';
			}
			echo ' <a href="object.php?id='.$row['objectID'].'" class="title">';
			if ($row['objectTitle']) {
				echo truncateString($row['objectTitle'], 50);
			} else {
				echo '[no title]';
			}
			echo '</a> 
			<a href="object_type.php?viewObjects='.$row['objectTypeID'].'">('.strtoupper($row['objectTypeName']).')</a>';
			if (USER_ACCESS_LEVEL <= 20) {
				echo '<br />
				[<em>'.$row['permissionName'].'</em>]';
			}
			if (USER_ACCESS_LEVEL <= 10) {
				echo ' added: '.$row['added'].', by <strong>'.$row['userUsername'].'</strong>';
				if ($row['objectActive']) {
					echo ' [<a href="'.$_SERVER['PHP_SELF'].'?deactivateObject='.$row['objectID'].'" class="alert">deactivate object</a>]';
				} else {
					echo ' [<a href="'.$_SERVER['PHP_SELF'].'?activateObject='.$row['objectID'].'" class="error">activate object</a>]';
				}
			}
			echo '</li>';
		}
		echo '</ol>';
		if (USER_ACCESS_LEVEL <= 10) {
			echo '
			<div class="formElement">
				<input type="submit" name="submitOrphanedObjects" value="assign unassigned/orphaned objects to categories" class="genSubmit" />
			</div>';
		}
	} else {
		echo '<p>[There are no unassigned/orphaned objects.]</p>';
	}
	echo '
	<div class="rule"><br /></div>
	<h3>Key to Control Panel</h3>
	<ul id="categoryKey">
		<li><img src="'.IMAGES_URL.'exp.gif" /> (expand icon): expand the category node.</li>
		<li><img src="'.IMAGES_URL.'coll.gif" /> (collapse icon): collapse the category node.</li>
		<li><img src="'.IMAGES_URL.'objecton.gif" /> (object icon): view all objects under the category.</li>';
	if (USER_ACCESS_LEVEL <= 10) {
		echo '
		<li><img src="'.IMAGES_URL.'add.gif" /> (add icon): add a subcategory to the category.</li>
		<li><img src="'.IMAGES_URL.'edit.gif" /> (edit icon): edit the category name.</li>
		<li><img src="'.IMAGES_URL.'up.gif" /> (move up icon): move the category up in its node.</li>
		<li><img src="'.IMAGES_URL.'down.gif" /> (move down icon): move the category down in its node.</li>';
	}
	echo '
	</ul>';

// End the category/object type form.
// PROTECTED ACCESS
if (USER_ACCESS_LEVEL <= 10) {
	echo '</form>';
}
?>