<?php
// PROTECTED ACCESS
if (USER_ACCESS_LEVEL <= 1) {
		
	// Instantiate the object type class.
	$objectType = new ObjectType;

echo '<div class="readable">';
	
	// Handle object type form #1.
	if (isset($_REQUEST['submitPage1'])) {
		if (!$objectType->validateObjectTypeForm1()) {
			echo $objectType->alert;
			echo $objectType->objectTypeForm1;
		} else {
			echo $objectType->objectTypeForm2;
		}
	
	// Handle object type form #2.
	} elseif (isset($_REQUEST['submitPage2'])) {
		if (!$objectType->validateObjectTypeForm2()) {
			echo $objectType->alert;
			echo $objectType->objectTypeForm2;
		} else {		
			$objectType->generateObjectType();
			echo $objectType->alert;
			echo '<p>[<a href="'.$_SERVER['PHP_SELF'].'">enter another object type]</a></p>';
		}
	
	// Default to form #1.
	} else {
		echo $objectType->objectTypeForm1;
	}
	
	echo '</div><!-- End readable div -->';
}
?>