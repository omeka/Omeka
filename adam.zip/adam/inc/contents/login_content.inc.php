<?php
if ($_SESSION[DB_NAME.'_userID']) {
	echo '
	<div id="login">
		<form action="'.$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'].'" method="post">
		<p>Logged in as <strong>'.$_SESSION[DB_NAME.'_userUsername'].'</strong>:
		<input type="submit" name="submitLogout" value="logout" class="btn" /></p>
		</form>
	</div>';
} else {
	// Only display the login form on all pages if wanted or if on the login page.
	if (LOGIN_ON_ALL_PAGES || ($_SERVER['SCRIPT_FILENAME'] == ADAM_ROOT_DIRECTORY.'login.php')) {
		echo '
		<div id="login">
			<form action="'.$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'].'" method="post">
			<p><strong>username:</strong> <input type="text" size="10" maxlength="10" name="userUsername" /> 
			<strong>password:</strong> <input type="password" size="10" maxlength="10" name="userPassword" />
			<input type="submit" name="submitLogin" value="login" class="btn" /></p>
			</form>
		</div>';
	}
}
?>