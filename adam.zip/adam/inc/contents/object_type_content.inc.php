<?php
// Instantiate the object type and object classes.
$objectType = new ObjectType;
$object = new Object;

// Validate the page number for object display.
settype($_GET['page'], 'integer');
if (!$_GET['page']) {
	$_GET['page'] = 1;
}

echo '<div class="readable">';

// PROTECTED ACCESS
if (USER_ACCESS_LEVEL <= 10) {
	// Deactivate an object.
	if ($_GET['deactivateObject']) {
		$object->deactivateObject($_GET['deactivateObject']);
		echo $object->alert;
	// Activate an object.
	} elseif ($_GET['activateObject']) {
		$object->activateObject($_GET['activateObject']);
		echo $object->alert;
	// Edit the default element set.
	} elseif ($_REQUEST['submitEditDefaultSet']) {
		$objectType->editDefaultElementSet($_REQUEST['viewObjectType']);
		echo $objectType->alert;
	// Edit the default element set.
	} elseif ($_REQUEST['submitEditExtendedSet']) {
		$objectType->editExtendedElementSet($_REQUEST['viewObjectType']);
		echo $objectType->alert;
	}
}

// PROTECTED ACCESS
if (USER_ACCESS_LEVEL <= 1) {
	// Deactivate an object type.
	if ($_REQUEST['deactivateObjectType']) {
		$objectType->deactivateObjectType($_REQUEST['deactivateObjectType']);
		echo $objectType->alert;
	// Activate an object type.
	} elseif ($_REQUEST['activateObjectType']) {
		$objectType->activateObjectType($_REQUEST['activateObjectType']);
		echo $objectType->alert;
	 // Delete an extended element.
	 } elseif ($_REQUEST['deleteElement']) {
		$objectType->deleteElement($_REQUEST['viewObjectType'], $_REQUEST['deleteElement']);
		echo $objectType->alert;
	// Add a default element.
	} elseif ($_REQUEST['submitAddElement']) {
		$objectType->addElement($_REQUEST['viewObjectType']);
		echo $objectType->alert;
	}
}

// Display all objects in the selected object type.
if ($_REQUEST['viewObjects']) {
	// Get the object type data.
	$result = $objectType->getObjectTypes($_REQUEST['viewObjects']);
	if (mysql_num_rows($result)) {
		$row = mysql_fetch_assoc($result);
		echo '<h3>Objects in Object Type: '.$row['objectTypeName'].'</h3>';
		if ($objectType->getObjectsInObjectType($_REQUEST['viewObjects'], $_GET['page'])) {
			$totalResults 			= $objectType->totalResults;
			$objectsInObjectType	= $objectType->objectsInObjectType;
			if (count($objectsInObjectType)) {
				echo '<p>There are '.$totalResults.' total objects in this object type:</p>';
				echo '<div style="text-align: center;">'.pagination($_GET['page'], $totalResults, MAX_UNITS_PER_PAGE, 3, '<a href="'.$_SERVER['PHP_SELF'].'?viewObjects='.$_REQUEST['viewObjects'].'&page=', array('viewObjects'), array($_REQUEST['viewObjects']), $nextPage = NULL).'</div>';
				echo '<ol start="'.((($_GET['page'] - 1) * MAX_UNITS_PER_PAGE) + 1).'">';
				foreach ($objectsInObjectType as $value) {
					echo '<li>';
					if ($value['objectTitle']) {
						echo '<a href="object.php?id='.$value['objectID'].'" title="'.$value['objectTitle'].'" class="title">'.$value['objectTitle'].'</a> ';
					} else {
						echo '<a href="object.php?id='.$value['objectID'].'" class="title">[no title]</a> ';
					}
					if (USER_ACCESS_LEVEL <= 20) {
						echo '<br />[<em>'.$value['permissionName'].'</em>] ';
					}
					if (USER_ACCESS_LEVEL <= 10) {
						if ($value['objectActive']) {
							echo '[<a href="'.$_SERVER['PHP_SELF'].'?viewObjects='.$_REQUEST['viewObjects'].'&deactivateObject='.$value['objectID'].'&page='.$_GET['page'].'" class="alert">deactivate object</a>]';
						} else {
							echo '[<a href="'.$_SERVER['PHP_SELF'].'?viewObjects='.$_REQUEST['viewObjects'].'&activateObject='.$value['objectID'].'&page='.$_GET['page'].'" class="error">activate object</a>]';
						}
					}
					echo '</li>';
				}
				echo '</ol>';
			} else {
				echo '<p>[There are no objects in this object type.]</p>';
			}
		} else {
			echo $objectType->alert;
		}
	} else {
		echo '<div class="error">ERROR: There is no object type by that ID.</div>';
	}
	echo '<div class="rule"><br /></div>';
}


if ($_REQUEST['viewObjectType']) {
	// Get the object type data.
	$result = $objectType->getObjectTypes($_REQUEST['viewObjectType']);
	if (mysql_num_rows($result)) {
		$row = mysql_fetch_assoc($result);
		if (USER_ACCESS_LEVEL <= 10) {
			if (isset($_REQUEST['editDefaultSet'])) {
				echo '
				<form action="'.$_SERVER['PHP_SELF'].'?viewObjectType='.$_REQUEST['viewObjectType'].'" method="post">
				<h3>Edit Default Element Set:</h3>
				<div class="formElement">
					<div class="inputLabel">Title Description</div>
					<textarea name="objectTitleDescription" rows="8" cols="60">'.prepStr($row['objectTitleDescription'], 3).'</textarea>
				</div>
				<div class="formElement">
					<div class="inputLabel">Description Description</div>
					<textarea name="objectDescriptionDescription" rows="8" cols="60">'.prepStr($row['objectDescriptionDescription'], 3).'</textarea>
				</div>
				<div class="formElement">
					<div class="inputLabel">Creator/Author Description</div>
					<textarea name="objectCreatorDescription" rows="8" cols="60">'.prepStr($row['objectCreatorDescription'], 3).'</textarea>
				</div>
				<div class="formElement">
					<div class="inputLabel">Subject and Keywords Description</div>
					<textarea name="objectSubjectDescription" rows="8" cols="60">'.prepStr($row['objectSubjectDescription'], 3).'</textarea>
				</div>
				<div class="formElement">
					<div class="inputLabel">Date Description</div>
					<textarea name="objectDateDescription" rows="8" cols="60">'.prepStr($row['objectDateDescription'], 3).'</textarea>
				</div>
				<div class="formElement">
					<input type="submit" name="submitEditDefaultSet" value="edit default element set" class="genSubmit" /> <input type="submit" name="cancel" value="cancel this edit" class="genSubmit" />
				</div>
				</form>
				<div class="rule"><br /></div>';
			}
			if (isset($_REQUEST['editExtendedSet'])) {
				$objectTypeMetadataDump = unserialize($row['objectTypeMetadataDump']);
				echo '
				<form action="'.$_SERVER['PHP_SELF'].'?viewObjectType='.$_REQUEST['viewObjectType'].'" method="post">
				<h3>Edit Extended Element Set:</h3>';
				foreach ($objectTypeMetadataDump as $key => $value) {
					echo '
					<div class="formElement">
						<div class="inputLabel">'.$value[0].'</div>
						<textarea name="description[]" rows="8" cols="60">'.prepStr($value[1], 6).'</textarea>
					</div>';
				}
				echo '
				<div class="formElement">
					<input type="submit" name="submitEditExtendedSet" value="edit extended element set" class="genSubmit" /> <input type="submit" name="cancel" value="cancel this edit" class="genSubmit" />
				</div>
				</form>
				<div class="rule"><br /></div>';
			}
			if (isset($_REQUEST['addExtendedElement'])) {
				echo '
				<form action="'.$_SERVER['PHP_SELF'].'?viewObjectType='.$row['objectTypeID'].'" method="post">
				<h3>Add New Extended Element:</h3>
				<div class="formElement">
					<div class="inputLabel">Metadata Field Name</div>
					<div class="instructionText">Be descriptive yet concise; 1 or 2 words preferable; no punctuation:</div>
					<input type="text" name="objectTypeFieldName" '; if ($_REQUEST['objectTypeFieldName']) {echo 'value="'.prepStr($_REQUEST['objectTypeFieldName'], 6).'" ';} echo 'size="20" /><br />
				</div>
				<div class="formElement">
					<div class="inputLabel">Description of Field Name</div>
					<div class="instructionText">This is an elaborated description, a cautionary or instructive prompt, or directions for filling out the metadata field name, only if needed:</div>
					<textarea name="objectTypeFieldNameDescription" rows="8" cols="60">'; if ($_REQUEST['objectTypeFieldNameDescription']) {echo prepStr($_REQUEST['objectTypeFieldNameDescription'], 6);} echo '</textarea><br />
				</div>
				<div class="formElement">
					Text Input<input type="radio" name="objectTypeFormElementType" value="textInput" '; if ($_REQUEST['objectTypeFormElementType'] == 'textInput') {echo 'checked';} elseif (!$_REQUEST['objectTypeFormElementTypes'][$i]) {echo 'checked';} echo '/>
					Text Area<input type="radio" name="objectTypeFormElementType" value="textArea" '; if ($_REQUEST['objectTypeFormElementType'] == 'textArea') {echo 'checked';} echo '/></p>
				</div>
				<div class="formElement">
					<input type="submit" name="submitAddElement" value="add new extended element" class="genSubmit" /> <input type="submit" name="cancel" value="cancel this addition" class="genSubmit" />
				</div>
				</form>
				<div class="rule"><br /></div>';
			}
		}
		echo '<h3>Object Type: '.$row['objectTypeName'].'</h3>';
		if ($row['objectTypeDescription']) {
			echo '<p>'.nl2br($row['objectTypeDescription']).'</p>';
		} else {
			echo '<p>[no description]</p>';
		}
		echo '<h3>Default Element Set:</h3>';
		if (USER_ACCESS_LEVEL <= 10) {
			echo '<p>[<a href="'.$_SERVER['PHP_SELF'].'?viewObjectType='.$_REQUEST['viewObjectType'].'&editDefaultSet">edit default element set</a>]</p>';
		}
		echo '
		<ol>
			<li><strong>Title or short description</strong><br />
			'.$row['objectTitleDescription'].'</li>
			<li><strong>Description</strong><br />
			'.$row['objectDescriptionDescription'].'</li>
			<li><strong>Creator/Author</strong><br />
			'.$row['objectCreatorDescription'].'</li>
			<li><strong>Subject and Keywords</strong><br />
			'.$row['objectSubjectDescription'].'</li>
			<li><strong>Date</strong><br />
			'.$row['objectDateDescription'].'</li>
		</ol>';
		$objectTypeMetadataDump = unserialize($row['objectTypeMetadataDump']);
		if (is_array($objectTypeMetadataDump)) {
			echo '<h3>Extended Element Set:</h3>';
			if (USER_ACCESS_LEVEL <= 10) {
				echo '<p>[<a href="'.$_SERVER['PHP_SELF'].'?viewObjectType='.$_REQUEST['viewObjectType'].'&editExtendedSet">edit extended element set</a>]</p>';
			}
			echo '<ol>';
			foreach ($objectTypeMetadataDump as $key => $value) {
				echo '<li>';
				echo '<strong>'.prepStr($value[0], 6).':</strong><br />';
				if (USER_ACCESS_LEVEL <= 1) {
					echo '[<a href="'.$_SERVER['PHP_SELF'].'?viewObjectType='.$row['objectTypeID'].'&deleteElement='.($key + 1).'" onclick="return confirm(\'WARNING! Are you sure you want to delete this extended element? The element�s metadata will be unrecoverable. \')">delete this extended element</a>]<br />';
				}
				echo ''.prepStr($value[1], 6).'</li>';
			}
			echo '</ol>';
		} else {
			echo '<p>[There is no extended element set.]</p>';
		}
		if (USER_ACCESS_LEVEL <= 1) {
			echo '<p>[<a href="'.$_SERVER['PHP_SELF'].'?viewObjectType='.$_REQUEST['viewObjectType'].'&addExtendedElement">add an extended element</a>]</p>';
		}
	} else {
		echo '<div class="error">ERROR: Invalid object type.</div>';
	}
	echo '<div class="rule"><br /></div>';
}

// Display all object types and descriptions.
$result = $objectType->getObjectTypes();
echo '<h3>Object Types</h3>';
if (mysql_num_rows($result)) {
	echo '<ol>';
	while ($row = mysql_fetch_assoc($result)) {
		echo '
		<li><strong>'.$row['objectTypeName'].'</strong>';
		echo '<br />';
		echo '[<a href="'.$_SERVER['PHP_SELF'].'?viewObjects='.$row['objectTypeID'].'">view objects</a>] [<a href="'.$_SERVER['PHP_SELF'].'?viewObjectType='.$row['objectTypeID'].'">view object type metadata</a>]';
		// PROTECTED ACCESS
		if (USER_ACCESS_LEVEL <= 1) {
			if ($row['objectTypeActive']) {
				echo ' [<a href="'.$_SERVER['PHP_SELF'].'?deactivateObjectType='.$row['objectTypeID'].'" class="alert">deactivate object type</a>]';
			} else {
				echo ' [<a href="'.$_SERVER['PHP_SELF'].'?activateObjectType='.$row['objectTypeID'].'" class="error">activate object type</a>]';
			}
		}
		echo '</li>';
	}
	echo '</ol>';
} else {
	echo '<p>[There are no object types.]</p>';
}

echo '</div><!-- End readable div -->';
?>