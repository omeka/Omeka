<?php
if (USER_ACCESS_LEVEL <= 1) {

$user = new User;

if ($_REQUEST['deactivateUser']) {
	$user->deactivateUser($_REQUEST['deactivateUser']);
	echo $user->alert;
} elseif ($_REQUEST['activateUser']) {
	$user->activateUser($_REQUEST['activateUser']);
	echo $user->alert;
} elseif ($_REQUEST['submitEditUser']) {
	$user->editUser($_REQUEST['userID']);
	echo $user->alert;
} elseif ($_REQUEST['submitEditPassword']) {
	$user->editPassword($_REQUEST['userID']);
	echo $user->alert;
} elseif ($_REQUEST['submitAddUser']) {
	$user->addUser();
	echo $user->alert;
}

if ($_REQUEST['editUser']) {
	if ($user->getUser($_REQUEST['editUser'])) {
		$userArray = $user->userArray;
		echo '
		<form action="'.$_SERVER['PHP_SELF'].'" method="post">
		<h3>Edit User</h3>
		<div class="formElement">
			<div class="inputLabel">Username: '.$userArray['userUsername'].'</div>
		</div>
		<div class="formElement">
			<div class="inputLabel">First Name:</div>
			<input type="text" name="userFName" value="'.$userArray['userFName'].'" size="20" />
		</div>
		<div class="formElement">
			<div class="inputLabel">Last Name:</div>
			<input type="text" name="userLName" value="'.$userArray['userLName'].'" size="20" />
		</div>
		<div class="formElement">
			<div class="inputLabel">Email:</div>
			<input type="text" name="userEmail" value="'.$userArray['userEmail'].'" size="40" />
		</div>
		<div class="formElement">
			<div class="inputLabel">Institution:</div>
			<input type="text" name="userInstitution" value="'.$userArray['userInstitution'].'" size="40" />
		</div>
		<div class="formElement">
			<div class="inputLabel">Permission:</div>
			<select name="userPermissionID">';
		$result = getPermissions();
		while ($row = mysql_fetch_assoc($result)) {
			echo '
				<option value="'.$row['permissionID'].'"'; if ($row['permissionID'] == $userArray['userPermission']['permissionID']) {echo ' selected';} echo '>'.$row['permissionName'].'</option>';
		}
		echo '
			</select>
		</div>
		<p>[<a href="'.$_SERVER['PHP_SELF'].'?editPassword='.$userArray['userID'].'">edit password</a>]</p>
		<div class="formElement">
			<input type="submit" name="submitEditUser" value="edit user" class="genSubmit" />
		</div>
		<input type="hidden" name="userID" value="'.$userArray['userID'].'" />
		</form>';
	} else {
		echo $user->alert;
	}
	echo '<div class="rule"><br /></div>';
}

if ($_REQUEST['editPassword']) {
	if ($user->getUser($_REQUEST['editPassword'])) {
		$userArray = $user->userArray;
		echo '
		<form action="'.$_SERVER['PHP_SELF'].'" method="post">
		<h3>Edit Password</h3>
		<div class="formElement">
			<div class="inputLabel">Username: '.$userArray['userUsername'].'</div>
		</div>
		<div class="formElement">
			<div class="inputLabel">New password:</div>
			<input type="password" name="userPassword1" size="20" />
		</div>
		<div class="formElement">
			<div class="inputLabel">Retype password:</div>
			<input type="password" name="userPassword2" size="20" />
		</div>
		<div class="formElement">
			<input type="submit" name="submitEditPassword" value="edit password" class="genSubmit" />
		</div>
		<input type="hidden" name="userID" value="'.$userArray['userID'].'" />
		</form>';
	} else {
		echo $user->alert;
	}
	echo '<div class="rule"><br /></div>';
}

if (isset($_REQUEST['addUser'])) {
	echo '
	<form action="'.$_SERVER['PHP_SELF'].'" method="post">
	<h3>Add New User</h3>
	<div class="formElement">
		<div class="inputLabel">Username:</div>
		<input type="text" name="userUsername" size="20" />
	</div>
	<div class="formElement">
		<div class="inputLabel">Password:</div>
		<input type="password" name="userPassword1" size="20" />
	</div>
	<div class="formElement">
		<div class="inputLabel">Retype password:</div>
		<input type="password" name="userPassword2" size="20" />
	</div>
	<div class="formElement">
		<div class="inputLabel">First Name:</div>
		<input type="text" name="userFName" size="20" />
	</div>
	<div class="formElement">
		<div class="inputLabel">Last Name:</div>
		<input type="text" name="userLName" size="20" />
	</div>
	<div class="formElement">
		<div class="inputLabel">Email:</div>
		<input type="text" name="userEmail" size="40" />
	</div>
	<div class="formElement">
		<div class="inputLabel">Institution:</div>
		<input type="text" name="userInstitution" size="40" />
	</div>
	<div class="formElement">
		<div class="inputLabel">Permission:</div>
		<select name="userPermissionID">';
	$result = getPermissions();
	while ($row = mysql_fetch_assoc($result)) {
		echo '
			<option value="'.$row['permissionID'].'"'; if ($row['permissionID'] == 20) {echo ' selected';} echo '>'.$row['permissionName'].'</option>';
	}
	echo '
		</select>
	</div>
	<div class="formElement">
		<input type="submit" name="submitAddUser" value="add user" class="genSubmit" />
	</div>
	</form>
	<div class="rule"><br /></div>';	
}

// Display the users data.
if ($user->getUsers()) {
	echo '
	<h3>Manage Users</h3>
	<p>[<a href="'.$_SERVER['PHP_SELF'].'?addUser">add a new user</a>]</p>
	<table id="users">
		<tr>
			<td><strong>Username</strong></td>
			<td><strong>Permission</strong></td>
			<td><strong>Name</strong></td>
			<td><strong>Email</strong></td>
			<td><strong>Institution</strong></td>
			<td>&nbsp;</td>
		</tr>';
	foreach ($user->usersArray as $value) {
		echo '
		<tr>
			<td>'.$value['userUsername'].'<br />
			[<a href="'.$_SERVER['PHP_SELF'].'?editUser='.$value['userID'].'">edit user</a>]</td>
			<td>'.$value['userPermission']['permissionName'].'</td>
			<td>';
		if ($value['userLName'] || $value['userFName']) {
			echo $value['userLName'].', '.$value['userFName'];
		} else {
			echo '[none]';
		}
		echo '</td>
			<td>';
		if ($value['userEmail']) {
			echo $value['userEmail'];
		} else {
			echo '[none]';
		}
		echo '</td>
			<td>';
		if ($value['userInstitution']) {
			echo $value['userInstitution'];
		} else {
			echo '[none]';
		}
		echo '</td>
			<td>';
		// Users cannot deactivate themselves.
		if ($value['userID'] != $_SESSION[DB_NAME.'_userID']) {
			if ($value['userActive']) {
				echo '[<a href="'.$_SERVER['PHP_SELF'].'?deactivateUser='.$value['userID'].'" class="alert">deactivate</a>]';
			} else {
				echo '[<a href="'.$_SERVER['PHP_SELF'].'?activateUser='.$value['userID'].'" class="error">activate</a>]';
			}
		} else {
			echo '--------';
		}
		echo '</td>
		</tr>';
	}
	echo '
	</table>';
} else {
	echo '[There are no users in the system.]';
}
}
?>