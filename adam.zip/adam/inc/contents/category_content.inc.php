<?php
$category = new Category;
$object = new Object;
$objectType = new ObjectType;

settype($_GET['page'], 'integer');
if (!$_GET['page']) {
	$_GET['page'] = 1;
}

if (USER_ACCESS_LEVEL <= 10) {
	if ($_GET['deactivateObject']) {
		$object->deactivateObject($_GET['deactivateObject']);
		echo $object->alert;
	} elseif ($_GET['activateObject']) {
		$object->activateObject($_GET['activateObject']);
		echo $object->alert;
	} elseif ($_POST['submitObjectCategoryEdit']) {
		$category->editCategory($_POST['objectCategoryID'], $_POST['objectCategoryName'], $_POST['objectCategoryDescription']);
		echo $category->alert;
	}
}

if (USER_ACCESS_LEVEL <= 1) {
	if ($_GET['deleteCategory']) {
		$category->deleteCategory($_GET['deleteCategory']);
		echo $category->alert;
	}
}

if ($category->getCategory($_GET['id'], $_GET['page'])) {
	$objectCategoryID 			= $category->objectCategoryID;
	$objectCategoryParentID 	= $category->objectCategoryParentID;
	$objectCategoryName 		= $category->objectCategoryName;
	$objectCategoryDescription 	= $category->objectCategoryDescription;
	$pathToRootCategory 		= $category->pathToRootCategory;
	$totalResults 				= $category->totalResults;
	$recursiveObjects 			= $category->recursiveObjects;
	
	if (USER_ACCESS_LEVEL <= 10) {
		echo '<p>';
		if ($_GET['editCategory']) {
			echo '[<a href="'.$_SERVER['PHP_SELF'].'?id='.$objectCategoryID.'">return to simple category view</a>]';		
		} else {
			echo '[<a href="'.$_SERVER['PHP_SELF'].'?id='.$objectCategoryID.'&editCategory=true">edit this category</a>]';
		}
		echo '</p>';
	}
	echo '<div class="rule"><br /></div>';
	
	if (USER_ACCESS_LEVEL <= 10) {
		if ($_GET['editCategory']) {
			echo '
<h3>Edit Category</h3>
<form action="'.$_SERVER['PHP_SELF'].'?id='.$objectCategoryID.'" method="post">
<div class="formElement">
	<div class="inputLabel">Category Name:</div>
	<input type="text" name="objectCategoryName" value="'.$objectCategoryName.'" size="60" />
</div>
<div class="formElement">
	<div class="inputLabel">Category Description:</div>
	<textarea name="objectCategoryDescription" rows="8" cols="60">'.$objectCategoryDescription.'</textarea>
</div>
<div class="formElement">
	<input type="submit" name="submitObjectCategoryEdit" value="submit changes to this category" class="genSubmit" /> <input type="submit" name="cancel" value="cancel this edit" class="genSubmit" />
	<input type="hidden" name="objectCategoryID" value="'.$objectCategoryID.'" />
</div>
</form>';
			echo '<div class="rule"><br /></div>';
		}
	}

	echo '<h3>Category: '.$objectCategoryName.'</h3>';
	if ($objectCategoryDescription) {
		echo $objectCategoryDescription;
	} else {
		echo '[no description]';
	}
	echo '</p>';
	
	echo '<h3>All Category/Object Associations under Category</h3>';
	if (count($recursiveObjects)) {
		echo '<p>There are '.$totalResults.' total associations under this category (including subcategories):</p>';
		echo '<div style="text-align: center;">'.pagination($_GET['page'], $totalResults, MAX_UNITS_PER_PAGE, 3, '<a href="'.$_SERVER['PHP_SELF'].'?id='.$objectCategoryID.'&page=', array('id'), array($objectCategoryID), $nextPage = NULL).'</div>';
		echo '<ol start="'.((($_GET['page'] - 1) * MAX_UNITS_PER_PAGE) + 1).'">';
		foreach ($recursiveObjects as $value) {
			echo '<li>';
			if ($value['objectTitle']) {
				echo '<a href="object.php?id='.$value['objectID'].'" title="'.$value['objectTitle'].'" class="title">'.truncateString($value['objectTitle'], 40).'</a> ';
			} else {
				echo '<a href="object.php?id='.$value['objectID'].'" class="title">[no title]</a> ';
			}
			echo '<a href="object_type.php?id='.$value['objectTypeID'].'">('.strtoupper($value['objectTypeName']).')</a> in ';
			if ($objectCategoryID == $value['objectCategoryID']) {
				echo '<a href="category.php?id='.$value['objectCategoryID'].'" title="'.$value['objectCategoryName'].'" class="category">this category</a>';
			} else {
				echo 'subcategory "<a href="category.php?id='.$value['objectCategoryID'].'" title="'.$value['objectCategoryName'].'" class="category">'.truncateString($value['objectCategoryName'], 40).'</a>"';
			}
			if (USER_ACCESS_LEVEL <= 20) {
				echo '<br />[<em>'.$value['permissionName'].'</em>] ';
			}
			if (USER_ACCESS_LEVEL <= 10) {
				if ($value['objectActive']) {
					echo '[<a href="'.$_SERVER['PHP_SELF'].'?id='.$objectCategoryID.'&deactivateObject='.$value['objectID'].'" class="error">deactivate object</a>]';
				} else {
					echo '[<a href="'.$_SERVER['PHP_SELF'].'?id='.$objectCategoryID.'&activateObject='.$value['objectID'].'" class="alert">activate object</a>]';
				}
			}
			echo '</li>';
		}
		echo '</ol>';
	} else {
		echo '<p>[There are no objects under this category (including subcategories)]</p>';
	}

	echo '<h3>Path to Root Category</h3>';
	$i = 0;
	foreach ($pathToRootCategory as $value) {
		$categoryArray = explode('|', $value);
		echo '<div style="margin-left: '.($i * 28).'px;"><a href="'.$_SERVER['PHP_SELF'].'?id='.$categoryArray[0].'">'.$categoryArray[1].'</a></div>';
		$i++;
	}
	
	if (USER_ACCESS_LEVEL <= 1) {
		echo '<div class="rule"><br /></div>';
		echo '<h3>Category State Changes</h3>';
		echo '<p>To permanently remove this category and all its subcategories, click <strong><a href="archive.php?deleteCategory='.$objectCategoryID.'" onclick="return confirm(\'WARNING! Are you sure you want to delete this category: '.$objectCategoryName.'? This category and all its subcategories will be deleted, and any object assigned to them may be orphaned. \')" class="error">DELETE CATEGORY</a></strong>.</p>';
	}
} else {
	echo $category->alert;
}
?>