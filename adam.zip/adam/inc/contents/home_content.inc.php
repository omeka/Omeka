<?php
echo '
<div class="readable"> 
	<h3>'.PROJECT_TITLE.'</h3>';
if (PROJECT_DESCRIPTION) {
	echo PROJECT_DESCRIPTION;
}
echo '</div>';
?>