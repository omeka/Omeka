	<?php 
echo '
<div id="footer">
	<div class="footerNav">
	<p>';
	//adam home link
	if ($_SERVER['SCRIPT_FILENAME'] == ADAM_ROOT_DIRECTORY.'index.php') {
		echo ' ';
	} else {
		echo '<a href="index.php">home</a>';
	}
	if (
		$_SERVER['SCRIPT_FILENAME'] != ADAM_ROOT_DIRECTORY.'index.php' 
		&& $_SERVER['SCRIPT_FILENAME'] != ADAM_ROOT_DIRECTORY.'guide.php'
	) {
		echo ' | ';
	}
	if ($_SERVER['SCRIPT_FILENAME'] == ADAM_ROOT_DIRECTORY.'guide.php') {
		echo ' ';
	} else {
		echo '<a href="guide.php">guide</a>';
	}
echo '</p>
	</div>
</div>
<!-- end footer -->';
?>
