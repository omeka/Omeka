<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $pageTitle.': '.PROJECT_TITLE; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Content-Language" content="en-us" />
<meta name="Copyright" content="Copyright (c) <?php echo ''.date('Y').' '.PROJECT_TITLE ?>" />
<?php
if (file_exists('favicon.ico')) {
echo '
<link rel="shortcut icon" href="favicon.ico" />
<link rel="icon" href="favicon.ico" />';
}
?>
<style type="text/css">
<!--
@import url("<?php echo CSS_FILE_URL; ?>");
-->
</style>
<script language="javascript" type="text/javascript">

/* AJAX-ready javascript for future testing. */

function getHTTPObject() {
	var xmlhttp;
	/*
	@cc_on
	@if (@_jscript_version >= 5)
	try {
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	} catch (e) {
		try {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		} catch (E) {
			xmlhttp = false;
		}
	} 
	@else
		xmlhttp = false;
	@end @
	*/
	if (!xmlhttp && typeof XMLHttpRequest != "undefined") {
		try {
			xmlhttp = new XMLHttpRequest();
		} catch (e) {
			xmlhttp = false;
		}
	}
	return xmlhttp;
}

var http = getHTTPObject(); // We create the HTTP Object
var url = "";

function handleHttpResponse() {
	if (http.readyState == 4) {
		/*
		Assumes a hidden <div> like the one below:
		<div id="hiddenDIV" style="visibility:hidden; background-color:white; border: 0px solid black;"></div>
		*/
		document.getElementById("hiddenDIV").style.visibility="visible"; 
		document.getElementById("hiddenDIV").innerHTML=http.responseText;
	}
}

function updateData(param) {
	/*
	var action = document.getElementById("action").value;
	http.open("GET", url + "?action=" + escape(id) + "&param=" + escape(param), true);
	*/
	http.onreadystatechange = handleHttpResponse;
	http.send(null);
}
  
</script>
</head>
