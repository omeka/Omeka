<?php
// Function that truncates a string according to a length parameter.
function truncateString($string, $length = 100)
{
	settype($string, 'string');	
	// Check to see if the string is longer than the length
	if (strlen($string) > $length) {
		$str = substr($string, 0, strrpos(substr($string, 0, $length), ' ')).' ...';
	} else {
		$str = $string;
	}
	
	return $str;
}

// This function converts strings to studlyCaps.
function convertToStudlyCaps($str, $firstCaps = FALSE)
{
	// replace underscores with spaces and explode at all spaces
	$strArray = explode(' ', str_replace('_', ' ', $str));
	// generate the string in studlyCaps format
	$i = 1;
	foreach ($strArray as $value) {
		$value = preg_replace('/[^a-zA-Z1-9]/', '', strtolower($value));
		if ($i != 1 || $firstCaps) {
			$value = ucfirst($value);
		}
		$studlyCapsStr .= $value;
		$i++;
	}
	
	return $studlyCapsStr;
}

// This function converts strings to a unix_compatable_file_name.
function convertToUnixFileName($str, $fileExtension)
{
	// replace underscores with spaces and explode at all spaces
	$strArray = explode(' ', str_replace('_', ' ', $str));
	// generate the string in valid UNIX filing system format
	foreach ($strArray as $value) {
		$value = preg_replace('/[^a-zA-Z1-9]/', '', strtolower($value));	
		$unixFileNameStr .= $value.'_';	
	}
	$unixFileNameStr = substr($unixFileNameStr, 0, -1).'.'.$fileExtension;
	
	return $unixFileNameStr;
}

// This function gets all permissions from the database. (Not associated with any particular class.)
function getPermissions()
{
	global $db;
	
	$sql = 'SELECT * 
	FROM permissions 
	ORDER BY permissionID';
	$result = $db->dbQuery($sql);
	
	return $result;	
}

// This function destroys all $_SESSION data.
function destroySession()
{
	// Unset all of the session variables.
	$_SESSION = array();
	// If it's desired to kill the session, also delete the session cookie.
	// Note: This will destroy the session, and not just the session data!
	if (isset($_COOKIE[session_name()])) {
	   setcookie(session_name(), '', time() - 42000, '/');
	}
	// Finally, destroy the session.
	session_destroy();
}

function formatFileName($str)
{
	$search = array('/\s/', '/\W/');
	$replace = array('_', '');
	$fileNameStr = preg_replace($search, $replace, $str);
	
	return $fileNameStr;
}

function pagination($page, $totalResults, $objectsPerPage, $showPages, $openLink, $inputName = NULL, $inputValue = NULL, $nextPage = NULL, $showJumpToPage = TRUE)
{
	// Determine the page count.
	$pageCount = ceil($totalResults / $objectsPerPage);

	// Output nothing if the page count is 1 or 0.
	if ($pageCount <= 1) {
		return NULL;
	}

	// sanitize page number
	if((empty($page)) || (is_nan($page)) || ($page < 0) || (!isset($page))) {
		$page = 1;
	}

	// Minimum and Maximum Page Counts for the Paginations
	$pageCountMax = $page + $showPages;
	$pageCountMin = $page - $showPages;

	if ($pageCountMax > $pageCount) {
		$pageCountMax = $pageCount;
	}
	if ($pageCountMin < 0) {
		$pageCountMin = 0;
	}

	if ($showJumpToPage) {
		if (empty($nextPage)) {
			$link .= '<form method="get" action="'.$_SERVER["PHP_SELF"].'">';
		} else {
			$link .= '<form method="get" action="'.$nextPage.'">';
		}
	}

	//Print PREVIOUS and FIRST Page
	if ($page > 1) {

		//Set Previous Page
		$prevPage = $page - 1;

		// Print "FIRST" Page
		$link .= $openLink.'1">first</a> | ';

		// Print "PREVIOUS" Page
		$link .= $openLink.$prevPage.'">previous</a> | ';
	}

	for ($pageCountMin; $pageCountMin < $pageCountMax; $pageCountMin++) {

		//Set page Number Apart from Counter
		$curPage = $pageCountMin + 1;

		//Print Pagination
		if ($page == $curPage && $pageCountMin == 0) {
			$link .= '<strong>'.$page.'</strong> | ';
		} elseif ($page == $curPage) {
			$link .= '<strong>'.$curPage.'</strong> | ';
		} else {
			$link .= $openLink.$curPage.'">'.$curPage.'</a> | ';
		}
	}

	//Print Total pages
	$nextPage = $page + 1;
	if ($pageCount > 1) {
		$link .= ' of '.$pageCount;
	}

	//Print NEXT and LAST Page
	if ($pageCount>$page) {

		// Print "NEXT" Page
		$link .= ' | '.$openLink.$nextPage.'">next</a> | ';

		// Print "LAST" Page
		$link .= $openLink.$pageCount.'">last</a>';
	}

	if ($showJumpToPage) {
		if ($pageCount > 1) {
			
			//loop this value because it must be an array
			for ($i = 0; $i < count($inputName); $i++) {
				$link .= '<input type="hidden" name="'.$inputName[$i].'" value="'.$inputValue[$i].'">';
			}
			
			$link .= ' | <select name="page" onChange="this.form.submit()">';
			$link .= '<option value="0">Jump to Page</option>';
	
			for ($i = 1; $i < $pageCount + 1; $i++) {
				$link .= '<option>'.$i.'</option>';
			}
		}
	
		$link .= '</select></form>';
	}

	//return pagination links
	return $link;
}

function humanReadableSize($sizeInKb)
{
	$size = ($sizeInKb > 512) ? (($sizeInKb / 1024 > 512) ? sprintf("%.02f MB", ($sizeInKb / 1024) / 1024) : sprintf("%.02f kB", $sizeInKb / 1024)) : sprintf("%d B", $sizeInKb);
	return $size;
}

// This function performs baseline alterations to a string, preparing it for various states.
// Any further alterations should be performed before passing the string to this function.
// Valid $prepareType arguments:
// 1 -- webFormToDatabase_normal
// 2 -- webFormToDatabase_strict
// 3 -- databaseToWebPage_normal
// 4 -- databaseToWebPage_strict
// 5 -- webFormToWebPage
// 6 -- webFormToWebForm
function prepStr($str, $prepareType)
{
	// Type-cast passed variables.
	settype($str, 'string');
	settype($prepareType, 'integer');
	
	// Trim whitespace from beginning and end of the string. All strings are trimmed!
	$str = trim($str);
	
	// Prepare the string according to $prepareType.
	switch ($prepareType) {
		////////////////////////////////
		// 1 -- webFormToDatabase_normal
		// Prepare a string for normal database insertion from a web form.
		case 1:
			if (!get_magic_quotes_gpc()) {
				$str = addslashes();
			}
			break;
		
		////////////////////////////////
		// 2 -- webFormToDatabase_strict
		// Prepare a string for strict database insertion from a web form. 
		// The $chars array maps conversions for problematic characters. This includes 
		// characters modified by MS Word's AutoCorrect function. The $chars array 
		// may be extended to include further character conversions.
		case 2:
			if (get_magic_quotes_gpc()) {
				$str = stripslashes($str);
			}
			$chars = array(
				133 => '...', // &#8230; horizontal ellipsis
				145 => '\'', // &#8216; left single quotation mark
				146 => '\'', // &#8217; right single quotation mark
				147 => '"', // &#8220; left double quotation mark
				148 => '"', // &#8221; right double quotation mark
				150 => '--', // &#8211; en dash
				151 => '--', // &#8212; em dash
			);
			$str = str_replace(array_map('chr', array_keys($chars)), $chars, $str);
			$str = addslashes($str);
			break;
		
		////////////////////////////////
		// 3 -- databaseToWebPage_normal
		// Prepare a string for normal webpage insertion from a database.
		case 3:
			break;
		
		////////////////////////////////
		// 4 -- databaseToWebPage_strict
		// Prepare a string for strict webpage insertion from a database. 
		// It converts MS Word and other non-alphanumeric characters to their 
		// valid HTML counterparts. The $chars array extends the htmlentities() character 
		// conversions, and may be extended to include further character conversions.
		case 4:
			$str = preg_replace('/[^!-%\x27-;=?-~ ]/e', '"&#".ord("$0").chr(59)', $str);
			//$str = htmlentities(stripslashes($str), ENT_QUOTES);
			$chars = array(
				128 => '&#8364;',
				130 => '&#8218;',
				131 => '&#402;',
				132 => '&#8222;',
				133 => '&#8230;',
				134 => '&#8224;',
				135 => '&#8225;',
				136 => '&#710;',
				137 => '&#8240;',
				138 => '&#352;',
				139 => '&#8249;',
				140 => '&#338;',
				142 => '&#381;',
				145 => '&#8216;',
				146 => '&#8217;',
				147 => '&#8220;',
				148 => '&#8221;',
				149 => '&#8226;',
				150 => '&#8211;',
				151 => '&#8212;',
				152 => '&#732;',
				153 => '&#8482;',
				154 => '&#353;',
				155 => '&#8250;',
				156 => '&#339;',
				158 => '&#382;',
				159 => '&#376;'
			);
			$str = str_replace(array_map('chr', array_keys($chars)), $chars, $str);
			break;
		
		////////////////////////////////
		// 5 -- webFormToWebPage
		// Prepare a string for webpage insertion from a web form.
		case 5:
			if (get_magic_quotes_gpc()) {
				$str = stripslashes($str);
			}
			break;
		
		////////////////////////////////
		// 6 -- webFormToWebForm
		// Prepare a string for web form insertion from a web form.
		case 6:
			$str = htmlentities(stripslashes($str), ENT_QUOTES);
			$chars = array(
				128 => '&#8364;',
				130 => '&#8218;',
				131 => '&#402;',
				132 => '&#8222;',
				133 => '&#8230;',
				134 => '&#8224;',
				135 => '&#8225;',
				136 => '&#710;',
				137 => '&#8240;',
				138 => '&#352;',
				139 => '&#8249;',
				140 => '&#338;',
				142 => '&#381;',
				145 => '&#8216;',
				146 => '&#8217;',
				147 => '&#8220;',
				148 => '&#8221;',
				149 => '&#8226;',
				150 => '&#8211;',
				151 => '&#8212;',
				152 => '&#732;',
				153 => '&#8482;',
				154 => '&#353;',
				155 => '&#8250;',
				156 => '&#339;',
				158 => '&#382;',
				159 => '&#376;'
			);
			$str = str_replace(array_map('chr', array_keys($chars)), $chars, $str);
			break;
		
		////////////////////////////////
		// Default: return the unaltered string if $prepareType is invalid.
		default:
			break;
	}
	
	// Return the fully prepared string.
	return $str;
}

function highlightStr($haystack, $needle, $bufferLen = FALSE, $highlightColor = '#FFFFAA')
{
	settype($haystack, 'string');
	settype($needle, 'string');
	
	// Check to see if the needle is in the haystack.
	if (stristr($haystack, $needle)) {
		
		// Strip HTML tags, lest the tags will throw off the string character counts.
		$haystack = strip_tags($haystack);
		$needle = strip_tags($needle);
		
		// If the buffer length argument exists, process the haystack accordingly.
		if ($bufferLen) {
			settype($bufferLen, 'integer');
			
			// Set the begin and end buffer lengths.
			$beginBufferLen = $bufferLen;
			$endBufferLen = $bufferLen;
			
			// Set the haystack and needle lengths.
			$haystackLen = strlen($haystack);
			$needleLen = strlen($needle);
			
			// PHP 4.x  does not have the case insensitive stripos(). Below is a way around that.
			$temp = stristr($haystack, $needle);
			$needlePos = $haystackLen - strlen($temp);
			
			// Determine whether the string's buffer lengths need to be modified.
			if (($beginBufferLen + $needleLen + $endBufferLen) < $haystackLen) {
				// Reset the begin and end buffer lengths if necessary.
				// If the begin buffer length exceeds the character position of the needle, set the begin buffer length to the needle position, 
				// and set the end buffer length to compensate for the buffer length lost at the beginning of the string.
				if ($beginBufferLen > $needlePos) {
					$beginBufferLen = $needlePos;
					$endBufferLen = ($bufferLen - $needlePos) + $bufferLen; 
				}
				
				// If the end buffer length exceeds the haystack length less the position and length of the needle, set the begin buffer length 
				// to copensate for the buffer length lost at the end of the string.
				if ($endBufferLen > ($haystackLen - ($needlePos + $needleLen))) {
					$beginBufferLen = ($endBufferLen - ($haystackLen - ($needlePos + $needleLen))) + $beginBufferLen;
				}
				// Add the buffers to the beginning and ending of the string.
				$haystack = '... '.substr($haystack, ($needlePos - $beginBufferLen), ($beginBufferLen + $needleLen + $endBufferLen)).' ...';
			}
			
		}
		// PHP 4.x does not have the case insensitive srt_ireplace(). Below is a way around that.
		$haystack = preg_replace('/'.$needle.'/i', '<span style="background-color: '.$highlightColor.';">'.$needle.'</span>', $haystack);
		
		return $haystack;
		
	} else {
		if ($bufferLen) {
			$haystack = truncateString($haystack, ($bufferLen * 2));
			return $haystack;
		} else {
			return $haystack;
		}
	}
}
?>