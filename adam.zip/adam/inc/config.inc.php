<?php
// Start the session.
session_start();

// Require class scripts.
require_once('classes/user_class.inc.php');
require_once('classes/object_class.inc.php');
require_once('classes/db_class.inc.php');
require_once('classes/object_type_class.inc.php');
require_once('classes/category_class.inc.php');
require_once('classes/search_class.inc.php');

// Require function scripts.
require_once('functions/common_functions.inc.php');

// Define MySQL connection constants.
define('DB_NAME', 'adam'); // This constant is also used to differenciate $_SESSION and $_COOKIE variables, otherwise there may be a namespace conflict with other implementations of ADAM on the same server.
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_HOST', 'localhost');

// Define global configuration constants.

// Title of the project.
define('PROJECT_TITLE',				'Adaptable Digital Archive Manager (ADAM)');

// Simple description of the project, if any (HTML and PHP allowed). This can be empty if there is no description.
define('PROJECT_DESCRIPTION',		'
<p>The purpose of ADAM is to provide an adaptable digital framework around which you can manage your project\'s assets. Think of ADAM as modular furniture. Build it using simple tools, position it neatly, and organize your objects accordingly.</p>
<p>Developed by Jim Safley for the <a href="http://chnm.gmu.edu/">Center for History and New Media</a>.</p>
<p>Click <a href="guide.php">here</a> to learn more about ADAM.</p>
<p>Version 0.8<br />
'.date("F j, Y").'</p>
');

// Full path from root to directory in which ADAM is installed
// (always begin and end with a foward slash "/").
define('ADAM_ROOT_DIRECTORY', 	'/websites/echo/adam/');

// URL for the website
// (always end with a foward slash "/").
define('WEBSITE_URL',			'http://echo.gmu.edu/adam/');

// URL for the cascading style sheet file.
define('CSS_FILE_URL',			'http://echo.gmu.edu/adam/styles/base_style.css');

// URL for the banner image. This can be empty if there is no image.
define('BANNER_IMAGE_URL',		'http://echo.gmu.edu/adam/imgs/adam_banner.jpg');

// URL for the imgs directory
// (always end with a foward slash "/").
define('IMAGES_URL',			'http://echo.gmu.edu/adam/imgs/');

// URL for the files directory
// (always end with a foward slash "/").
define('FILES_URL',				'http://echo.gmu.edu/adam/files/');

// Maximum number of file uploads per form.
// RECOMMENDED is 1 (any more will increase the risk of exceeding maximum file upload size and timeouts).
define('MAX_FILE_UPLOAD',		1);

// Full path from root to file upload directory (directory must be set to 777 permission).
// (always begin and end with a foward slash "/").
define('FILE_UPLOAD_DIRECTORY',	'/websites/echo/adam/files/');

// Full path from root to file dropbox directory (directory must be set to 777 permission).
// (always begin and end with a foward slash "/").
define('FILE_DROPBOX_DIRECTORY','/websites/echo/adam/dropbox_files/');

// Maximum number of objects, categories, object types, or files in a list per page.
// RECOMMENDED is no more than 10.
define('MAX_UNITS_PER_PAGE', 	10);

// TRUE = login and logoff form will be on all pages;
// FALSE = login form will anly be available on login.php, but logoff for will be on all pages.
define('LOGIN_ON_ALL_PAGES',	TRUE);

// TRUE = perform searches in full text mode. May give unpredictable results.
// FALSE = perform simple searches using LIKE "%...%". Very forgiving, but may give excessive results.
// RECOMMENDED is FALSE until there are enough objects to reliably use full text. Certain characters give full text searches problems.
define('SEARCH_IN_FULL_TEXT',	FALSE);

// TRUE = upon initial ingest, objects are made inactive and must be activated by an administrator.
// FALSE = upon initial ingest, objects are made active and can be viewed by those with permission.
// This configuration depends on how rigorous you want your review process to be.
define('REVIEW_OBJECTS',		TRUE);

// TRUE = debugging mode is on;
// FALSE = debugging mode is off.
define('DEBUGGING_MODE',		FALSE);

// Connect to MySQL.
$db = new DB;
$db->dbConnect();

// Authenticate the user.
$user = new User;
// Handle user login.
if ($_POST['submitLogin']) {
	$user->authenticateUser();
// Handle user logout.
} elseif ($_POST['submitLogout']) {
	$user->logoutUser();
// Reset the session if it expires before the browser closes.
} elseif (isset($_COOKIE[DB_NAME]) && !isset($_SESSION[DB_NAME.'_userID'])) {
	// To enable cookie-based session resets (in case the session expires before the browser 
	// closes), the cookie data must match up perfectly with a row in the users table. This will 
	// go a long way in protecting a session from being hijacked.
	$cookie = explode(';;', $_COOKIE[DB_NAME]);
	if ($user->checkUserExists($cookie)) {
		$_SESSION[DB_NAME.'_userID']			= $cookie[1];
		$_SESSION[DB_NAME.'_userUsername']		= $cookie[2];
		$_SESSION[DB_NAME.'_userFName']			= $cookie[3];
		$_SESSION[DB_NAME.'_userLName']			= $cookie[4];
		$_SESSION[DB_NAME.'_userPermissionID']	= $cookie[5];
	}
}
// Set the user access level.
define('USER_ACCESS_LEVEL', $user->userAccessLevel());

// Display the debugging control panel.
if (DEBUGGING_MODE) {
	// Provide a way to completely destroy the $_SESSION variable for debugging purposes.
	if (isset($_GET['sessionDestroy'])) {
		destroySession();
	}
	echo '
	DEBUGGING: 
	<a href="'.$_SERVER['PHP_SELF'].'?sessionDestroy">destroy current session</a> | 
	<a href="javascript://" onclick="showhide(\'superglobals\');">display current superglobals</a>'."\n";
}

// Display hidden super-globals if debugging mode is on.
if (DEBUGGING_MODE) {
	// First print out the necessary javascript to show and hide the data.
	echo '
	<script language="javascript">
		<!--
		var state = "hidden";
		function showhide(layer_ref) {
			
			if (state == "visible") {
				state = "hidden";
			} else {
				state = "visible";
			}
			
			//IS IE 4 or 5 (or 6 beta)
			if (document.all) {
				eval( "document.all." + layer_ref + ".style.visibility = state");
			}
			
			//IS NETSCAPE 4 or below
			if (document.layers) {
				document.layers[layer_ref].visibility = state;
			}
			
			if (document.getElementById && !document.all) {
				maxwell_smart = document.getElementById(layer_ref);
				maxwell_smart.style.visibility = state;
			}
		}
		//-->
	</script>';
	echo '<div id="superglobals" style="position:absolute; background-color: #ffffff; visibility: hidden;"><pre>'."\n";
	echo '<strong>$_POST:</strong>'."\n";
	print_r($_POST);
	echo '<strong>$_GET:</strong>'."\n";
	print_r($_GET);
	echo '<strong>$_FILES:</strong>'."\n";
	print_r($_FILES);
	echo '<strong>$_COOKIE:</strong>'."\n";
	print_r($_COOKIE);
	echo '<strong>$_SESSION:</strong>'."\n";
	print_r($_SESSION);
	echo '</pre></div>'."\n";
}

?>
