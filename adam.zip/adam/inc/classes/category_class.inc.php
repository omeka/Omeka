<?php
class Category
{
	// Alert attribute.
	var $alert;
	
	// Category attributes.
	var $objectCategoryID;
	var $objectCategoryParentID;
	var $objectCategoryName;
	var $objectCategoryDescription;
	
	// Parent categories attribute.
	var $pathToRootCategory = array();
	
	// Objects attribute.
	var $totalResults;
	var $recursiveObjects = array();

	// Constructor that initializes non-constant category attributes.
	function Category()
	{
	}
	
	function getCategory($categoryID, $page)
	{
		global $db;
		
		// Set the type to an integer.
		settype($categoryID, 'integer');
		
		$sql = 'SELECT * 
		FROM objectCategories 
		WHERE objectCategoryID = '.$categoryID.'';
		$result = $db->dbQuery($sql);
		
		// Check if there is an object by the supplied ID.
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There is no category with that ID number.</div>';
			return FALSE;
		}
		
		$row = mysql_fetch_assoc($result);
		// DO NOT CHANGE THE ORDER BELOW. Population order is vital to a working script.
		// Populate the category attributes.
		$this->objectCategoryID = $categoryID; // Set the category ID to whatever was passed.
		$this->objectCategoryParentID = $row['objectCategoryParentID'];
		$this->objectCategoryName = $row['objectCategoryName'];
		$this->objectCategoryDescription = $row['objectCategoryDescription'];
		// Populate the parent categories attribute.
		$this->getParentCategories();
		// Populate the objects attribute.
		$this->getObjects($page);
		
		return TRUE;
	}
	
	function getParentCategories()
	{
		$this->pathToRootCategory = $this->getPath($this->objectCategoryID);
	}
	
	function getObjects($page)
	{
		global $db;
		
		// Build the category tree array and flatten it.
		$showTree = $this->buildTree($this->objectCategoryID);
		if (is_array($showTree)) {
			$cat = $this->flattenTree($showTree);
			array_unshift($cat, $this->objectCategoryID);	
		} else {
			$cat = array($this->objectCategoryID);
		}

		if (USER_ACCESS_LEVEL <= 1) {
			$sql = 'SELECT * 
			FROM objects, objects_objectCategories, objectCategories, objectTypes 
			WHERE objects.objectID = objects_objectCategories.objectID 
			AND objectCategories.objectCategoryID = objects_objectCategories.objectCategoryID 
			AND objects.objectTypeID = objectTypes.objectTypeID AND (';
			foreach ($cat as $value) {
				$sql .= 'objects_objectCategories.objectCategoryID = '.$value.' OR ';
			}
			$sql = substr($sql, 0, -4).')';			
			$resultTotal = $db->dbQuery($sql);
			
			$sql = 'SELECT * 
			FROM objects, objects_objectCategories, objectCategories, objectTypes, permissions 
			WHERE objects.objectID = objects_objectCategories.objectID 
			AND objects.objectPermissionID = permissions.permissionID 
			AND objectCategories.objectCategoryID = objects_objectCategories.objectCategoryID 
			AND objects.objectTypeID = objectTypes.objectTypeID AND (';
			foreach ($cat as $value) {
				$sql .= 'objects_objectCategories.objectCategoryID = '.$value.' OR ';
			}
			$sql = substr($sql, 0, -4).') 
			ORDER BY objects.objectActive DESC, 
			objectTypes.objectTypeActive DESC, 
			objectTypes.objectTypeName, 
			objects.objectTitle 
			LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';			
		} elseif (USER_ACCESS_LEVEL <= 10) {
			$sql = 'SELECT * 
			FROM objects, objects_objectCategories, objectCategories, objectTypes 
			WHERE objects.objectID = objects_objectCategories.objectID 
			AND objectCategories.objectCategoryID = objects_objectCategories.objectCategoryID 
			AND objects.objectTypeID = objectTypes.objectTypeID AND (';
			foreach ($cat as $value) {
				$sql .= 'objects_objectCategories.objectCategoryID = '.$value.' OR ';
			}
			$sql = substr($sql, 0, -4).') 
			AND objects.objectPermissionID >= 10';			
			$resultTotal = $db->dbQuery($sql);
			
			$sql = 'SELECT * 
			FROM objects, objects_objectCategories, objectCategories, objectTypes, permissions 
			WHERE objects.objectID = objects_objectCategories.objectID 
			AND objects.objectPermissionID = permissions.permissionID 
			AND objectCategories.objectCategoryID = objects_objectCategories.objectCategoryID 
			AND objects.objectTypeID = objectTypes.objectTypeID AND (';
			foreach ($cat as $value) {
				$sql .= 'objects_objectCategories.objectCategoryID = '.$value.' OR ';
			}
			$sql = substr($sql, 0, -4).') 
			AND objects.objectPermissionID >= 10 
			ORDER BY objects.objectActive DESC, 
			objectTypes.objectTypeActive DESC, 
			objectTypes.objectTypeName, 
			objects.objectTitle 
			LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';			
		} elseif (USER_ACCESS_LEVEL <= 20) {
			$sql = 'SELECT * 
			FROM objects, objects_objectCategories, objectCategories, objectTypes 
			WHERE objects.objectID = objects_objectCategories.objectID 
			AND objectCategories.objectCategoryID = objects_objectCategories.objectCategoryID 
			AND objects.objectTypeID = objectTypes.objectTypeID AND (';
			foreach ($cat as $value) {
				$sql .= 'objects_objectCategories.objectCategoryID = '.$value.' OR ';
			}
			$sql = substr($sql, 0, -4).') 
			AND objects.objectPermissionID >= 20 
			AND objectTypes.objectTypeActive = 1 
			AND objects.objectActive = 1';			
			$resultTotal = $db->dbQuery($sql);
			
			$sql = 'SELECT * 
			FROM objects, objects_objectCategories, objectCategories, objectTypes, permissions 
			WHERE objects.objectID = objects_objectCategories.objectID 
			AND objects.objectPermissionID = permissions.permissionID 
			AND objectCategories.objectCategoryID = objects_objectCategories.objectCategoryID 
			AND objects.objectTypeID = objectTypes.objectTypeID AND (';
			foreach ($cat as $value) {
				$sql .= 'objects_objectCategories.objectCategoryID = '.$value.' OR ';
			}
			$sql = substr($sql, 0, -4).') 
			AND objects.objectPermissionID >= 20 
			AND objectTypes.objectTypeActive = 1 
			AND objects.objectActive = 1 
			ORDER BY objectTypes.objectTypeName, 
			objects.objectTitle 
			LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';			
		} elseif (USER_ACCESS_LEVEL <= 30) {
			$sql = 'SELECT * 
			FROM objects, objects_objectCategories, objectCategories, objectTypes 
			WHERE objects.objectID = objects_objectCategories.objectID 
			AND objectCategories.objectCategoryID = objects_objectCategories.objectCategoryID 
			AND objects.objectTypeID = objectTypes.objectTypeID AND (';
			foreach ($cat as $value) {
				$sql .= 'objects_objectCategories.objectCategoryID = '.$value.' OR ';
			}
			$sql = substr($sql, 0, -4).') 
			AND objects.objectPermissionID >= 30 
			AND objectTypes.objectTypeActive = 1 
			AND objects.objectActive = 1 
			ORDER BY objectTypes.objectTypeName, 
			objects.objectTitle';
			$resultTotal = $db->dbQuery($sql);
			
			$sql = 'SELECT * 
			FROM objects, objects_objectCategories, objectCategories, objectTypes 
			WHERE objects.objectID = objects_objectCategories.objectID 
			AND objectCategories.objectCategoryID = objects_objectCategories.objectCategoryID 
			AND objects.objectTypeID = objectTypes.objectTypeID AND (';
			foreach ($cat as $value) {
				$sql .= 'objects_objectCategories.objectCategoryID = '.$value.' OR ';
			}
			$sql = substr($sql, 0, -4).') 
			AND objects.objectPermissionID >= 30 
			AND objectTypes.objectTypeActive = 1 
			AND objects.objectActive = 1 
			ORDER BY objectTypes.objectTypeName, 
			objects.objectTitle 
			LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';			
		}
		
		$this->totalResults = mysql_num_rows($resultTotal);
		$result = $db->dbQuery($sql);
		while ($row = mysql_fetch_assoc($result)) {
			$this->recursiveObjects[] = $row;
		}
	}
	
	// Recursive function that returns a multidimentional array containing category ID
	// and category name data in the array keys. The array values may be arrays themselves,
	// and all the arrays must be named, so keys are populated with category ID as well as 
	// category name metadata. This function is only called on a first visit to a page, or
	// when the user wants to collapse (collapseTree) all nodes in the tree. (This cuts down
	// on processing time -- less queries!)
	function buildTree($parentID)
	{
		global $db;
		
		$sql = 'SELECT * 
		FROM objectCategories 
		WHERE objectCategoryParentID = '.$parentID.' 
		ORDER BY objectCategoryOrder';
		$result = $db->dbQuery($sql);
		// Build the tree through recursive iteration.
		while ($row = mysql_fetch_assoc($result)) {
			$tree[$row['objectCategoryID'].'|'.$row['objectCategoryName']] = $this->buildTree($row['objectCategoryID']);
		}
		
		return $tree;
	}
	
	// Function that flattens the buildTree() array if needed.
	function flattenTree($tree)
	{
		$flatTree = array();
		foreach($tree as $key => $value) {
			$key = explode('|', $key);
			// Flatten the tree through recursive iteration.
			if(is_array($value)) {
				$flatTree[] = $key[0];
				$flatTree = array_merge($flatTree, $this->flattenTree($value));
			} else {
				$flatTree[] = $key[0];
			}
		}
		
		return $flatTree;
	}
	
	// Function that returns an array containing the path to the node of the tree.
	function getPath($nodeID)
	{
		global $db;
		
		$sql = 'SELECT objectCategoryID, objectCategoryParentID, objectCategoryName 
		FROM objectCategories 
		WHERE objectCategoryID = '.$nodeID.'';
		$result = $db->dbQuery($sql);
		$row = mysql_fetch_assoc($result);
		if ($row['objectCategoryID'] != 0) {
			$path[] = $row['objectCategoryID'].'|'.$row['objectCategoryName'];
			$path = array_merge($this->getPath($row['objectCategoryParentID']), $path);
		}
		
		return $path;
	}
	
	// Function that returns an array containing all category IDs. This function is only called
	// on a first visit to a page, or when the user wants to collapse (collapseTree) all nodes
	// in the tree. (This cuts down on processing time -- less queries!)
	function getIDs() 
	{
		global $db;
		
		$sql = 'SELECT objectCategoryID FROM objectCategories';
		$result = $db->dbQuery($sql);
		/* Build the ID array. */
		while ($row = mysql_fetch_assoc($result)) {
			$ids[] = $row['objectCategoryID'];
		}
		
		return $ids;
	}
	
	// Function that recursively displays the category tree, expanded or collapsed.
	function displayTree($tree, $level, $collapse, $add = FALSE, $edit = FALSE, $cat = FALSE) {
		if (is_array($tree)) {
			foreach($tree as $key => $value) {
				// Prepare the level divs.
				$key = explode('|', $key);
				$str .= '<div style="margin-left: '.($level * 28).'px;">'."\n";
				// If the parent node has children (is an array) display the appropriate content.
				if (is_array($value)) {
					// Display the expand or collapse links. */
					if (in_array($key[0], $collapse)) {
						$str .= '<a href="'.$_SERVER['PHP_SELF'].'?expand='.$key[0].'"><img class="img" src="'.IMAGES_URL.'exp.gif" title="expand this category node" /></a>'."\n";
					} else {
						$str .= '<a href="'.$_SERVER['PHP_SELF'].'?collapse='.$key[0].'"><img class="img" src="'.IMAGES_URL.'coll.gif" title="collapse this category node" /></a>'."\n";
					}
					$str .= $this->displayControlPanel($key, $level, $add, $edit, $cat).'</div>'."\n";
					// If the node is not collapsed, recursively itereate through the function
					// until the node is collapsed or there are no more children.
					if (!in_array($key[0], $collapse)) {
						$str .= $this->displayTree($value, $level + 1, $collapse, $add, $edit, $cat);			
					}
				// If the parent node does not have children (is not an array) display the appropriate content.
				} else {
					$str .= $this->displayControlPanel($key, $level, $add, $edit, $cat).'</div>'."\n";
				}
			}
		} else {
			$str = '[There are no root categories.]';
		}
		
		return $str;
	}
	
	// Function that displays the control panel for the category tree.
	function displayControlPanel($key, $level, $add, $edit, $cat)
	{
		global $db;
		
		// Display the object list link.
		$str .= '<a href="'.$_SERVER['PHP_SELF'].'?showObjects='.$key[0].'"><img class="img" src=';
		if ($key[0] == $cat[0]) {
			$str .= '"'.IMAGES_URL.'objectoff.gif" title="turn off object display"';
		} else {			
			$str .= '"'.IMAGES_URL.'objecton.gif" title="display objects"';
		}
		$str .= ' /></a>'."\n";
		
		// PROTECTED FUNCTIONALITY
		if (USER_ACCESS_LEVEL <= 10) {
			// Display the add category, edit category, delete category, move category up, and move category down links, as well as the file assign checkbox.
			$str .= '<a href="'.$_SERVER['PHP_SELF'].'?add='.$key[0].'"><img class="img" src="'.IMAGES_URL.'add.gif" title="add a subcategory" /></a> '."\n";
			$str .= '<a href="'.$_SERVER['PHP_SELF'].'?edit='.$key[0].'"><img class="img" src="'.IMAGES_URL.'edit.gif" title="edit this category" /></a> '."\n";
			$str .= '<a href="'.$_SERVER['PHP_SELF'].'?up='.$key[0].'"><img class="img" src="'.IMAGES_URL.'up.gif" title="move this category up" /></a> '."\n";
			$str .= '<a href="'.$_SERVER['PHP_SELF'].'?down='.$key[0].'"><img class="img" src="'.IMAGES_URL.'down.gif" title="move this category down" /></a> '."\n";
			$str .= '<input type="checkbox" name="assign[]" value="'.$key[0].'" />'."\n";
		}
		
		// Display the category name link.
		$str .= '<a href="category.php?id='.$key[0].'" class="category">'; if ($key[1]) {$str .= $key[1];} else {$str .= '[no category name]';} $str .= '</a><br />'."\n";
		
		// PROTECTED ACCESS
		if (USER_ACCESS_LEVEL <= 10) {
			
			// Display the add category form if selected.
			if ($key[0] == $add) {
				$str .= '<input type="text" size="40" name="catName" />'."\n";
				$str .= '<input type="hidden" name="catID" value="'.$key[0].'" />'."\n";
				$str .= '<input type="submit" name="submitAdd" value="add subcategory" class="genSubmit" /><input type="submit" name="cancel" value="cancel" class="genSubmit" /><br />'."\n";
			
			// Display the edit category form if selected.
			} elseif ($key[0] == $edit) {
				$str .= '<input type="text" size="40" name="catName" value="'.prepStr($key[1], 4).'" />'."\n";
				$str .= '<input type="hidden" name="catID" value="'.$key[0].'" />'."\n";
				$str .= '<input type="submit" name="submitEdit" value="edit category" class="genSubmit" /><input type="submit" name="cancel" value="cancel" class="genSubmit" /><br />'."\n";
			}
		}
		
		// Display the objects recursively under the selected category, if any.
		if ($key[0] == $cat[0]) {
			// These recursive object queries are seperate from the getObjects() method because there is no need 
			// for administrators to view inactive category/object associations on the category tree.
			$sql = 'SELECT * 
			FROM objects, objects_objectCategories, objectCategories, objectTypes 
			WHERE objects.objectID = objects_objectCategories.objectID 
			AND objectCategories.objectCategoryID = objects_objectCategories.objectCategoryID 
			AND objects.objectTypeID = objectTypes.objectTypeID AND (';
			foreach ($cat as $value) {
				$sql .= 'objects_objectCategories.objectCategoryID = '.$value.' OR ';
			}
			$sql = substr($sql, 0, -4).') 
			AND objects.objectPermissionID >= '.USER_ACCESS_LEVEL.' ';
			if (USER_ACCESS_LEVEL > 10) {
				$sql .='
				AND objectTypes.objectTypeActive = 1 
				AND objects.objectActive = 1';			
			}
			$result = $db->dbQuery($sql);
			$totalResults = mysql_num_rows($result);
			
			$sql = 'SELECT * 
			FROM objects, objects_objectCategories, objectCategories, objectTypes 
			WHERE objects.objectID = objects_objectCategories.objectID 
			AND objectCategories.objectCategoryID = objects_objectCategories.objectCategoryID 
			AND objects.objectTypeID = objectTypes.objectTypeID AND (';
			foreach ($cat as $value) {
				$sql .= 'objects_objectCategories.objectCategoryID = '.$value.' OR ';
			}
			$sql = substr($sql, 0, -4).') 
			AND objects.objectPermissionID >= '.USER_ACCESS_LEVEL.' ';
			if (USER_ACCESS_LEVEL > 10) {
				$sql .= '
				AND objectTypes.objectTypeActive = 1 
				AND objects.objectActive = 1 ';
			}
			$sql .= '
			ORDER BY objects.objectAdded DESC 
			LIMIT '.(($_GET['page'] - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';			
			$result = $db->dbQuery($sql);
			// If there are objects under the category, display them.
			if (mysql_num_rows($result)) {
				$str .= '<div class="hlight">There are '.$totalResults.' total category/object associations under this category (including subcategories).'."\n";
				
				// The "Jump To Page" form in the pagination line cannot be used because it would create a nested form within another form, which would not work.
				$str .= '<div style="text-align: center;">'.pagination($_GET['page'], $totalResults, MAX_UNITS_PER_PAGE, 3, '<a href="'.$_SERVER['PHP_SELF'].'?page=', array('showObjects'), array($_REQUEST['showObjects']), NULL, NULL, NULL, FALSE).'</div>';				
				
				$str .= '<ol start="'.((($_GET['page'] - 1) * MAX_UNITS_PER_PAGE) + 1).'">';
				
				while ($row = mysql_fetch_assoc($result)) {
					$str .= '<li>';
					// PROTECTED ACCESS
					if (USER_ACCESS_LEVEL <= 10) {
						$str .= '<input type="checkbox" name="allObjectIDs[]" value="'.$row['objectID'].'" /> ';
					}
					if ($row['objectTitle']) {
						$str .= '<a href="object.php?id='.$row['objectID'].'" class="title">'.truncateString($row['objectTitle'], 40).'</a> ';
					} else {
						$str .= '<a href="object.php?id='.$row['objectID'].'" class="title">[no title]</a> ';
					}
					$str .= '<a href="object_type.php?viewObjects='.$row['objectTypeID'].'">('.strtoupper($row['objectTypeName']).')</a> in ';
					if ($key[0] == $row['objectCategoryID']) {
						$str .= '<a href="category.php?id='.$row['objectCategoryID'].'" class="category">this category</a>';
					} else {
						$str .= 'subcategory "<a href="category.php?id='.$row['objectCategoryID'].'" class="category">'.truncateString($row['objectCategoryName'], 40).'</a>"'."\n";
					}
					if (USER_ACCESS_LEVEL <= 10) {
						if (!$row['objectActive']) {
							$str .= ' <span class="error">[inactive]</span>';
						}
					}
					$str .= '</li>';
				}
				$str .= '
				</ol>
				</div>';
			} else {
				$str .= '<div class="hlight">There are no objects under this category (including subcategories)<br /></div>';
			}
		}
		
		return $str;
	}
	
	// Function that resets the entire category order.
	// WARNING! ONLY USE THIS FUNCTION WHEN IT IS NECESSARY TO RESET THE ENTIRE CATEGORY ORDER!
	function resetCatOrder($highestCatID = 1000)
	{
		global $db;
		
		unset($i);
		for ($j = 0; $j <= $highestCatID; $j++) {
			$sql = 'SELECT * 
			FROM objectCategories 
			WHERE objectCategoryParentID = '.$j.'';
			$result = $db->dbQuery($sql);
			$i = 1;
			while ($row = mysql_fetch_assoc($result)) {
				$sql = 'UPDATE objectCategories 
				SET objectCategoryOrder = '.$i.' 
				WHERE objectCategoryID = '.$row['objectCategoryID'].'';
				$db->dbQuery($sql);
				$i++;
			}
		}
	}
	
	// Function that moves a category up in order.
	function orderUp($catID)
	{
		global $db;
		
		$sql = 'SELECT * 
		FROM objectCategories 
		WHERE objectCategoryID = '.$catID.'';
		$result = $db->dbQuery($sql);
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There is no category by the given ID number.</div>';
			return FALSE;
		}
		
		$result = $db->dbQuery($sql);
		$rowCat = mysql_fetch_assoc($result);
		if ($rowCat['objectCategoryOrder'] > 1) {
			$sql = 'SELECT * 
			FROM objectCategories 
			WHERE objectCategoryParentID = '.$rowCat['objectCategoryParentID'].'';
			$result = $db->dbQuery($sql);
			while ($row = mysql_fetch_assoc($result)) {
				if ($row['objectCategoryID'] == $catID) {
					$sql = 'UPDATE objectCategories 
					SET objectCategoryOrder = (objectCategoryOrder - 1) 
					WHERE objectCategoryID = '.$row['objectCategoryID'].'';
					$db->dbQuery($sql);
				} elseif ($row['objectCategoryOrder'] == ($rowCat['objectCategoryOrder'] - 1)) {
					$sql = 'UPDATE objectCategories 
					SET objectCategoryOrder = (objectCategoryOrder + 1) 
					WHERE objectCategoryID = '.$row['objectCategoryID'].'';
					$db->dbQuery($sql);
				}
			}
			$this->alert = '<div class="alert">A category has been ordered up.</div>';
		}
	}
	
	// Function that moves a category down in order.
	function orderDown($catID)
	{
		global $db;
		
		$sql = 'SELECT * 
		FROM objectCategories 
		WHERE objectCategoryID = '.$catID.'';
		$result = $db->dbQuery($sql);
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There is no category by the given ID number.</div>';
			return FALSE;
		}
		
		$result = $db->dbQuery($sql);
		$rowCat = mysql_fetch_assoc($result);
		$sql = 'SELECT MAX(objectCategoryOrder) AS maxObjectCategoryOrder 
		FROM objectCategories 
		WHERE objectCategoryParentID = '.$rowCat['objectCategoryParentID'].'';
		$result = $db->dbQuery($sql);
		$row = mysql_fetch_assoc($result);
		if ($rowCat['objectCategoryOrder'] < $row['maxObjectCategoryOrder']) {
			$sql = 'SELECT * 
			FROM objectCategories 
			WHERE objectCategoryParentID = '.$rowCat['objectCategoryParentID'].'';
			$result = $db->dbQuery($sql);
			while ($row = mysql_fetch_assoc($result)) {
				if ($row['objectCategoryID'] == $catID) {
					$sql = 'UPDATE objectCategories 
					SET objectCategoryOrder = (objectCategoryOrder + 1) 
					WHERE objectCategoryID = '.$row['objectCategoryID'].'';
					$db->dbQuery($sql);
				} elseif ($row['objectCategoryOrder'] == ($rowCat['objectCategoryOrder'] + 1)) {
					$sql = 'UPDATE objectCategories 
					SET objectCategoryOrder = (objectCategoryOrder - 1) 
					WHERE objectCategoryID = '.$row['objectCategoryID'].'';
					$db->dbQuery($sql);
				}
			}
			$this->alert = '<div class="alert">A category has been ordered down.</div>';
		}
	}
	
	// Function that adds a child category to a parent category.
	function addCategory($catParentID, $catName) {
		global $db;
		
		$catName = str_replace('|', '', prepStr($catName, 2));
		$sql = 'SELECT * 
		FROM objectCategories 
		WHERE objectCategoryParentID = '.$catParentID.'';
		$result = $db->dbQuery($sql);
		if (mysql_num_rows($result)) {
			$sql = 'SELECT MAX(objectCategoryOrder) + 1 AS lastObjectCategoryOrder 
			FROM objectCategories 
			WHERE objectCategoryParentID = '.$catParentID.'';
			$result = $db->dbQuery($sql);
			$row = mysql_fetch_assoc($result);
			$sql = 'INSERT INTO objectCategories (
			objectCategoryParentID, 
			objectCategoryName, 
			objectCategoryOrder
			) VALUES (
			'.$catParentID.', 
			"'.$catName.'", 
			'.$row['lastObjectCategoryOrder'].'
			)';
			$db->dbQuery($sql);
		} else {
			$sql = 'INSERT INTO objectCategories (
			objectCategoryParentID, 
			objectCategoryName, 
			objectCategoryOrder
			) VALUES (
			'.$catParentID.', 
			"'.$catName.'", 
			1
			)';
			$db->dbQuery($sql);
		}
		
		$this->alert = '<div class="alert">A category has been added.</div>';
		return TRUE;
	}
		
	// Function that edits a category name.
	function editCategory($catID, $catName, $catDescription) {
		global $db;
		
		$sql = 'UPDATE objectCategories 
		SET objectCategoryName = "'.str_replace('|', '', prepStr($catName, 2)).'", 
		objectCategoryDescription = "'.prepStr($catDescription, 1).'" 
		WHERE objectCategoryID = '.$catID.'';	
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">A category has been edited.</div>';
		return TRUE;
	}

	// Function that deletes a category and its subcategories and unlinks all objects assigned to it.
	function deleteCategory($categoryID)
	{
		global $db;
				
		settype($categoryID, 'integer');

		$sql = 'SELECT * 
		FROM objectCategories 
		WHERE objectCategoryID = '.$categoryID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There is no category by the given ID number.</div>';
			return FALSE;
		}
		
		// First build an array containing all categories in the specified node.
		$deleteArray = $this->buildTree($categoryID);
		if (is_array($deleteArray)) {
			$deleteArray = $this->flattenTree($deleteArray);
			array_unshift($deleteArray, $categoryID);	
		} else {
			$deleteArray = array($categoryID);
		}
		
		// Determine the order of the category and the node's parent category.
		$sql = 'SELECT objectCategoryParentID, objectCategoryOrder 
		FROM objectCategories 
		WHERE objectCategoryID = '.$categoryID.'';
		$result = $db->dbQuery($sql);
		$rowDeletedCat = mysql_fetch_assoc($result);
		
		// Delete each category and all object associations. Note that objects are not deleted, 
		// only orphaned (i.e. only the object/category link is deleted, while the object is preserved).
		foreach ($deleteArray as $deleteID) {
			$sql = 'DELETE FROM objectCategories 
			WHERE objectCategoryID = '.$deleteID.'';
			$db->dbQuery($sql);
			$sql = 'DELETE FROM objects_objectCategories 
			WHERE objectCategoryID = '.$deleteID.'';
			$db->dbQuery($sql);
		}
		
		// Reorder the categories in the parent node.
		$sql = 'UPDATE objectCategories 
		SET objectCategoryOrder = (objectCategoryOrder - 1) 
		WHERE objectCategoryParentID = '.$rowDeletedCat['objectCategoryParentID'].' 
		AND  objectCategoryOrder > '.$rowDeletedCat['objectCategoryOrder'].'';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">A category, all its subcategories, and all object associations assigned to them were deleted.</div>';
		return TRUE;
	}
}
?>