<?php
class DB
{
	// Constructor that initializes non-constant database attributes.
	function DB()
	{
	}

	function dbConnect()
	{
		if (mysql_connect(DB_HOST, DB_USER, DB_PASS)) {
			if (mysql_select_db(DB_NAME)) {
				return TRUE;
			} else {
				if (DEBUGGING_MODE) {
					exit('
					<pre>
					<p>DATABASE UNABLE TO CONNECT!<br />
					<a href="javascript: window.location.reload()">Reload Page</a></p>
					<p>MYSQL ERROR:<br />
					'.mysql_error().'</p>
					<p>========================================</p>
					'.$this->getDebugBacktrace().'
					</pre>');
				} else {
					exit('
					<pre>
					<p>There was a problem. Please try again.<br />
					<a href="javascript:history.go(-1)">Click here to go back.</a></p>
					<p>If the problem persists please contact the webmaster.</p>
					</pre>');
				}
			}
		} else {
			if (DEBUGGING_MODE) {
				exit('
				<pre>
				<p>MySQL UNABLE TO CONNECT!<br />
				<a href="javascript: window.location.reload()">Reload Page</a></p>
				<p>MYSQL ERROR:<br />
				'.mysql_error().'</p>
				<p>========================================</p>
				'.$this->getDebugBacktrace().'
				</pre>');
			} else {
				exit('
				<pre>
				<p>There was a problem. Please try again.<br />
				<a href="javascript:history.go(-1)">Click here to go back.</a></p>
				<p>If the problem persists please contact the webmaster.</p>
				</pre>');
			}
		}
	}
	
	function dbQuery($sql)
	{
		if ($result = mysql_query($sql)) {
			return $result;
		} else {
			if (DEBUGGING_MODE) {
				exit('
				<pre>
				<p>ERROR FOUND!<br />
				<a href="javascript: window.location.reload()">Reload Page</a></p>
				<p>MYSQL ERROR:<br />'.mysql_error().'</p>
				<p>QUERY STRING:<br />'.$sql.'</p>
				<p>========================================</p>
				'.$this->getDebugBacktrace().'
				</pre>');
			} else {
				exit('
				<pre>
				<p>There was a problem. Please try again.<br />
				<a href="javascript:history.go(-1)">Click here to go back.</a></p>
				<p>If the problem persists please contact the webmaster.</p>
				</pre>');
			}
		}	
	}
	
	// This function formats the debug_backtrace() function for dubugging purposes.
	// It prints out the chain of calls before the error, including file and line number.
	function getDebugBacktrace()
	{
		$i = 1;
		foreach (debug_backtrace() as $trace) {
			$str .= '<p>DEBUG BACKTRACE '.$i.'<br />
			File: '.$trace['file'].'<br />
			Line: '.$trace['line'].'</p>';
			$i++;
		}
		
		return $str;
	}
}
?>