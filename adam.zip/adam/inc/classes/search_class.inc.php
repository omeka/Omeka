<?php
class Search
{
	var $alert;
	
	var $totalResults;
	var $simpleSearchResults = array();
	var $advSearchResults = array();

	// Constructor that initializes non-constant search attributes.
	function Search()
	{
	}
	
	function simpleSearch($searchString, $page)
	{
		global $db;
		
		if (!$searchString) {
			$this->alert = '<div class="error">[no search parameters given]</div>';
			return FALSE;
		}

		settype($searchString, 'string');
		settype($page, 'integer');
		
		$searchString = prepStr($searchString, 1);
		
		if (USER_ACCESS_LEVEL <= 1) {
			if (SEARCH_IN_FULL_TEXT) {
				$sql = 'SELECT objectID 
				FROM objects 
				WHERE MATCH (
				objectTitle, 
				objectCreator, 
				objectSubject, 
				objectDescription, 
				objectData, 
				objectDate
				) AGAINST(
				"'.$searchString.'"
				)';
				$resultTotal = $db->dbQuery($sql);
				
				$sql = 'SELECT * 
				FROM objects 
				WHERE MATCH (
				objectTitle, 
				objectCreator, 
				objectSubject, 
				objectDescription, 
				objectData, 
				objectDate
				) AGAINST(
				"'.$searchString.'"
				)  
				LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';
			} else {
				$sql = 'SELECT * 
				FROM objects 
				WHERE objectTitle LIKE "%'.$searchString.'%" 
				OR objectCreator LIKE "%'.$searchString.'%" 
				OR objectSubject LIKE "%'.$searchString.'%" 
				OR objectDescription LIKE "%'.$searchString.'%" 
				OR objectData LIKE "%'.$searchString.'%" 
				OR objectDate LIKE "%'.$searchString.'%"';
				$resultTotal = $db->dbQuery($sql);
				
				$sql = 'SELECT * 
				FROM objects 
				WHERE objectTitle LIKE "%'.$searchString.'%" 
				OR objectCreator LIKE "%'.$searchString.'%" 
				OR objectSubject LIKE "%'.$searchString.'%" 
				OR objectDescription LIKE "%'.$searchString.'%" 
				OR objectData LIKE "%'.$searchString.'%" 
				OR objectDate LIKE "%'.$searchString.'%" 
				ORDER BY objectTitle 
				LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';
			}
		} elseif (USER_ACCESS_LEVEL <= 10) {
			if (SEARCH_IN_FULL_TEXT) {
				$sql = 'SELECT objectID 
				FROM objects 
				WHERE MATCH(
				objectTitle, 
				objectCreator, 
				objectSubject, 
				objectDescription, 
				objectData, 
				objectDate
				) AGAINST(
				"'.$searchString.'"
				) 
				AND objects.objectPermissionID >= 10';
				$resultTotal = $db->dbQuery($sql);
				
				$sql = 'SELECT * 
				FROM objects 
				WHERE MATCH(
				objectTitle, 
				objectCreator, 
				objectSubject, 
				objectDescription, 
				objectData, 
				objectDate
				) AGAINST(
				"'.$searchString.'"
				) 
				AND objects.objectPermissionID >= 10 
				LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';
			} else {
				$sql = 'SELECT * 
				FROM objects 
				WHERE (
				objectTitle LIKE "%'.$searchString.'%" 
				OR objectCreator LIKE "%'.$searchString.'%" 
				OR objectSubject LIKE "%'.$searchString.'%" 
				OR objectDescription LIKE "%'.$searchString.'%" 
				OR objectData LIKE "%'.$searchString.'%" 
				OR objectDate LIKE "%'.$searchString.'%"
				) 
				AND objects.objectPermissionID >= 10';
				$resultTotal = $db->dbQuery($sql);
				
				$sql = 'SELECT * 
				FROM objects 
				WHERE (
				objectTitle LIKE "%'.$searchString.'%" 
				OR objectCreator LIKE "%'.$searchString.'%" 
				OR objectSubject LIKE "%'.$searchString.'%" 
				OR objectDescription LIKE "%'.$searchString.'%" 
				OR objectData LIKE "%'.$searchString.'%" 
				OR objectDate LIKE "%'.$searchString.'%"
				) 
				AND objects.objectPermissionID >= 10
				ORDER BY objectTitle 
				LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';
			}
		// Prevent non-admins from seeing objects that are inactive in all assigned categories.
		} elseif(USER_ACCESS_LEVEL <= 20) {
			if (SEARCH_IN_FULL_TEXT) {
				$sql = 'SELECT objects.objectID 
				FROM objects, objectTypes 
				WHERE MATCH(
				objects.objectTitle, 
				objects.objectCreator, 
				objects.objectSubject, 
				objects.objectDescription, 
				objects.objectData, 
				objects.objectDate
				) AGAINST(
				"'.$searchString.'"
				)  
				AND objects.objectTypeID = objectTypes.objectTypeID 
				AND objectTypes.objectTypeActive = 1 
				AND objects.objectActive = 1 
				AND objects.objectPermissionID >= 20';
				$resultTotal = $db->dbQuery($sql);
				
				$sql = 'SELECT * 
				FROM objects, objectTypes 
				WHERE MATCH(
				objects.objectTitle, 
				objects.objectCreator, 
				objects.objectSubject, 
				objects.objectDescription, 
				objects.objectData, 
				objects.objectDate
				) AGAINST(
				"'.$searchString.'"
				)  
				AND objects.objectTypeID = objectTypes.objectTypeID 
				AND objectTypes.objectTypeActive = 1 
				AND objects.objectActive = 1 
				AND objects.objectPermissionID >= 20 
				LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';
			} else {
				$sql = 'SELECT * FROM objects, objectTypes 
				WHERE (
				objects.objectTitle LIKE "%'.$searchString.'%" 
				OR objects.objectCreator LIKE "%'.$searchString.'%" 
				OR objects.objectSubject LIKE "%'.$searchString.'%" 
				OR objects.objectDescription LIKE "%'.$searchString.'%" 
				OR objects.objectData LIKE "%'.$searchString.'%" 
				OR objects.objectDate LIKE "%'.$searchString.'%"
				) 
				AND objects.objectTypeID = objectTypes.objectTypeID 
				AND objectTypes.objectTypeActive = 1 
				AND objects.objectActive = 1 
				AND objects.objectPermissionID >= 20';
				$resultTotal = $db->dbQuery($sql);

				$sql = 'SELECT * FROM objects, objectTypes 
				WHERE (
				objects.objectTitle LIKE "%'.$searchString.'%" 
				OR objects.objectCreator LIKE "%'.$searchString.'%" 
				OR objects.objectSubject LIKE "%'.$searchString.'%" 
				OR objects.objectDescription LIKE "%'.$searchString.'%" 
				OR objects.objectData LIKE "%'.$searchString.'%" 
				OR objects.objectDate LIKE "%'.$searchString.'%"
				) 
				AND objects.objectTypeID = objectTypes.objectTypeID 
				AND objectTypes.objectTypeActive = 1 
				AND objects.objectActive = 1 
				AND objects.objectPermissionID >= 20 
				ORDER BY objects.objectTitle 
				LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';
			}
		} elseif (USER_ACCESS_LEVEL <= 30) {
			if (SEARCH_IN_FULL_TEXT) {
				$sql = 'SELECT objects.objectID 
				FROM objects, objectTypes 
				WHERE MATCH(
				objects.objectTitle, 
				objects.objectCreator, 
				objects.objectSubject, 
				objects.objectDescription, 
				objects.objectData, 
				objects.objectDate
				) AGAINST(
				"'.$searchString.'"
				) 
				AND objects.objectTypeID = objectTypes.objectTypeID 
				AND objectTypes.objectTypeActive = 1 
				AND objects.objectActive = 1 
				AND objects.objectPermissionID >= 30';
				$resultTotal = $db->dbQuery($sql);
				
				$sql = 'SELECT * 
				FROM objects, objectTypes 
				WHERE MATCH(
				objects.objectTitle, 
				objects.objectCreator, 
				objects.objectSubject, 
				objects.objectDescription, 
				objects.objectData, 
				objects.objectDate
				) AGAINST(
				"'.$searchString.'"
				) 
				AND objects.objectTypeID = objectTypes.objectTypeID 
				AND objectTypes.objectTypeActive = 1 
				AND objects.objectActive = 1 
				AND objects.objectPermissionID >= 30 
				LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';
			} else {
				$sql = 'SELECT * FROM objects, objectTypes 
				WHERE (
				objects.objectTitle LIKE "%'.$searchString.'%" 
				OR objects.objectCreator LIKE "%'.$searchString.'%" 
				OR objects.objectSubject LIKE "%'.$searchString.'%" 
				OR objects.objectDescription LIKE "%'.$searchString.'%" 
				OR objects.objectData LIKE "%'.$searchString.'%" 
				OR objects.objectDate LIKE "%'.$searchString.'%"
				) 
				AND objects.objectTypeID = objectTypes.objectTypeID 
				AND objectTypes.objectTypeActive = 1 
				AND objects.objectActive = 1 
				AND objects.objectPermissionID >= 30';
				$resultTotal = $db->dbQuery($sql);

				$sql = 'SELECT * FROM objects, objectTypes 
				WHERE (
				objects.objectTitle LIKE "%'.$searchString.'%" 
				OR objects.objectCreator LIKE "%'.$searchString.'%" 
				OR objects.objectSubject LIKE "%'.$searchString.'%" 
				OR objects.objectDescription LIKE "%'.$searchString.'%" 
				OR objects.objectData LIKE "%'.$searchString.'%" 
				OR objects.objectDate LIKE "%'.$searchString.'%"
				) 
				AND objects.objectTypeID = objectTypes.objectTypeID 
				AND objectTypes.objectTypeActive = 1 
				AND objects.objectActive = 1 
				AND objects.objectPermissionID >= 30 
				ORDER BY objects.objectTitle 
				LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';
			}
		}
		$this->totalResults = mysql_num_rows($resultTotal);
		$result = $db->dbQuery($sql);
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">[no search results found]</div>';
			return FALSE;
		}
		while ($row = mysql_fetch_assoc($result)) {
			$this->simpleSearchResults[] = $row;
		}
		return TRUE;
	}
	
	function advancedSearch($searchString, $categoryIDs, $objectTypeIDs, $fileTypes, $userIDs, $page)
	{
		global $db;

		settype($searchString, 'string');
		settype($page, 'integer');
		
		$searchString = prepStr($searchString, 1);
		
		if (!$searchString && !is_array($categoryIDs) && !is_array($objectTypeIDs) && !is_array($fileTypes) && !is_array($userIDs)) {
			$this->alert = '<div class="error">[no search parameters given]</div>';
			return FALSE;
		}
		
		// Prepare the searchString WHERE clause.
		if ($searchString) {
			if (SEARCH_IN_FULL_TEXT) {
				$where_searchString = ' MATCH (
				objects.objectTitle, 
				objects.objectCreator, 
				objects.objectSubject, 
				objects.objectDescription, 
				objects.objectData, 
				objects.objectDate
				) AGAINST (
				"'.$searchString.'"
				)';
			} else {
				$where_searchString = ' (
				objects.objectTitle LIKE "%'.$searchString.'%" 
				OR objects.objectCreator LIKE "%'.$searchString.'%" 
				OR objects.objectSubject LIKE "%'.$searchString.'%" 
				OR objects.objectDescription LIKE "%'.$searchString.'%" 
				OR objects.objectData LIKE "%'.$searchString.'%" 
				OR objects.objectDate LIKE "%'.$searchString.'%"
				)';
			}
		}
		
		// Prepare the categoryIDs WHERE clause.
		if (is_array($categoryIDs)) {
			$where_categoryIDs = ' (';
			foreach ($categoryIDs as $categoryID) {
				$where_categoryIDs .= 'objects_objectCategories.objectCategoryID = '.$categoryID.' OR ';
			}
			$where_categoryIDs = substr($where_categoryIDs, 0, -4).')';
		}
		
		// Prepare the objectTypeIDs WHERE clause.
		if (is_array($objectTypeIDs)) {
			$where_objectTypeIDs = ' (';
			foreach ($objectTypeIDs as $objectTypeID) {
				$where_objectTypeIDs .= 'objectTypes.objectTypeID = '.$objectTypeID.' OR ';
			}
			$where_objectTypeIDs = substr($where_objectTypeIDs, 0, -4).')';
		}
		
		// Prepare the fileTypes WHERE clause.
		if (is_array($fileTypes)) {
			$where_fileTypes = ' (';
			foreach ($fileTypes as $fileType) {
				$where_fileTypes .= 'objectFiles.objectFileType = "'.$fileType.'" OR ';
			}
			$where_fileTypes = substr($where_fileTypes, 0, -4).')';
		}
		
		// Prepare the userIDs WHERE clause.
		if (is_array($userIDs)) {
			$where_userIDs = ' (';
			foreach ($userIDs as $userID) {
				$where_userIDs .= 'objects.objectUserID = '.$userID.' OR ';
			}
			$where_userIDs = substr($where_userIDs, 0, -4).')';
		}
		
		// Build the SQL statement using LEFT JOINs, and include any WHERE clauses.
		$sql = 'SELECT DISTINCT(objects.objectID), objects.objectTypeID, objects.objectTitle, objects.objectDescription 
		FROM objects 
		LEFT JOIN objects_objectCategories 
		ON objects.objectID = objects_objectCategories.objectID 
		LEFT JOIN objectTypes 
		ON objects.objectTypeID = objectTypes.objectTypeID 
		LEFT JOIN objectFiles 
		ON objects.objectID = objectFiles.objectFileObjectID 
		WHERE';
		if ($searchString) {
			$sql .= $where_searchString;
		}
		if ($searchString && (is_array($categoryIDs) || is_array($objectTypeIDs) || is_array($fileTypes) || is_array($userIDs))) {
			$sql .= ' AND';
		}
		if (is_array($categoryIDs)) {
			$sql .= $where_categoryIDs;
		}
		if (is_array($categoryIDs) && (is_array($objectTypeIDs) || is_array($fileTypes) || is_array($userIDs))) {
			$sql .= ' AND';
		}
		if (is_array($objectTypeIDs)) {
			$sql .= $where_objectTypeIDs;
		}
		if (is_array($objectTypeIDs) && (is_array($fileTypes) || is_array($userIDs))) {
			$sql .= ' AND';
		}
		if (is_array($fileTypes)) {
			$sql .= $where_fileTypes;
		}
		if (is_array($fileTypes) && is_array($userIDs)) {
			$sql .= ' AND';
		}
		if (is_array($userIDs)) {
			$sql .= $where_userIDs;
		}
				
		// Find the total number of results.
		$resultTotal = $db->dbQuery($sql);
		$this->totalResults = mysql_num_rows($resultTotal);
		
		// Append the limited results to the SQL for each permission level.
		if (USER_ACCESS_LEVEL <= 1) {
			$sql .= ' ORDER BY objects.objectTitle 
			LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';
		} elseif (USER_ACCESS_LEVEL <= 10) {
			$sql .= ' AND objects.objectPermissionID >= 10 
			ORDER BY objects.objectTitle 
			LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';
		} elseif (USER_ACCESS_LEVEL <= 20) {
			$sql .= ' AND objectTypes.objectTypeActive = 1 
			AND objects.objectActive = 1 
			AND objects.objectPermissionID >= 20 
			ORDER BY objects.objectTitle 
			LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';
		} elseif (USER_ACCESS_LEVEL <= 30) {
			$sql .= ' AND objectTypes.objectTypeActive = 1 
			AND objects.objectActive = 1 
			AND objects.objectPermissionID >= 30 
			ORDER BY objects.objectTitle 
			LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';
		}	
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">[no search results found]</div>';
			return FALSE;
		}
		
		while ($row = mysql_fetch_assoc($result)) {
			$this->advSearchResults[] = $row;
		}
		
		return TRUE;
	}
	
	function getAllCategories()
	{
		global $db;
		
		$sql = 'SELECT * 
		FROM objectCategories 
		ORDER BY objectCategoryName';
		$result = $db->dbQuery($sql);
		
		return $result;
	}
	
	function getAllObjectTypes()
	{
		global $db;
		
		$sql = 'SELECT * 
		FROM objectTypes 
		ORDER BY objectTypeName';
		$result = $db->dbQuery($sql);
		
		return $result;
	}
	
	function getAllFileTypes()
	{
		global $db;
		
		$sql = 'SELECT DISTINCT(objectFileType) 
		FROM objectFiles 
		ORDER BY objectFileType';
		$result = $db->dbQuery($sql);
		
		return $result;
	}
	
	function getAllUsers()
	{
		global $db;
		
		$sql = 'SELECT * 
		FROM users 
		ORDER BY userUsername';
		$result = $db->dbQuery($sql);
		
		return $result;
	}
}
?>