<?php
class User
{
	var $alert;
	var $userArray;
	var $usersArray = array();
	
	// Constructor that initializes non-constant user attributes.
	function User()
	{
	}

	function getUser($userID)
	{
		global $db;
		
		settype($userID, 'integer');
		
		$sql = 'SELECT * 
		FROM users 
		WHERE userID = '.$userID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: there is no user by that ID.</div>';
			return FALSE;
		}
		
		$row = mysql_fetch_assoc($result);
		$this->userArray = array(
								'userID' => $row['userID'], 
								'userUsername' => $row['userUsername'], 
								'userPassword' => $row['userPassword'], 
								'userFName' => $row['userFName'], 
								'userLName' => $row['userLName'], 
								'userEmail' => $row['userEmail'], 
								'userInstitution' => $row['userInstitution'], 
								'userPermission' => $this->getPermissions($row['userPermissionID']), 
								'userActive' => $row['userActive']
								);
		return TRUE;
	}
	
	function getUsers()
	{
		global $db;
				
		$sql = 'SELECT * 
		FROM users 
		ORDER BY userActive DESC, userUsername';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			return FALSE;
		}
		
		while ($row = mysql_fetch_assoc($result)) {
			$this->usersArray[] = array(
									'userID' => $row['userID'], 
									'userUsername' => $row['userUsername'], 
									'userPassword' => $row['userPassword'], 
									'userFName' => $row['userFName'], 
									'userLName' => $row['userLName'], 
									'userEmail' => $row['userEmail'], 
									'userInstitution' => $row['userInstitution'], 
									'userPermission' => $this->getPermissions($row['userPermissionID']), 
									'userActive' => $row['userActive']
									);
		}
		return TRUE;
	}
	
	
	function getPermissions($permissionID)
	{
		global $db;
		
		$sql = 'SELECT * 
		FROM permissions 
		WHERE permissionID = '.$permissionID.'';
		$result = $db->dbQuery($sql);
		
		$row = mysql_fetch_assoc($result);
		return array(
					'permissionID' => $row['permissionID'],
					'permissionName' => $row['permissionName'],
					'permissionDescription' => $row['permissionDescription'],
					);
	}
	
	function editUser($userID)
	{
		global $db;
		
		settype($userID, 'integer');
		
		if (!$this->getUser($userID)) {
			return FALSE;
		}
		
		$userFName 			= prepStr($_REQUEST['userFName'], 2);
		$userLName 			= prepStr($_REQUEST['userLName'], 2);
		$userEmail 			= prepStr($_REQUEST['userEmail'], 2);
		$userInstitution 	= prepStr($_REQUEST['userInstitution'], 2);
		$userPermissionID 	= prepStr($_REQUEST['userPermissionID'], 2);

		$sql = 'UPDATE users 
		SET userFName = "'.$userFName.'", 
		userLName = "'.$userLName.'", 
		userEmail = "'.$userEmail.'", 
		userInstitution = "'.$userInstitution.'", 
		userPermissionID = "'.$userPermissionID.'" 
		WHERE userID = '.$userID.'';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">The user was successfully edited.</div>';
		return TRUE;
	}
	
	function editPassword($userID)
	{
		global $db;

		settype($userID, 'integer');
		
		if (!$this->getUser($userID)) {
			return FALSE;
		}
		
		if ($_REQUEST['userPassword1'] != $_REQUEST['userPassword2']) {
			$this->alert = '<div class="error">ERROR: The supplied passwords were not identical.</div>';
			return FALSE;
		}
		
		if (strlen($_REQUEST['userPassword1']) < 4) {
			$this->alert = '<div class="error">ERROR: The password must be at least four characters long.</div>';
			return FALSE;
		}
		
		$userPassword = prepStr($_REQUEST['userPassword1'], 2);
		
		$sql = 'UPDATE users 
		SET userPassword = MD5("'.$userPassword.'") 
		WHERE userID = '.$userID.'';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">The password was successfully edited.</div>';
		return TRUE;
	}
	
	function addUser()
	{
		global $db;
		
		$sql = 'SELECT * 
		FROM users 
		WHERE userUsername = "'.prepStr($_REQUEST['userUsername'], 2).'"';
		$result = $db->dbQuery($sql);
		
		if (mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: The username "'.prepStr($_REQUEST['userUsername'], 5).'" has already been taken.</div>';
			return FALSE;
		}
		
		if (strlen($_REQUEST['userUsername']) < 4) {
			$this->alert = '<div class="error">ERROR: The username must be at least four characters long.</div>';
			return FALSE;
		}
		
		if ($_REQUEST['userPassword1'] != $_REQUEST['userPassword2']) {
			$this->alert = '<div class="error">ERROR: The supplied passwords were not identical.</div>';
			return FALSE;
		}
		
		if (strlen($_REQUEST['userPassword1']) < 4) {
			$this->alert = '<div class="error">ERROR: The password must be at least four characters long.</div>';
			return FALSE;
		}
		
		$userUsername 		= prepStr($_REQUEST['userUsername'], 2);
		$userPassword 		= prepStr($_REQUEST['userPassword'], 2);
		$userFName 			= prepStr($_REQUEST['userFName'], 2);
		$userLName 			= prepStr($_REQUEST['userLName'], 2);
		$userEmail 			= prepStr($_REQUEST['userEmail'], 2);
		$userInstitution 	= prepStr($_REQUEST['userInstitution'], 2);
		$userPermissionID 	= prepStr($_REQUEST['userPermissionID'], 2);
		
		$sql = 'INSERT INTO users (
		userUsername, 
		userPassword, 
		userFName, 
		userLName, 
		userEmail, 
		userInstitution, 
		userPermissionID, 
		userActive
		) VALUES (
		"'.$userUsername.'", 
		"'.$userPassword.'", 
		"'.$userFName.'", 
		"'.$userLName.'", 
		"'.$userEmail.'", 
		"'.$userInstitution.'", 
		"'.$userPermissionID.'", 
		1
		)';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">The user was successfully added.</div>';
		return TRUE;
	}

	function deactivateUser($userID)
	{
		global $db;
		
		settype($userID, 'integer');
		
		if (!$this->getUser($userID)) {
			return FALSE;
		}
		
		$sql = 'UPDATE users 
		SET userActive = 0 
		WHERE userID = '.$userID.'';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">The user was successfully deactivated.</div>';
		return TRUE;
	}
	
	function activateUser($userID)
	{
		global $db;
		
		settype($userID, 'integer');
		
		if (!$this->getUser($userID)) {
			return FALSE;
		}
		
		$sql = 'UPDATE users 
		SET userActive = 1 
		WHERE userID = '.$userID.'';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">The user was successfully activated.</div>';
		return TRUE;
	}

	// Function that authenticates the user login.
	function authenticateUser()
	{
		global $db;
		
		$sql = 'SELECT * 
		FROM users 
		WHERE userUsername = "'.trim($_POST['userUsername']).'" 
		AND userPassword = MD5("'.trim($_POST['userPassword']).'") 
		AND userActive = 1';
		$result = $db->dbQuery($sql);
		
		if (mysql_num_rows($result)) {
			$row = mysql_fetch_assoc($result);
			
			$_SESSION[DB_NAME.'_userID']			= $row['userID'];
			$_SESSION[DB_NAME.'_userUsername']		= $row['userUsername'];
			$_SESSION[DB_NAME.'_userFName']			= $row['userFName'];
			$_SESSION[DB_NAME.'_userLName']			= $row['userLName'];
			$_SESSION[DB_NAME.'_userPermissionID']	= $row['userPermissionID'];
			
			setcookie(DB_NAME, $row['userPassword'].';;'.$row['userID'].';;'.$row['userUsername'].';;'.$row['userFName'].';;'.$row['userLName'].';;'.$row['userPermissionID']);
		}
	}
	
	// Function that logs out the user.
	function logoutUser()
	{
		unset(
			$_SESSION[DB_NAME.'_userID'], 
			$_SESSION[DB_NAME.'_userUsername'], 
			$_SESSION[DB_NAME.'_userFName'], 
			$_SESSION[DB_NAME.'_userLName'], 
			$_SESSION[DB_NAME.'_userPermissionID']
			);
		if (isset($_COOKIE[DB_NAME])) {
	   		setcookie(DB_NAME, '', time() - 42000);
		}
	}
	
	// Function that sets the access (permission level) of the user.
	function userAccessLevel()
	{
		if (isset($_SESSION[DB_NAME.'_userPermissionID'])) {
			switch ($_SESSION[DB_NAME.'_userPermissionID']) {
				case 1: // super user
					$level = 1;
					break;
				case 10: // administrator
					$level = 10;
					break;
				case 20: // researcher
					$level = 20;
					break;
				default: // public
					$level = 30;
					break;
			}
		} else {
			$level = 30; // public
		}
		
		return $level;
	}
	
	function checkUserExists($cookie)
	{
		global $db;
		
		$sql = 'SELECT * 
		FROM users 
		WHERE userPassword = "'.$cookie[0].'" 
		AND userID = "'.$cookie[1].'" 
		AND userUsername = "'.$cookie[2].'" 
		AND userPermissionID = "'.$cookie[5].'"';
		$result = $db->dbQuery($sql);
		
		if (mysql_num_rows($result)) {
			return TRUE;
		} else {
			return FALSE;
		}
	}
}
?>