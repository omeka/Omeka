<?php
class Object
{
	// Alert attribute.
	var $alert;
	
	// Object attributes.
	var $objectID;
	var $objectTypeID;
	var $objectPermissionID;
	var $objectUserID;
	var $objectTitle;
	var $objectCreator;
	var $objectSubject;
	var $objectDescription;
	var $objectDate;
	var $objectData;
	var $objectModified;
	var $objectAdded;
	var $objectActive;
	
	// Object Type attributes.
	var $objectType = array();
	var $objectTypeMetadataDump = array();

	// Object permission attribute.
	var $objectPermission = array();
	
	// Object user attribute.
	var $objectUser = array();
	
	// Object metadata attribute.
	var $objectMetadata = array();
	var $objectDataTypeMetadata = array();

	// Object Files attribute.
	var $objectFiles = array();

	// Object categories attribute.
	var $objectCategories = array();
	
	// Object notes attribute.
	var $getObjectNotes = array();
	
	
	// Constructor that initializes non-constant object attributes.
	function Object()
	{
	}
	
	// Function that gets the object's metadata.
	function getObject($objectID)
	{
		global $db;
		
		// Set the type to an integer.
		settype($objectID, 'integer');
		
		if (USER_ACCESS_LEVEL <= 1) {
			$sql = 'SELECT *, 
			DATE_FORMAT(objectModified, "%e %M %Y, %l:%i%p") AS modified, 
			DATE_FORMAT(objectAdded, "%e %M %Y, %l:%i%p") AS added 
			FROM objects 
			WHERE objectID = '.$objectID.'';
		} elseif (USER_ACCESS_LEVEL <= 10) {
			$sql = 'SELECT *, 
			DATE_FORMAT(objectModified, "%e %M %Y, %l:%i%p") AS modified, 
			DATE_FORMAT(objectAdded, "%e %M %Y, %l:%i%p") AS added 
			FROM objects 
			WHERE objectID = '.$objectID.' 
			AND objects.objectPermissionID >= 10';
		} elseif (USER_ACCESS_LEVEL <= 20) {
		// Prevent non-admins from seeing objects that are inactive in all assigned categories.
			$sql = 'SELECT *, 
			DATE_FORMAT(objects.objectModified, "%e %M %Y, %l:%i%p") AS modified, 
			DATE_FORMAT(objects.objectAdded, "%e %M %Y, %l:%i%p") AS added 
			FROM objects, objectTypes 
			WHERE objects.objectID = '.$objectID.' 
			AND objects.objectTypeID = objectTypes.objectTypeID 
			AND objectTypes.objectTypeActive = 1 
			AND objects.objectActive = 1 
			AND objects.objectPermissionID >= 20';
		} elseif (USER_ACCESS_LEVEL <= 30) {
			$sql = 'SELECT *, 
			DATE_FORMAT(objects.objectModified, "%e %M %Y, %l:%i%p") AS modified, 
			DATE_FORMAT(objects.objectAdded, "%e %M %Y, %l:%i%p") AS added 
			FROM objects, objectTypes 
			WHERE objects.objectID = '.$objectID.' 
			AND objects.objectTypeID = objectTypes.objectTypeID 
			AND objectTypes.objectTypeActive = 1 
			AND objects.objectActive = 1 
			AND objects.objectPermissionID >= 30';
		}
		$result = $db->dbQuery($sql);
		
		// Check if there is an object by the supplied ID.
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There is no object with that ID number.</div>';
			return FALSE;
		}
			
		$row = mysql_fetch_assoc($result);
		// DO NOT CHANGE THE ORDER BELOW. Population order is vital to a working script.
		// Populate the object attributes.
		$this->objectID 			= $objectID; // Set the object ID to whatever was passed.
		$this->objectTypeID 		= $row['objectTypeID'];
		$this->objectPermissionID 	= $row['objectPermissionID'];
		$this->objectUserID 		= $row['objectUserID'];
		$this->objectTitle 			= $row['objectTitle'];
		$this->objectCreator 		= $row['objectCreator'];
		$this->objectSubject 		= $row['objectSubject'];
		$this->objectDescription 	= $row['objectDescription'];
		$this->objectDate 			= $row['objectDate'];
		$this->objectData 			= $row['objectData'];
		$this->objectModified 		= $row['modified'];
		$this->objectAdded 			= $row['added'];
		$this->objectActive 		= $row['objectActive'];
		// Populate the object type attribute.
		$this->getObjectType();
		// Populate the object permission attribute.
		$this->getObjectPermission();
		// Populate the object user attribute.
		$this->getObjectUser();
		// Populate the object metadata attribute.
		$this->getObjectMetadata();
		// Populate the object files attribute.
		$this->getObjectFiles();
		// Populate the object categories attribute.
		$this->getObjectCategories();
		// Populate the object notes attribute.
		$this->getObjectNotes();
		
		return TRUE;
	}
	
	function getObjectType()
	{
		global $db;
		$sql = 'SELECT * 
		FROM objectTypes 
		WHERE objectTypeID = '.$this->objectTypeID.'';
		$result = $db->dbQuery($sql);
		$row = mysql_fetch_assoc($result);
		$this->objectType = array(
							$row['objectTypeName'], 
							$row['objectTypeTableName'], 
							$row['objectTypeTemplateFileName'], 
							$row['objectTypeDescription'], 
							$row['objectTypeActive'], 
							$row['objectTitleDescription'], 
							$row['objectDescriptionDescription'], 
							$row['objectCreatorDescription'], 
							$row['objectSubjectDescription'], 
							$row['objectDateDescription'], 
							);
		// Unserialize the objectTypeMetadataDump.
		$this->objectTypeMetadataDump = unserialize($row['objectTypeMetadataDump']);
	}
	
	function getObjectPermission()
	{
		global $db;
		$sql = 'SELECT * 
		FROM permissions 
		WHERE permissionID = '.$this->objectPermissionID.'';
		$result = $db->dbQuery($sql);
		$row = mysql_fetch_assoc($result);
		$this->objectPermission = array(
							$row['permissionID'], 
							$row['permissionName'], 
							$row['permissionDescription']
							);
	}
	
	function getObjectUser()
	{
		global $db;
		$sql = 'SELECT * 
		FROM users 
		WHERE userID = '.$this->objectUserID.'';
		$result = $db->dbQuery($sql);
		$row = mysql_fetch_assoc($result);
		$this->objectUser = array(
						$row['userUsername'], 
						$row['userFName'], 
						$row['userLName'], 
						$row['userEmail'], 
						$row['userActive'], 
						$row['userInstitution']
						);
	}
	
	function getObjectMetadata()
	{
		global $db;
		$sql = 'SELECT * 
		FROM '.$this->objectType[1].' 
		WHERE objectID = '.$this->objectID.'';
		$result = $db->dbQuery($sql);
		$row = mysql_fetch_assoc($result);
		$this->objectMetadata = $row;
		
		// Get the data type of the input fields. This is to determine the input types.
		$sql = 'DESCRIBE '.$this->objectType[1];
		$result = $db->dbQuery($sql);
		while ($row = mysql_fetch_assoc($result)) {
			$this->objectDataTypeMetadata[] = $row;
		}
	}

	function getObjectFiles()
	{
		global $db;
		if (USER_ACCESS_LEVEL <= 10) {
			$sql = 'SELECT *, 
			DATE_FORMAT(objectFileModified, "%e %M %Y, %l:%i%p") AS fileModified, 
			DATE_FORMAT(objectFileAdded, "%e %M %Y, %l:%i%p") AS fileAdded 
			FROM objectFiles 
			WHERE objectFileObjectID = '.$this->objectID.'';
		} elseif (USER_ACCESS_LEVEL <= 20) {
				$sql = 'SELECT *, 
			DATE_FORMAT(objectFileModified, "%e %M %Y, %l:%i%p") AS fileModified, 
			DATE_FORMAT(objectFileAdded, "%e %M %Y, %l:%i%p") AS fileAdded 
			FROM objectFiles 
			WHERE objectFileObjectID = '.$this->objectID.' 
			AND objectFileActive = 1';
		} elseif (USER_ACCESS_LEVEL <= 30) {
			$sql = 'SELECT *, 
			DATE_FORMAT(objectFileModified, "%e %M %Y, %l:%i%p") AS fileModified, 
			DATE_FORMAT(objectFileAdded, "%e %M %Y, %l:%i%p") AS fileAdded 
			FROM objectFiles 
			WHERE objectFileObjectID = '.$this->objectID.' 
			AND objectFileActive = 1';
		}
		$sql .= ' ORDER BY objectFileActive DESC, objectFileName';
		$result = $db->dbQuery($sql);
		while ($row = mysql_fetch_assoc($result)) {
			$this->objectFiles[] = array(
									$row['objectFileID'], 
									$row['objectFileName'], 
									$row['objectFileDescription'], 
									$row['objectFileType'], 
									$row['objectFileSize'], 
									$row['objectFileModified'], 
									$row['objectFileAdded'], 
									$row['objectFileActive'], 
									$row['objectFileOriginalName']
									);
		}
	}

	function getObjectCategories()
	{
		global $db;
		
		if (USER_ACCESS_LEVEL <= 10) {
			$sql = 'SELECT objectCategories.objectCategoryID, 
			objectCategories.objectCategoryName 
			FROM objects, objects_objectCategories, objectCategories 
			WHERE objects.objectID = objects_objectCategories.objectID 
			AND objectCategories.objectCategoryID = objects_objectCategories.objectCategoryID 
			AND objects.objectID = '.$this->objectID.' 
			ORDER BY objects.objectActive DESC, 
			objectCategories.objectCategoryName';
		} elseif (USER_ACCESS_LEVEL <= 20) {
			$sql = 'SELECT objectCategories.objectCategoryID, 
			objectCategories.objectCategoryName 
			FROM objects, objects_objectCategories, objectCategories 
			WHERE objects.objectID = objects_objectCategories.objectID 
			AND objectCategories.objectCategoryID = objects_objectCategories.objectCategoryID 
			AND objects.objectID = '.$this->objectID.' 
			AND objects.objectActive = 1';
		} elseif (USER_ACCESS_LEVEL <= 30) {
			$sql = 'SELECT objectCategories.objectCategoryID, 
			objectCategories.objectCategoryName 
			FROM objects, objects_objectCategories, objectCategories 
			WHERE objects.objectID = objects_objectCategories.objectID 
			AND objectCategories.objectCategoryID = objects_objectCategories.objectCategoryID 
			AND objects.objectID = '.$this->objectID.' 
			AND objects.objectActive = 1';
		}
		$result = $db->dbQuery($sql);
		while ($row = mysql_fetch_assoc($result)) {
			$this->objectCategories[] = array(
										$row['objectCategoryID'], 
										$row['objectCategoryName']
										);
		}
	}
	
	function getObjectNotes()
	{
		global $db;
		
		$sql = 'SELECT *, 
		DATE_FORMAT(objectNoteAdded, "%e %M %Y, %l:%i%p") AS objectNoteAdded 
		FROM objectNotes 
		WHERE objectNoteObjectID = '.$this->objectID.' 
		AND objectNotePermissionID >= '.USER_ACCESS_LEVEL.'';	
		$result = $db->dbQuery($sql);
		
		while ($row = mysql_fetch_assoc($result)) {
			$this->objectNotes[] = array(
									$row['objectNoteID'], 
									$row['objectNoteObjectID'], 
									$row['objectNoteUserID'], 
									$row['objectNotePermissionID'], 
									$row['objectNoteText'], 
									$row['objectNoteModified'], 
									$row['objectNoteAdded']
									);
		}
	}
	
	// Function that deactivates an object.
	function deactivateObject($objectID)
	{
		global $db;
		
		settype($objectID, 'integer');
		
		// First check to see if the object/category link exists.
		$sql = 'SELECT * 
		FROM objects 
		WHERE objectID = '.$objectID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: The object ID is invalid.</div>';
			return FALSE;
		}
		
		// Then deactivate the object.
		$sql = 'UPDATE objects 
		SET objectActive = 0 
		WHERE objectID = '.$objectID.'';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">The object was deactivated.</div>';
		return TRUE;
	}
	
	// Function that activates an object.
	function activateObject($objectID)
	{
		global $db;
		
		settype($objectID, 'integer');

		// First check to see if the object/category link exists.
		$sql = 'SELECT * 
		FROM objects 
		WHERE objectID = '.$objectID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: The object ID is invalid.</div>';
			return FALSE;
		}
		
		// Then deactivate the object.
		$sql = 'UPDATE objects 
		SET objectActive = 1 
		WHERE objectID = '.$objectID.'';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">The object was activated.</div>';
		return TRUE;
	}
	
	// This function is generalized in order to allow extensibility.
	function ingestObject()
	{
		global $db;
		
		// Then get the table name of the selected object type. 
		$sql = 'SELECT * 
		FROM objectTypes 
		WHERE objectTypeID = '.$_POST['objectTypeID'].'';
		$result = $db->dbQuery($sql);
		$row = mysql_fetch_assoc($result);
		$tableName = $row['objectTypeTableName'];
		
		// Then get the column names and the primary key name.
		$sql = 'SHOW COLUMNS FROM '.$tableName.'';
		$result = $db->dbQuery($sql);
		$row = mysql_fetch_assoc($result);
		$primaryKeyName = $row['Field'];

		// Then insert a new row into the correct table and get the last inserted ID.
		$sql = 'INSERT INTO '.$tableName.' (
		'.$primaryKeyName.'
		) VALUES (
		NULL
		)';
		$db->dbQuery($sql);
		$objectTypeInsertID = mysql_insert_id();
		
		// Then iterate through the column names, which should match up to the form element names, and update the row for each column.
		while ($row = mysql_fetch_assoc($result)) {
			foreach ($_POST as $fieldName => $data) {
				if ($row['Field'] == $fieldName) {
					$sql = 'UPDATE '.$tableName.' 
					SET '.$fieldName.' = "'.$data.'" 
					WHERE '.$primaryKeyName.' = '.$objectTypeInsertID.'';
					$db->dbQuery($sql);
				}
			}
		}
		
		// Then insert the general object metadata.
		$sql = 'INSERT INTO objects (
		objectTypeID, 
		objectPermissionID, 
		objectUserID, 
		objectTitle, 
		objectCreator, 
		objectSubject, 
		objectDescription, 
		objectDate, 
		objectData, 
		objectModified, 
		objectAdded, 
		objectActive
		) VALUES (
		'.$_POST['objectTypeID'].', 
		'.$_POST['objectPermissionID'].', 
		'.$_SESSION[DB_NAME.'_userID'].', 
		"'.prepStr($_POST['objectTitle'], 2).'", 
		"'.prepStr($_POST['objectCreator'], 2).'", 
		"'.prepStr($_POST['objectSubject'], 2).'", 
		"'.prepStr($_POST['objectDescription'], 2).'", 
		"'.prepStr($_POST['objectDate'], 2).'", 
		"'.prepStr($_POST['objectData'], 2).'", 
		NOW(), 
		NOW(), ';
		// Activate or deactivate the object according to the REVIEW_OBJECTS configuration.
		if (REVIEW_OBJECTS) {
			$sql .= '0';
		} else {
			$sql .= '1';
		}
		$sql .= ')';
		$db->dbQuery($sql);
		$objectInsertID = mysql_insert_id();
		
		// Then make the object relationships.
		$sql = 'UPDATE '.$tableName.' 
		SET objectID = '.$objectInsertID.' 
		WHERE '.$primaryKeyName.' = '.$objectTypeInsertID.'';
		$db->dbQuery($sql);
				
		// Then call the upload file method.
		$this->uploadFile($objectInsertID);
		
		// Build the appropriate message.
		$this->alert .= '<div class="alert">The object was successfully entered into the database.';
		if (USER_ACCESS_LEVEL <= 10) {
			$this->alert .= ' Click <a href="archive.php">here</a> to assign the object to categories.';
		} else {
			if (REVIEW_OBJECTS) {
				$this->alert .= ' It must first be reviewed by an administrator before being accepted. Please check back later.';
			} else {
				$this->alert .= ' You may view it by clicking <a href="archive.php">here</a>.';
			}
		}
		$this->alert .= '</div>';
		return TRUE;
	}
	
	function editObject()
	{
		global $db;
		
		// First get the table name of the selected object type. 
		$sql = 'SELECT * 
		FROM objectTypes 
		WHERE objectTypeID = '.$_POST['objectTypeID'].'';
		$result = $db->dbQuery($sql);
		$row = mysql_fetch_assoc($result);
		$tableName = $row['objectTypeTableName'];

		// Then get the column names and the primary key name.
		$sql = 'SHOW COLUMNS FROM '.$tableName.'';
		$result = $db->dbQuery($sql);
		$row = mysql_fetch_assoc($result);
		$primaryKeyName = $row['Field'];
				
		// Then iterate through the column names, which should match up to the form element names, 
		// and update the row for each column.
		while ($row = mysql_fetch_assoc($result)) {
			foreach ($_POST as $fieldName => $data) {
				if ($row['Field'] == $fieldName) {
					$sql = 'UPDATE '.$tableName.' 
					SET '.$fieldName.' = "'.$data.'" 
					WHERE objectID = '.$_POST['objectID'].'';
					$db->dbQuery($sql);
				}
			}
		}
		
		// Then update the general object metadata.
		$sql = 'UPDATE objects 
		SET objectTitle = "'.prepStr($_POST['objectTitle'], 2).'", 
		objectCreator = "'.prepStr($_POST['objectCreator'], 2).'", 
		objectSubject = "'.prepStr($_POST['objectSubject'], 2).'", 
		objectDescription = "'.prepStr($_POST['objectDescription'], 2).'", 
		objectDate = "'.prepStr($_POST['objectDate'], 2).'", 
		objectData = "'.prepStr($_POST['objectData'], 2).'", 
		objectPermissionID = "'.$_POST['objectPermissionID'].'", 
		objectModified = NOW() 
		WHERE objectID = '.$_POST['objectID'].'';
		$db->dbQuery($sql);
		
		// Then update the file descriptions.
		if (is_array($_POST['objectFileDescriptionEdit'])) {
			foreach ($_POST['objectFileDescriptionEdit'] as $key => $value) {
				$sql = 'UPDATE objectFiles 
				SET objectFileDescription = "'.prepStr($value, 2).'" 
				WHERE objectFileID = '.$key.'';
				$db->dbQuery($sql);
			}
		}
		
		// Then call the upload file method.
		$this->uploadFile($_POST['objectID']);
		
		$this->alert .= '<div class="alert">The object was successfully edited.</div>';
		return TRUE;
	}
	
	function uploadFile($objectID)
	{
		global $db;
		
		// Upload the associated file(s) and insert metadata.
		$i = 1;
		foreach ($_FILES as $fileArray) {
			if (is_array($fileArray)) {
				
				// Check for file upload errors.
				if ($fileArray['error'] == 1) {
					$this->alert .= '<div class="error">ERROR: The uploaded file "'.$fileArray['name'].'" exceeds the upload_max_filesize directive.</div>';
				} elseif ($fileArray['error'] == 2) {
					$this->alert .= '<div class="error">ERROR: The uploaded file "'.$fileArray['name'].'" exceeds the MAX_FILE_SIZE directive.</div>';
				} elseif ($fileArray['error'] == 3) {
					$this->alert .= '<div class="error">ERROR: The uploaded file "'.$fileArray['name'].'" was only partially uploaded.</div>';
				// Suppress the "no file uploaded" error.
				/*
				} elseif ($fileArray['error'] == 4) {
					$this->alert .= '<div class="error">ERROR: No file was uploaded.</div>';
				*/
				// If there are no upload errors, continue handling the form.
				} elseif ($fileArray['error'] == 0) {
					// Create a unique identifier for the uploaded file.
					// If the filename has a period, process the file as if it has a file extension.
					if (strstr(basename($fileArray['name']), '.')) {
						
						// Determine the last position of the period.
						$last = strrpos(basename($fileArray['name']), '.');
						
						// Seperate the file name with the file extension, assuming that the latter is an authentic extension.
						$name = substr(basename($fileArray['name']), 0, $last);
						
						// This unique identifier algorhythm includes the formatted filename, an underscore, a truncated MD5 hash of a 
						// unique id generator based on the current time in microseconds with additional entropy, and ending with 
						// the PROVIDED and/or ASSUMED file extension. There is still a chance of file name collision, but it is negligable.
						$objectFileName = formatFileName($name).'_'.substr(md5(uniqid(rand(), TRUE)), 0, 10).strrchr(basename($fileArray['name']), '.');
					
					// If the filename does not contain a period, determine the file type using a file type registry protocol.
					// Although safer, this is arguably less helpful than provided/assumed file extensions.
					} else {
						
						// Check to see if safe mode is on, and if so shell_exec() is inaccessable, so use $_FILES[]['type'] instead.
						if (ini_get('safe_mode')) {
							$extension = substr(strrchr($fileArray['type'], '/'), 1);
						// If safe mode is off, get a more accurate extension from the shell file command.
						} else {
							preg_match('/\/[\w-]+/', shell_exec('file -bi "'.$fileArray['tmp_name'].'"'), $matches);
							if (!empty($matches)) {
								$extension = substr($matches[0], 1);
							} else {
								$extension = 'unknown';
							}
						}
						
						// This unique identifier algorhythm includes the formatted filename, an underscore, a truncated MD5 hash of a 
						// unique id generator based on the current time in microseconds with additional entropy, and ending with 
						// the INTERPRETED file extension. There is still a chance of file name collision, but it is negligable.
						$objectFileName = trim(formatFileName(basename($fileArray['name'])).'_'.substr(md5(uniqid(rand(), TRUE)), 0, 10).'.'.$extension);
					}
					
					$objectFileDescription = $_POST['objectFileDescription'];
					
					// Check to see if safe mode is on, and if so shell_exec() is inaccessable, so use $_FILES[]['type'] for the file type.
					if (ini_get('safe_mode')) {
						$fileType = $fileArray['type'];
					// If safe mode is off, get a more accurate file type from the shell file command.
					} else {
						$fileType = trim(shell_exec('file -bi "'.$fileArray['tmp_name'].'"'));
					}
					
					// Move the file to the destination directory and continue handling the form. Don't forget to strip magic quote slashes!
					if (move_uploaded_file($fileArray['tmp_name'], FILE_UPLOAD_DIRECTORY.stripslashes($objectFileName))) {
						$sql = 'INSERT INTO objectFiles (
						objectFileObjectID, 
						objectFileName, 
						objectFileOriginalName, 
						objectFileDescription, 
						objectFileType, 
						objectFileSize, 
						objectFileModified, 
						objectFileAdded, 
						objectFileActive
						) VALUES (
						'.$objectID.', 
						"'.$objectFileName.'", 
						"'.basename($fileArray['name']).'", 
						"'.prepStr($objectFileDescription[$i], 2).'", 
						"'.$fileType.'", 
						"'.$fileArray['size'].'", 
						NOW(), 
						NOW(), 
						1
						)';
						$db->dbQuery($sql);
						$this->alert .= '<div class="alert">File "'.$fileArray['name'].'" was successfully uploaded.</div>';
					} else {
						$this->alert .= '<div class="error">ERROR: File "'.$fileArray['name'].'" was not moved to the directory. Possible file upload attack!</div>';
					}
				}
			}
			$i++;			
		}
	}

	function getOrphanedObjects()
	{
		global $db;
		
		if (USER_ACCESS_LEVEL <= 1) {
			$sql = 'SELECT objects.objectID, 
			objects.objectTitle, 
			objects.objectActive, 
			DATE_FORMAT(objectAdded, "%e %M %Y, %l:%i%p") AS added, 
			objectTypes.objectTypeID, 
			objectTypes.objectTypeName, 
			permissions.permissionName, 
			users.userUsername 
			FROM objects 
			LEFT JOIN objects_objectCategories 
			ON (objects.objectID = objects_objectCategories.objectID) 
			LEFT JOIN objectTypes 
			ON (objects.objectTypeID = objectTypes.objectTypeID) 
			LEFT JOIN permissions 
			ON (objects.objectPermissionID = permissions.permissionID) 
			LEFT JOIN users 
			ON (objects.objectUserID = users.userID) 
			WHERE objects_objectCategories.objectID IS NULL 
			ORDER BY objects.objectAdded DESC';
		} elseif (USER_ACCESS_LEVEL <= 10) {
			$sql = 'SELECT objects.objectID, 
			objects.objectTitle, 
			objects.objectActive, 
			DATE_FORMAT(objectAdded, "%e %M %Y, %l:%i%p") AS added, 
			objectTypes.objectTypeID, 
			objectTypes.objectTypeName, 
			permissions.permissionName, 
			users.userUsername 
			FROM objects 
			LEFT JOIN objects_objectCategories 
			ON (objects.objectID = objects_objectCategories.objectID) 
			LEFT JOIN objectTypes 
			ON (objects.objectTypeID = objectTypes.objectTypeID) 
			LEFT JOIN permissions 
			ON (objects.objectPermissionID = permissions.permissionID) 
			LEFT JOIN users 
			ON (objects.objectUserID = users.userID) 
			WHERE objects_objectCategories.objectID IS NULL 
			AND objects.objectPermissionID >= 10 
			ORDER BY objects.objectAdded DESC';
		} elseif (USER_ACCESS_LEVEL <= 20) {
			$sql = 'SELECT objects.objectID, 
			objects.objectTitle, 
			objects.objectActive, 
			objectTypes.objectTypeID, 
			objectTypes.objectTypeName,  
			permissions.permissionName 
			FROM objects 
			LEFT JOIN objects_objectCategories 
			ON (objects.objectID = objects_objectCategories.objectID) 
			LEFT JOIN objectTypes 
			ON (objects.objectTypeID = objectTypes.objectTypeID) 
			LEFT JOIN permissions 
			ON (objects.objectPermissionID = permissions.permissionID) 
			WHERE objects_objectCategories.objectID IS NULL 
			AND objects.objectActive = 1 
			AND objectTypes.objectTypeActive = 1 
			AND objects.objectPermissionID >= 20 
			ORDER BY objectTypes.objectTypeName, objects.objectTitle';
		} elseif (USER_ACCESS_LEVEL <= 30) {
			$sql = 'SELECT objects.objectID, 
			objects.objectTitle, 
			objects.objectActive, 
			objectTypes.objectTypeID, 
			objectTypes.objectTypeName 
			FROM objects 
			LEFT JOIN objects_objectCategories 
			ON (objects.objectID = objects_objectCategories.objectID) 
			LEFT JOIN objectTypes 
			ON (objects.objectTypeID = objectTypes.objectTypeID) 
			WHERE objects_objectCategories.objectID IS NULL 
			AND objects.objectActive = 1 
			AND objectTypes.objectTypeActive = 1 
			AND objects.objectPermissionID >= 30 
			ORDER BY objectTypes.objectTypeName, objects.objectTitle';
		}
		$result = $db->dbQuery($sql);
		
		return $result;
	}
	
	function assignOrphanedObjects()
	{
		global $db;
		
		// Validate the form to make sure a the object was assigned at least one category.
		if (!is_array($_POST['assign'])) {
			$this->alert = '<div class="error">ERROR: The object(s) must be assigned to at least one category. Please try again.</div>';
			return FALSE;
		}

		// Validate the form to make sure a the object was assigned at least one category.
		if (!is_array($_POST['orphanedObjectIDs'])) {
			$this->alert = '<div class="error">ERROR: You must select at least one orphaned object to assign to a category. Please try again.</div>';
			return FALSE;
		}
		
		// Iterate through both arrays and make the object/category associations.
		foreach ($_POST['assign'] as $categoryID) {
			foreach ($_POST['orphanedObjectIDs'] as $objectID) {
				$sql = 'INSERT INTO objects_objectCategories (
				objectID, 
				objectCategoryID 
				) VALUES (
				'.$objectID.', 
				'.$categoryID.'
				)';
				$db->dbQuery($sql);
			}
		}
				
		$this->alert = '<div class="alert">The unassigned/orphaned object(s) has been assigned to the category(ies), and the object(s) have been activated.</div>';
		return TRUE;
	}

	function getAllObjectIDs()
	{
		global $db;

		$sql = 'SELECT objects.objectID 
		FROM objects, objectTypes 
		WHERE objects.objectTypeID = objectTypes.objectTypeID 
		ORDER BY objectTypes.objectTypeName, 
		objectTypes.objectTypeActive DESC, 
		objects.objectTitle';
		$result = $db->dbQuery($sql);
		
		return $result;
	}
	
	function assignAllObjects()
	{
		global $db;
	
		// Validate the form to make sure a the object was assigned at least one category.
		if (!is_array($_POST['assign'])) {
			$this->alert = '<div class="error">ERROR: The object(s) must be assigned to at least one category. Please try again.</div>';
			return FALSE;
		}

		// Validate the form to make sure a the object was assigned at least one category.
		if (!is_array($_POST['allObjectIDs'])) {
			$this->alert = '<div class="error">ERROR: You must select at least one object to assign to a category. Please try again.</div>';
			return FALSE;
		}
		
		// Iterate through both arrays and make the object/category associations.
		foreach ($_POST['assign'] as $categoryID) {
			foreach ($_POST['allObjectIDs'] as $objectID) {
				// Check to see if the object/category relationship already exists.
				$sql = 'SELECT * 
				FROM objects_objectCategories 
				WHERE objectID = '.$objectID.' 
				AND objectCategoryID = '.$categoryID.'';
				$result = $db->dbQuery($sql);
				// If not, make the relationship.
				if (!mysql_num_rows($result)) {
					$sql = 'INSERT INTO objects_objectCategories (
					objectID, 
					objectCategoryID
					) VALUES (
					'.$objectID.', 
					'.$categoryID.'
					)';
					$db->dbQuery($sql);
				}
			}
		}
				
		$this->alert .= '<div class="alert">The objects have been assigned to the categories.</div>';
		return TRUE;
	}
		
	function deactivateFile($fileID)
	{
		global $db;
		
		$sql = 'SELECT * 
		FROM objectFiles 
		WHERE objectFileID = '.$fileID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There are no files by that ID.</div>';
			return FALSE;
		}
		
		$sql = 'UPDATE objectFiles 
		SET objectFileActive = 0 
		WHERE objectFileID = '.$fileID.'';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">The file has been deactivated.</div>';
		return TRUE;
	}

	function activateFile($fileID)
	{
		global $db;
		
		$sql = 'SELECT * 
		FROM objectFiles 
		WHERE objectFileID = '.$fileID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There are no files by that ID.</div>';
			return FALSE;
		}
		
		$sql = 'UPDATE objectFiles 
		SET objectFileActive = 1 
		WHERE objectFileID = '.$fileID.'';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">The file has been re-activated.</div>';
		return TRUE;
	}
	
	function deleteObject($objectID)
	{
		global $db;
		
		// Determine if the object exists.
		$sql = 'SELECT * 
		FROM objects 
		WHERE objectID = '.$objectID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There is no object by that ID.</div>';
			return FALSE;
		}
		
		// Delete the object metadata from the objectTypes_* table.
		$row = mysql_fetch_assoc($result);
		$sql = 'SELECT objectTypeTableName 
		FROM objectTypes 
		WHERE objectTypeID = '.$row['objectTypeID'];
		$result = $db->dbQuery($sql);
		$row = mysql_fetch_assoc($result);
		$sql = 'DELETE FROM '.$row['objectTypeTableName'].' 
		WHERE objectID = '.$objectID.'';
		$db->dbQuery($sql);
		
		// Delete the object metadata from the objects table.
		$sql = 'DELETE FROM objects 
		WHERE objectID = '.$objectID.'';
		$db->dbQuery($sql);
		
		// Delete any object/category relationships.
		$sql = 'DELETE FROM objects_objectCategories 
		WHERE objectID = '.$objectID.'';
		$db->dbQuery($sql);
		
		// Deactivate any files associated with the object. Deactivate rather than delete because in the future there
		// may be an "orphaned files" page, whereby users may reassign files to other objects.
		$sql = 'UPDATE objectFiles 
		SET objectFileActive = 0, 
		objectFileObjectID = 0 
		WHERE objectFileObjectID = '.$objectID.'';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">The object has been deleted.</div>';
		return TRUE;
	}
	
	function deleteFile($objectFileID)
	{
		global $db;
		
		$sql = 'SELECT * 
		FROM objectFiles 
		WHERE objectFileID = '.$objectFileID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There is no file by that ID.</div>';
			return FALSE;
		}
		$row = mysql_fetch_assoc($result);
		
		$sql = 'DELETE FROM objectFiles 
		WHERE objectFileID = '.$objectFileID.'';
		$db->dbQuery($sql);
		
		if (@unlink(FILE_UPLOAD_DIRECTORY.$row['objectFileName'])) {
			$this->alert = '<div class="alert">The file has been deleted and its metadata has been removed.</div>';
			return TRUE;
		} else {
			$this->alert = '<div class="error">ERROR: The file was NOT deleted but its metadata has been removed.</div>';
			return FALSE;
		}
	}
	
	function removeAssociations($objectID)
	{
		global $db;
		
		// Determine if the object exists.
		$sql = 'SELECT * 
		FROM objects 
		WHERE objectID = '.$objectID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There is no object by that ID.</div>';
			return FALSE;
		}
		
		$sql = 'DELETE FROM objects_objectCategories 
		WHERE objectID = '.$objectID.'';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">This object\'s category associations have been removed.</div>';
		return TRUE;

	}
	
	function addObjectNote($objectID) {
		global $db;

		$sql = 'SELECT * 
		FROM objects 
		WHERE objectID = '.$objectID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There is no object by that ID.</div>';
			return FALSE;
		}
		
		$sql = 'INSERT INTO objectNotes (
		objectNoteObjectID, 
		objectNoteUserID, 
		objectNotePermissionID, 
		objectNoteText, 
		objectNotemodified, 
		objectNoteAdded
		) VALUES (
		'.$objectID.', 
		'.$_SESSION[DB_NAME.'_userID'].', 
		'.$_POST['objectNotePermissionID'].', 
		"'.prepStr($_POST['objectNoteText'], 2).'", 
		NOW(), 
		NOW()
		)';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">The note has been recorded.</div>';
		return TRUE;
	}
	
	function getDropboxFiles()
	{
		$d = dir(FILE_DROPBOX_DIRECTORY);
		$fileDropboxArray = array();
		while (false !== ($file = $d->read())) {
			if ($file != '.' && $file != '..') {
				$fileDropboxArray[] = $file;
			}
		}
		$d->close();
		return $fileDropboxArray;
	}
	
	function assignDropboxFile($objectID)
	{
		global $db;
		
		settype($id, 'integer');
		
		$fileName = prepStr($_REQUEST['dropboxFileName'], 5);
		
		if (!file_exists(FILE_DROPBOX_DIRECTORY.$fileName)) {
			$this->alert = '<div class="error">ERROR: The selected file is not recognized.</div>';
			return FALSE;
		}
		
		// This is a slightly modified version of the file name algorhythm from uploadFile().
		// Create a unique identifier for the file.
		// If the filename has a period, process the file as if it has a file extension.
		if (strstr(basename($fileName), '.')) {
			
			// Determine the last position of the period.
			$last = strrpos(basename($fileName), '.');
			
			// Seperate the file name with the file extension, assuming that the latter is an authentic extension.
			$name = substr(basename($fileName), 0, $last);
			
			$extension = strrchr(basename($fileName), '.');
			
			// This unique identifier algorhythm includes the formatted filename, an underscore, a truncated MD5 hash of a 
			// unique id generator based on the current time in microseconds with additional entropy, and ending with 
			// the PROVIDED and/or ASSUMED file extension. There is still a chance of file name collision, but it is negligable.
			$objectFileName = formatFileName($name).'_'.substr(md5(uniqid(rand(), TRUE)), 0, 10).$extension;
		
		// If the filename does not contain a period, determine the file type using a file type registry protocol.
		// Although safer, this is arguably less helpful than provided/assumed file extensions.
		} else {
			
			// Check to see if safe mode is on, and if so shell_exec() is inaccessable, so file type is indeterminate.
			if (ini_get('safe_mode')) {
				$extension = 'unknown';
			// If safe mode is off, get a more accurate extension from the shell file command.
			} else {
				preg_match('/\/[\w-]+/', shell_exec('file -bi '.escapeshellarg(FILE_DROPBOX_DIRECTORY.$fileName).''), $matches);
				if (!empty($matches)) {
					$extension = substr($matches[0], 1);
				} else {
					$extension = 'unknown';
				}
			}
			
			// This unique identifier algorhythm includes the formatted filename, an underscore, a truncated MD5 hash of a 
			// unique id generator based on the current time in microseconds with additional entropy, and ending with 
			// the INTERPRETED file extension. There is still a chance of file name collision, but it is negligable.
			$objectFileName = trim(formatFileName(basename($fileName)).'_'.substr(md5(uniqid(rand(), TRUE)), 0, 10).'.'.$extension);
		}
		
		$sourcePath = FILE_DROPBOX_DIRECTORY.$fileName;
		$destinationPath = FILE_UPLOAD_DIRECTORY.$objectFileName;
		
		if (!copy($sourcePath, $destinationPath)) {
			$this->alert = '<div class="error">ERROR: Failed to copy file.</div>';
			return FALSE;
		}
		
		$fileSize = filesize($destinationPath);
		$fileType = shell_exec('file -bi '.escapeshellarg($destinationPath).'');
		
		$sql = 'INSERT INTO objectFiles (
		objectFileObjectID, 
		objectFileName, 
		objectFileOriginalName, 
		objectFileDescription, 
		objectFileType, 
		objectFileSize, 
		objectFileModified, 
		objectFileAdded, 
		objectFileActive
		) VALUES (
		'.$objectID.', 
		"'.$objectFileName.'", 
		"'.$fileName.'", 
		"", 
		"'.$fileType.'", 
		"'.$fileSize.'", 
		NOW(), 
		NOW(), 
		1
		)';
		$db->dbQuery($sql);
		
		if (!unlink($sourcePath)) {
			$this->alert = '<div class="error">ERROR: The object has been assigned to the object, but the dropbox file could not be deleted.</div>';
		}
		
		$this->alert = '<div class="alert">The object has been renamed to "'.$objectFileName.'" and assigned to the object.</div>';
		return TRUE;
	}
}
?>