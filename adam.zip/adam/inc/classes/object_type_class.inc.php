<?php
class ObjectType
{

	// alert attribute
	var $alert;
	
	// form attributes
	var $objectTypeForm1;
	var $objectTypeForm2;
	var $objectTypeSelectionForm;
	
	// attributes for objectsInObjectType()
	var $totalResults;
	var $objectsInObjectType = array();
	
	// Constructor that initializes non-constant object type attributes.
	function ObjectType()
	{
		// object type form #1
		$this->objectTypeForm1 = '
		<h3>Create Object Type, Page 1</h3>
		<form action="'.$_SERVER['PHP_SELF'].'" method="post">
		<p>This form will create an object type. Qualified administrator only! Please plan ahead before attempting to create an object type.</p>
		<div class="formElement">
			<div class="inputLabel">Object Type Name, in <strong>SINGULAR</strong> form</div>
			<div class="instructionText">Be descriptive yet concise; 1 or 2 words preferable; no punctuation:</div>
			<input type="text" name="objectTypeNameSingular" '; if ($_REQUEST['objectTypeNameSingular']) $this->objectTypeForm1 .= 'value="'.prepStr($_REQUEST['objectTypeNameSingular'], 6).'"'; $this->objectTypeForm1 .= ' size="20" /></p>
		</div>
		<div class="formElement">
			<div class="inputLabel">Object Type Name, in <strong>PLURAL</strong> form</div>
			<div class="instructionText">Be descriptive yet concise; 1 or 2 words preferable; no punctuation:</div>
			<input type="text" name="objectTypeNamePlural" '; if ($_REQUEST['objectTypeNamePlural']) $this->objectTypeForm1 .= 'value="'.prepStr($_REQUEST['objectTypeNamePlural'], 6).'"'; $this->objectTypeForm1 .= ' size="20" /></p>
		</div>
		<div class="formElement">
			<div class="inputLabel">Object Type Description:</div>
			<div class="instructionText">Describe the object type and enter any further description/instruction concerning default object metadata.</div>
			<textarea name="objectTypeDescription" rows="4" cols="60" />'; if ($_REQUEST['objectTypeDescription']) $this->objectTypeForm1 .= prepStr($_REQUEST['objectTypeDescription'], 6); $this->objectTypeForm1 .= '</textarea></p>
		</div>
		<div class="rule"><br /></div>
		<h3>Default Object Element Set Descriptions</h3>
		<p>The following default object elements may need an elaborated description, a cautionary or instructive prompt, a controlled vocabulary list, or directions for filling out the field.</p>
		<div class="formElement">
			<div class="inputLabel">Title Description</div>
			<div class="instructionText">"Title" is the primary identifier of the object. A descriptive phrase may be used if there is no title. Typically, this will be a name by which the resource is formally known.</div>
			<textarea name="objectTitleDescription" rows="4" cols="60" />'; if ($_REQUEST['objectTitleDescription']) $this->objectTypeForm1 .= prepStr($_REQUEST['objectTitleDescription'], 6); $this->objectTypeForm1 .= '</textarea></p>
		</div>
		<div class="formElement">
			<div class="inputLabel">Description Description</div>
			<div class="instructionText">"Description" is an account of the content of the resource. Examples of this include, but is not limited to: an abstract, table of contents, reference to a graphical representation of content or a free-text account of the content.</div>
			<textarea name="objectDescriptionDescription" rows="4" cols="60" />'; if ($_REQUEST['objectDescriptionDescription']) $this->objectTypeForm1 .= prepStr($_REQUEST['objectDescriptionDescription'], 6); $this->objectTypeForm1 .= '</textarea></p>
		</div>
		<div class="formElement">
			<div class="inputLabel">Creator/Author Description</div>
			<div class="instructionText">"Creator/Author" is an entity primarily responsible for making the content of the resource. Examples of this include a person, an organization, or a service. Typically, the name of a Creator should be used to indicate the entity.</div>
			<textarea name="objectCreatorDescription" rows="4" cols="60" />'; if ($_REQUEST['objectCreatorDescription']) $this->objectTypeForm1 .= prepStr($_REQUEST['objectCreatorDescription'], 6); $this->objectTypeForm1 .= '</textarea></p>
		</div>
		<div class="formElement">
			<div class="inputLabel">Subject and Keywords Description</div>
			<div class="instructionText">"Subject and Keywords" is the topic of the content of the resource. Typically, this will be expressed as keywords, key phrases or classification codes that describe a topic of the resource. Recommended best practice is to select a value from a controlled vocabulary or formal classification scheme.</div>
			<textarea name="objectSubjectDescription" rows="4" cols="60" />'; if ($_REQUEST['objectSubjectDescription']) $this->objectTypeForm1 .= prepStr($_REQUEST['objectSubjectDescription'], 6); $this->objectTypeForm1 .= '</textarea></p>
		</div>
		<div class="formElement">
			<div class="inputLabel">Date Description</div>
			<div class="instructionText">Typically, "Date" will be associated with the creation or availability of the resource. Recommended best practice for encoding the date value is defined in a profile of ISO 8601 [W3CDTF] and includes (among others) dates of the form YYYY-MM-DD.</div>
			<textarea name="objectDateDescription" rows="4" cols="60" />'; if ($_REQUEST['objectDateDescription']) $this->objectTypeForm1 .= prepStr($_REQUEST['objectDateDescription'], 6); $this->objectTypeForm1 .= '</textarea></p>
		</div>
		<div class="rule"><br /></div>
		<h3>Extended Object Element Set Number</h3>
		<div class="formElement">
			<div class="inputLabel">How many extended element fields does the object type need?</div>
			<div class="instructionText">Note that title, creator/author, subject/keywords, description, date, bulk data, permission, and file upload fields will be automatically generated.</div>
			<input type="text" name="objectTypeFieldNumber" '; if ($_REQUEST['objectTypeFieldNumber']) $this->objectTypeForm1 .= 'value="'.prepStr($_REQUEST['objectTypeFieldNumber'], 6).'"'; $this->objectTypeForm1 .= ' size="3" /></p>
		</div>
		<div class="formElement">
			<input type="submit" name="submitPage1" value="continue to page two &gt;&gt;" class="genSubmit" />
		</div>
		</form>';
		
		// object type form #2
		$this->objectTypeForm2 = '
		<h3>Create Object Type, Page 2</h3>
		<form action="'.$_SERVER['PHP_SELF'].'" method="post">
		<p>(Note that title, creator/author, subject/keywords, description, date, bulk data, permission, and file upload fields will be automatically generated.)</p>';
		for ($i = 0; $i < $_REQUEST['objectTypeFieldNumber']; $i++) {
			$this->objectTypeForm2 .= '
			<div class="formElement">
				<div class="inputLabel">Extended Element Field Name</div>
				<div class="instructionText">Be descriptive yet concise; 1 or 2 words preferable; no punctuation:</div>
				<input type="text" name="objectTypeFieldNames[]" '; if ($_REQUEST['objectTypeFieldNames'][$i]) {$this->objectTypeForm2 .= 'value="'.prepStr($_REQUEST['objectTypeFieldNames'][$i], 6).'" ';} $this->objectTypeForm2 .= 'size="20" /><br />
			</div>
			<div class="formElement">
				<div class="inputLabel">Description of Field Name</div>
				<div class="instructionText">This is an elaborated description, a cautionary or instructive prompt, or directions for filling out the metadata field name, only if needed:</div>
				<textarea name="objectTypeFieldNameDescriptions[]" rows="8" cols="60">'; if ($_REQUEST['objectTypeFieldNameDescriptions'][$i]) {$this->objectTypeForm2 .= prepStr($_REQUEST['objectTypeFieldNameDescriptions'][$i], 6);} $this->objectTypeForm2 .= '</textarea><br />
			</div>
			<div class="formElement">
				Text Input<input type="radio" name="objectTypeFormElementTypes['.$i.']" value="textInput" '; if ($_REQUEST['objectTypeFormElementTypes'][$i] == 'textInput') {$this->objectTypeForm2 .= 'checked';} elseif (!$_REQUEST['objectTypeFormElementTypes'][$i]) {$this->objectTypeForm2 .= 'checked';} $this->objectTypeForm2 .= '/>
				Text Area<input type="radio" name="objectTypeFormElementTypes['.$i.']" value="textArea" '; if ($_REQUEST['objectTypeFormElementTypes'][$i] == 'textArea') {$this->objectTypeForm2 .= 'checked';} $this->objectTypeForm2 .= '/></p>
			</div>
			<div class="rule"><br /></div>';

		}
		$this->objectTypeForm2 .= '
		<div class="formElement">
			<input type="submit" name="submitPage2" value="submit new object type" class="genSubmit" /> <input type="submit" name="submitCancel" value="cancel" onclick="return confirm(\'WARNING! Are you sure you want to cancel this object type?\')" class="genSubmit" />
		</div>
		<input type="hidden" name="objectTypeNameSingular" value="'.prepStr($_REQUEST['objectTypeNameSingular'], 6).'" />
		<input type="hidden" name="objectTypeNamePlural" value="'.prepStr($_REQUEST['objectTypeNamePlural'], 6).'" />
		<input type="hidden" name="objectTypeDescription" value="'.prepStr($_REQUEST['objectTypeDescription'], 6).'" />
		<input type="hidden" name="objectTitleDescription" value="'.prepStr($_REQUEST['objectTitleDescription'], 6).'" />
		<input type="hidden" name="objectDescriptionDescription" value="'.prepStr($_REQUEST['objectDescriptionDescription'], 6).'" />
		<input type="hidden" name="objectCreatorDescription" value="'.prepStr($_REQUEST['objectCreatorDescription'], 6).'" />
		<input type="hidden" name="objectSubjectDescription" value="'.prepStr($_REQUEST['objectSubjectDescription'], 6).'" />
		<input type="hidden" name="objectDateDescription" value="'.prepStr($_REQUEST['objectDateDescription'], 6).'" />
		<input type="hidden" name="objectTypeFieldNumber" value="'.prepStr($_REQUEST['objectTypeFieldNumber'], 6).'" />
		</form>';
		
		// object type selection form in category tree
		$this->objectTypeSelectionForm = '<h3>Object Type Selection</h3>';
		$result = $this->getObjectTypes();
		if (mysql_num_rows($result)) {
			$this->objectTypeSelectionForm .= '
			<div class="formElement">
				<div class="inputLabel">Select the object type you are entering.</div>
				<select name="objectTypeID">
					<option value="">select one...'.str_repeat('&nbsp;', 60).'</option>';
			while ($row = mysql_fetch_assoc($result)) {
				$this->objectTypeSelectionForm .= '<option value="'.$row['objectTypeID'].'">'.$row['objectTypeName'].'</option>';
			}
			$this->objectTypeSelectionForm .= '
				</select>
			</div>
			<div class="formElement">
				<input type="submit" name="submitObjectType" value="select object type" class="genSubmit" />
			</div>';
		} else {
			$this->objectTypeSelectionForm .= '<p>[There are no object types in the database.]</p>';
		}
	
	}
		
	// validate objectTypeForm1
	function validateObjectTypeForm1()
	{
		global $db;
		
		// populate the attributes with relevant data
		$objectTypeNamePlural =		prepStr($_REQUEST['objectTypeNamePlural'], 2);
		$objectTypeNameSingular =	prepStr($_REQUEST['objectTypeNameSingular'], 2);
		$objectTypeDescription =	prepStr($_REQUEST['objectTypeDescription'], 2);
		$objectTypeFieldNumber =	prepStr($_REQUEST['objectTypeFieldNumber'], 2);

		// validate the form
		if (!$objectTypeNamePlural 
		|| !$objectTypeNameSingular 
		|| !is_numeric($objectTypeFieldNumber)) {
			$this->alert = '<div class="error">ERROR: All fields except description fields must be completed and in the correct format.</div>';
			return FALSE;
		}
		
		// continue validating the form
		if (!preg_match('/^[a-z1-9 ]+$/i', $objectTypeNamePlural) 
		|| !preg_match('/^[a-z1-9 ]+/i', $objectTypeNameSingular)) {
			$this->alert = '<div class="error">ERROR: Object type names must contain at least one letter or number, and may not contain punctuation.</div>';
			return FALSE;
		}
		
		// continue validating the form
		if (preg_match('/(^object$)|(^objects$)|(^objectType$)|(^object type$)/i', $objectTypeNamePlural) 
		|| preg_match('/(^object$)|(^objects$)|(^objectType$)|(^object type$)/i', $objectTypeNameSingular)) {
			$this->alert = '<div class="error">ERROR: An object type may not be named "object," "objects," "objecttype," or "object type".</div>';
			return FALSE;
		}
			
		// convert to studly caps to get table name
		$objectTypeTableName = 'objectType_'.convertToStudlyCaps($objectTypeNamePlural);
		
		// check to see if there is already an object type of the given name
		$sql = 'SELECT * 
		FROM objectTypes 
		WHERE objectTypeName = "'.$objectTypeNameSingular.'" 
		OR objectTypeName = "'.$objectTypeNamePlural.'"';
		$result1 = $db->dbQuery($sql);
		$sql = 'SELECT * 
		FROM objectTypes 
		WHERE objectTypeTableName = "'.$objectTypeTableName.'"';
		$result2 = $db->dbQuery($sql);
			
		// continue validating the form
		if (mysql_num_rows($result1) || mysql_num_rows($result2)) {
			$this->alert = '<div class="error">ERROR: There is already a object type by that name. Please try again.</div>';
			return FALSE;
		}
		
		// return true if all checks out
		return TRUE;
	}
	
	function validateObjectTypeForm2()
	{
		// validate objectTypeForm2
		
		if ($_REQUEST['objectTypeFieldNumber'] == 0) {
			return TRUE;
		}
		
		if (is_array($_REQUEST['objectTypeFieldNames']) && is_array($_REQUEST['objectTypeFormElementTypes'])) {
			foreach ($_REQUEST['objectTypeFieldNames'] as $value) {
				if (!trim($value)) {
					$this->alert = '<div class="error">ERROR: All fields must be completed, except for description.</div>';
					return FALSE;
				} elseif (!preg_match('/^[a-z1-9 ]+$/i', $value)) {
					$this->alert = '<div class="error">ERROR: Extended element field names must contain at least one letter or number, and may not contain punctuation.</div>';
					return FALSE;
				}
			}
			foreach ($_REQUEST['objectTypeFormElementTypes'] as $value) {		
				if (!trim($value)) {
					$this->alert = '<div class="error">ERROR: All fields must be completed, except for description.</div>';
					return FALSE;
				}
			}
		} else {
			$this->alert = '<div class="error">ERROR: All fields must be completed, except for description.</div>';
			return FALSE;
		}
		
		// Check to see if the object type field names are unique.
		foreach ($_REQUEST['objectTypeFieldNames'] as $objectTypeFieldName) {
			if (count(array_keys($_REQUEST['objectTypeFieldNames'], $objectTypeFieldName)) > 1) {
				$this->alert = '<div class="error">ERROR: Every field name must be unique.</div>';
				return FALSE;
			}
		}
		
		// return true if all checks out
		return TRUE;
	}

	function validateObjectTypeSelectionForm($objectTypeID)
	{
		global $db;
				
		settype($objectTypeID, 'integer');
		
		// Check to see if there is an object type ID.
		if (!$objectTypeID) {
			$this->alert = '<div class="error">ERROR: You must select an object type.</div>';
			return FALSE;
		}
		
		// First get the selected object type, if it is active.
		$sql = 'SELECT * 
		FROM objectTypes 
		WHERE objectTypeID = '.$objectTypeID.' 
		AND objectTypeActive = 1';
		$result = $db->dbQuery($sql);
		
		// Return FALSE if there is no object type by the supplied object type ID.
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There is no active object type by that ID number.</div>';
			return FALSE;
		}
				
		// return true if all checks out
		return TRUE;
	}
	
	// Generate the object type and create the specific object type table.
	function generateObjectType()
	{
		global $db;
		
		// Check to see if there is already an object type of the given name. This prevents form reload errors.
		$sql = 'SELECT * 
		FROM objectTypes 
		WHERE objectTypeName = "'.prepStr($_REQUEST['objectTypeNameSingular'], 2).'" 
		OR objectTypeName = "'.prepStr($_REQUEST['objectTypeNamePlural'], 2).'"';
		$result = $db->dbQuery($sql);
			
		// Validate the form.
		if (mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There is already a object type by that name.</div>';
			return FALSE;
		}
	
		// Populate the attributes with relevant data.
		$objectTypeFieldNames 				= $_REQUEST['objectTypeFieldNames'];
		$objectTypeFieldNameDescriptions 	= $_REQUEST['objectTypeFieldNameDescriptions'];
		$objectTypeFormElementTypes 		= $_REQUEST['objectTypeFormElementTypes'];
		$objectTypeFieldNumber 				= prepStr($_REQUEST['objectTypeFieldNumber'], 2);
		$objectTypeNamePlural 				= prepStr($_REQUEST['objectTypeNamePlural'], 2);
		$objectTypeNameSingular 			= prepStr($_REQUEST['objectTypeNameSingular'], 2);
		$objectTypeDescription 				= prepStr($_REQUEST['objectTypeDescription'], 2);
		$objectTitleDescription 			= prepStr($_REQUEST['objectTitleDescription'], 2);
		$objectDescriptionDescription 		= prepStr($_REQUEST['objectDescriptionDescription'], 2);
		$objectCreatorDescription 			= prepStr($_REQUEST['objectCreatorDescription'], 2);
		$objectSubjectDescription 			= prepStr($_REQUEST['objectSubjectDescription'], 2);
		$objectDateDescription 				= prepStr($_REQUEST['objectDateDescription'], 2);

		// Convert to studly caps to get table name.
		$objectTypeTableName = 'objectType_'.convertToStudlyCaps($objectTypeNamePlural);
		
		// Dump the field names and field name descriptions into the objectTypes table.
		// This will be serialized for object storage and unserialized for object display.
		for ($i = 0; $i < $objectTypeFieldNumber; $i++) {
			$metadataDump[] = array(
								prepStr($objectTypeFieldNames[$i], 2), 
								prepStr($objectTypeFieldNameDescriptions[$i], 2), 
								prepStr($objectTypeFormElementTypes[$i], 2)
								);
		}
		$metadataDump = serialize($metadataDump);
		
		// Generate the object type.
		$sql = 'INSERT INTO objectTypes (
		objectTypeName, 
		objectTypeTableName, 
		objectTypeDescription, 
		objectTypeMetadataDump, 
		objectTitleDescription, 
		objectDescriptionDescription, 
		objectCreatorDescription, 
		objectSubjectDescription, 
		objectDateDescription, 
		objectTypeActive
		) VALUES (
		"'.$objectTypeNameSingular.'", 
		"'.$objectTypeTableName.'", 
		"'.$objectTypeDescription.'", 
		"'.addslashes($metadataDump).'", 
		"'.$objectTitleDescription.'", 
		"'.$objectDescriptionDescription.'", 
		"'.$objectCreatorDescription.'", 
		"'.$objectSubjectDescription.'", 
		"'.$objectDateDescription.'", 
		1
		)';
		$db->dbQuery($sql);

		// Create the object type table.
		$objectType = convertToStudlyCaps($objectTypeNameSingular);
		
		$sql = 'CREATE TABLE objectType_'.convertToStudlyCaps($objectTypeNamePlural).' (
		'.$objectType.'ID INT(11) NOT NULL AUTO_INCREMENT, 
		objectID INT(11) NOT NULL, 
		objectTypeID INT(11) NOT NULL, ';
		for ($i = 0; $i < $objectTypeFieldNumber; $i++) {
			$sql .= $objectType.convertToStudlyCaps($objectTypeFieldNames[$i], TRUE).' TEXT, ';
		}
		$sql .= 'PRIMARY KEY ('.$objectType.'ID))';
		$db->dbQuery($sql);

		$this->alert = '<div class="alert">SUCCESS! The object type was successfully created.</div>';
		return TRUE;
	}
	
	// This function is generalized in order to allow extensibility.
	function getObjectTypeForm($objectTypeID)
	{
		global $db;
				
		// First get the selected object type, if it is active.
		$sql = 'SELECT * 
		FROM objectTypes 
		WHERE objectTypeID = '.$objectTypeID.' 
		AND objectTypeActive = 1';
		$result = $db->dbQuery($sql);
		$rowObjectType = mysql_fetch_assoc($result);
		
			// Unserialize the objectTypeMetadataDump.
			$objectTypeMetadataDump = unserialize($rowObjectType['objectTypeMetadataDump']);
	
			// Get the data type of the input fields. This is to determine the input types.
			$sql = 'DESCRIBE '.$rowObjectType['objectTypeTableName'];
			$result = $db->dbQuery($sql);
			while ($rowObjectTypeMetadata = mysql_fetch_assoc($result)) {
				$objectDataTypeMetadata[] = $rowObjectTypeMetadata;
			}
			
			// Note that the text is left aligned so the text appears cleaner in the rendered template.
			$str = '
<!-- Begin form elements. -->
<h3>Object Type: '.prepStr($rowObjectType['objectTypeName'], 4).'</h3>
<p>'.nl2br(prepStr($rowObjectType['objectTypeDescription'], 4)).'</p>
<div class="rule"><br /></div>
<h4>Default Metadata</h4>
<div class="formElement">
	<div class="inputLabel">Permission Level:</div> 
	<select name="objectPermissionID">';
	$result = getPermissions();
	while ($row = mysql_fetch_assoc($result)) {
		// PROTECTED ACCESS
		// Skip the administrator permission if user is a researcher.
		if ($row['permissionID'] < USER_ACCESS_LEVEL) {
			continue;
		}
			$str .='<option value="'.$row['permissionID'].'">'.$row['permissionName'].'</option>';
	}
	$str .= ' 
	</select>
</div>
<div class="formElement">
	<div class="inputLabel">Title or short description:</div>
	<div class="instructionText">'.prepStr($rowObjectType['objectTitleDescription'], 4).'</div>
	<textarea name="objectTitle" rows="1" cols="60"></textarea>
</div>
<div class="formElement">
	<div class="inputLabel">Description:</div>
	<div class="instructionText">'.prepStr($rowObjectType['objectDescriptionDescription'], 4).'</div>
	<textarea name="objectDescription" rows="8" cols="60"></textarea>
</div>
<div class="formElement">
	<div class="inputLabel">Creator/Author:</div>
	<div class="instructionText">'.prepStr($rowObjectType['objectCreatorDescription'], 4).'</div>
	<textarea name="objectCreator" rows="1" cols="60"></textarea>
</div>
<div class="formElement">
	<div class="inputLabel">Subject and Keywords:</div>
	<div class="instructionText">'.prepStr($rowObjectType['objectSubjectDescription'], 4).'</div>
	<textarea name="objectSubject" rows="1" cols="60"></textarea>
</div>
<div class="formElement">
	<div class="inputLabel">Date:</div>
	<div class="instructionText">'.prepStr($rowObjectType['objectDateDescription'], 4).'</div>
	<textarea name="objectDate" rows="1" cols="60"></textarea>
</div>
<div class="formElement">
	<div class="inputLabel">Raw data:</div>
	<div class="instructionText">Cut and paste any and all text data from the object into this box (if possible). Additionally, insert all user-defined extended metadata into this box:</div> 
	<textarea name="objectData" rows="8" cols="60"></textarea>
</div>
<div class="rule"><br /></div>';
	
	// Begin the extended element set, if any.
	if (is_array($objectTypeMetadataDump)) {
		$str .= '
<h4>Extended Metadata</h4>';
		// Iteration starts at 0 for one reason:
		// 1) Must begin retrieving metadata dump at objectTypeMetadataDump[0]
		$i = 0;
		foreach ($objectTypeMetadataDump as $key => $value) {
			// Follow this rule: objectTypeFieldName = [$i][0]; objectTypeFieldNameDescription = [$i][1]
			$str .= '
<div class="formElement">
	<div class="inputLabel">'.prepStr($objectTypeMetadataDump[$i][0], 4).':</div>';
			if ($objectTypeMetadataDump[$i][1]) {
				$str .= '
	<div class="instructionText">'.prepStr($objectTypeMetadataDump[$i][1], 4).'</div>';
			}
			switch ($objectTypeMetadataDump[$i][2]) {
				case 'textInput':
					$str .= '<input name="'.$objectDataTypeMetadata[$i + 3]['Field'].'" size="60" />';
					break;
				case 'textArea':
					$str .= '<textarea name="'.$objectDataTypeMetadata[$i + 3]['Field'].'" rows="8" cols="60"></textarea>';
					break;
			}
			$str .= '
</div>';
			$i++;
		}

		$str .= '
<div class="rule"><br /></div>';
	}
	
$str .= '
<h4>File Upload</h4>';
		for ($i = 1; $i <= MAX_FILE_UPLOAD; $i++) {
			$str .= '
<div class="formElement">
	<div class="inputLabel">Upload File:</div> 
	<div class="instructionText">Total upload size of all files should NOT exceed 6.0 megabytes.</div>
	<input type="file" name="'.$i.'" size="60" />
</div>
<div class="formElement">
	<div class="inputLabel">Describe File:</div> 
	<textarea name="objectFileDescription['.$i.']" rows="4" cols="60"></textarea>
</div>';
		}
		$str .= '
<div class="formElement">
	<input type="submit" name="submitObject" value="submit object" class="genSubmit" /><input type="submit" name="" value="cancel" class="genSubmit" />
</div>
<input type="hidden" name="objectTypeID" value="'.$objectTypeID.'" />
<!-- End form elements. -->';
		
		return $str;
	}
		
	// This function deactivates an object type and all its assigned objects
	function deactivateObjectType($objectTypeID)
	{
		global $db;
		
		settype($objectTypeID, 'integer');
		
		// First check to see if an object type exists by that ID.
		$sql = 'SELECT * 
		FROM objectTypes 
		WHERE objectTypeID = '.$objectTypeID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There are no object types by that ID.</div>';
			return FALSE;
		}
		
		// Then deactivate the selected object type.
		$sql = 'UPDATE objectTypes 
		SET objectTypeActive = 0 
		WHERE objectTypeID = '.$objectTypeID.'';
		$db->dbQuery($sql);
				
		$this->alert = '<div class="alert">The object type has been deactivated.</div>';
		return TRUE;
	}

	// This function deactivates an object type and all its assigned objects
	function activateObjectType($objectTypeID)
	{
		global $db;
		
		settype($objectTypeID, 'integer');

		// First check to see if an object type exists by that ID.
		$sql = 'SELECT * 
		FROM objectTypes 
		WHERE objectTypeID = '.$objectTypeID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There are no object types by that ID.</div>';
			return FALSE;
		}
		
		// Then deactivate the selected object type.
		$sql = 'UPDATE objectTypes 
		SET objectTypeActive = 1 
		WHERE objectTypeID = '.$objectTypeID.'';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">The object type has been re-activated.</div>';
		return TRUE;
	}
	
	
	// This function returns all object types or one object type.
	function getObjectTypes($objectTypeID = FALSE)
	{
		global $db;
		
		settype($objectTypeID, 'integer');
		
		// Select one particular object type.
		if ($objectTypeID) {
			if (USER_ACCESS_LEVEL <= 10) {
				$sql = 'SELECT * 
				FROM objectTypes
				WHERE objectTypeID = '.$objectTypeID.'';
			} elseif (USER_ACCESS_LEVEL <= 20) {
				$sql = 'SELECT * 
				FROM objectTypes
				WHERE objectTypeID = '.$objectTypeID.' 
				AND objectTypeActive = 1';
			} elseif (USER_ACCESS_LEVEL <= 30) {
				$sql = 'SELECT * 
				FROM objectTypes
				WHERE objectTypeID = '.$objectTypeID.' 
				AND objectTypeActive = 1';
			}
					
		// Else select all object types.
		} else {
			if (USER_ACCESS_LEVEL <= 10) {
				$sql = 'SELECT * 
				FROM objectTypes 
				ORDER BY objectTypeActive DESC, objectTypeName';
			} elseif (USER_ACCESS_LEVEL <= 20) {
				$sql = 'SELECT * 
				FROM objectTypes 
				WHERE objectTypeActive = 1 
				ORDER BY objectTypeName';
			} elseif (USER_ACCESS_LEVEL <= 30) {
				$sql = 'SELECT * 
				FROM objectTypes 
				WHERE objectTypeActive = 1 
				ORDER BY objectTypeName';
			}
		}
			
		$result = $db->dbQuery($sql);
		
		return $result;
	}
	
	// This function returns all object IDs in the object type/
	function getObjectsInObjectType($objectTypeID, $page)
	{
		global $db;
		
		settype($objectTypeID, 'integer');
		
		$sql = 'SELECT * 
		FROM objectTypes 
		WHERE objectTypeID = '.$objectTypeID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: The objectType ID is invalid.</div>';
			return FALSE;
		}

		if (USER_ACCESS_LEVEL <= 1) {
			$sql = 'SELECT * 
			FROM objects, objectTypes 
			WHERE objects.objectTypeID = objectTypes.objectTypeID 
			AND objectTypes.objectTypeID = '.$objectTypeID.'';
			$resultTotal = $db->dbQuery($sql);
			
			$sql = 'SELECT * 
			FROM objects, objectTypes, permissions 
			WHERE objects.objectTypeID = objectTypes.objectTypeID 
			AND objects.objectPermissionID = permissions.permissionID 
			AND objectTypes.objectTypeID = '.$objectTypeID.' 
			ORDER BY objects.objectActive DESC, 
			objectTypes.objectTypeActive DESC, 
			objects.objectTitle 
			LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';			
		} elseif (USER_ACCESS_LEVEL <= 10) {
			$sql = 'SELECT * 
			FROM objects, objectTypes 
			WHERE objects.objectTypeID = objectTypes.objectTypeID 
			AND objectTypes.objectTypeID = '.$objectTypeID.' 
			AND objects.objectPermissionID >= 10';
			$resultTotal = $db->dbQuery($sql);
			
			$sql = 'SELECT * 
			FROM objects, objectTypes, permissions 
			WHERE objects.objectTypeID = objectTypes.objectTypeID 
			AND objects.objectPermissionID = permissions.permissionID 
			AND objectTypes.objectTypeID = '.$objectTypeID.' 
			AND objects.objectPermissionID >= 10 
			ORDER BY objects.objectActive DESC, 
			objectTypes.objectTypeActive DESC, 
			objects.objectTitle 
			LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';			
		} elseif (USER_ACCESS_LEVEL <= 20) {
			$sql = 'SELECT * 
			FROM objects, objectTypes 
			WHERE objects.objectTypeID = objectTypes.objectTypeID 
			AND objectTypes.objectTypeID = '.$objectTypeID.' 
			AND objectTypes.objectTypeActive = 1 
			AND objects.objectActive = 1 
			AND objects.objectPermissionID >= 20';
			$resultTotal = $db->dbQuery($sql);
			
			$sql = 'SELECT * 
			FROM objects, objectTypes, permissions 
			WHERE objects.objectTypeID = objectTypes.objectTypeID 
			AND objects.objectPermissionID = permissions.permissionID 
			AND objectTypes.objectTypeID = '.$objectTypeID.' 
			AND objectTypes.objectTypeActive = 1 
			AND objects.objectActive = 1 
			AND objects.objectPermissionID >= 20 
			ORDER BY objects.objectTitle
			LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';			
		} elseif (USER_ACCESS_LEVEL <= 30) {
			$sql = 'SELECT * 
			FROM objects, objectTypes 
			WHERE objects.objectTypeID = objectTypes.objectTypeID 
			AND objectTypes.objectTypeID = '.$objectTypeID.' 
			AND objectTypes.objectTypeActive = 1 
			AND objects.objectActive = 1 
			AND objects.objectPermissionID >= 30';
			$resultTotal = $db->dbQuery($sql);
			
			$sql = 'SELECT * 
			FROM objects, objectTypes 
			WHERE objects.objectTypeID = objectTypes.objectTypeID 
			AND objectTypes.objectTypeID = '.$objectTypeID.' 
			AND objectTypes.objectTypeActive = 1 
			AND objects.objectActive = 1 
			AND objects.objectPermissionID >= 30 
			ORDER BY objects.objectTitle 
			LIMIT '.(($page - 1) * MAX_UNITS_PER_PAGE).', '.MAX_UNITS_PER_PAGE.'';			
		}
		$this->totalResults = mysql_num_rows($resultTotal);
		$result = $db->dbQuery($sql);
		while ($row = mysql_fetch_assoc($result)) {
			$this->objectsInObjectType[] = $row;
		}
		return TRUE;
	}
	
	function deleteElement($objectTypeID, $element)
	{
		global $db;

		settype($objectTypeID, 'integer');
		
		if (is_nan($element)) {
			$this->alert = '<div class="error">ERROR: The element is invalid.</div>';
			return FALSE;
		}
		
		$sql = 'SELECT * 
		FROM objectTypes 
		WHERE objectTypeID = '.$objectTypeID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There is no object type by that ID.</div>';
			return FALSE;
		}
		$row = mysql_fetch_assoc($result);
		
		$metadataDumpArray = unserialize($row['objectTypeMetadataDump']);
		
		if (!is_array($metadataDumpArray)) {
			$this->alert = '<div class="error">ERROR: There are no extended elements in the given object type.</div>';
			return FALSE;
		}
	
		$deletedElementName = $metadataDumpArray[$element - 1][0];
		array_splice($metadataDumpArray, ($element - 1), 1);
		
		// If no extended element exists in resulting array, delete it.
		if (empty($metadataDumpArray)) {
			$metadataDump = '';
		} else {
			$metadataDump = serialize($metadataDumpArray);
		}
		
		$sql = 'UPDATE objectTypes 
		SET objectTypeMetadataDump = "'.addslashes($metadataDump).'" 
		WHERE objectTypeID = '.$objectTypeID.'';
		$db->dbQuery($sql);
				
		$sql = 'ALTER TABLE '.$row['objectTypeTableName'].' 
		DROP '.convertToStudlyCaps($row['objectTypeName']).convertToStudlyCaps($deletedElementName, TRUE).'';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">The object type element was successfully deleted.</div>';
		return TRUE;
	}
	
	function addElement($objectTypeID)
	{
		global $db;
		
		$objectTypeFieldName 				= prepStr($_REQUEST['objectTypeFieldName'], 2);
		$objectTypeFieldNameDescription 	= prepStr($_REQUEST['objectTypeFieldNameDescription'], 2);
		$objectTypeFormElementType 			= prepStr($_REQUEST['objectTypeFormElementType'], 2);
		
		if (!$objectTypeFieldName) {
			$this->alert = '<div class="error">ERROR: All fields must be completed, except for description.</div>';
			return FALSE;
		}
		
		settype($objectTypeID, 'integer');
		
		$sql = 'SELECT * 
		FROM objectTypes 
		WHERE objectTypeID = '.$objectTypeID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There is no object type by that ID.</div>';
			return FALSE;
		}
		$row = mysql_fetch_assoc($result);
		$metadataDumpArray = unserialize($row['objectTypeMetadataDump']);
		
		if (!is_array($metadataDumpArray)) {
			$metadataDumpArray = array();
		}
		
		$metadataDumpArray[] = array($objectTypeFieldName, $objectTypeFieldNameDescription, $objectTypeFormElementType); 
		$metadataDump = serialize($metadataDumpArray);
		$sql = 'UPDATE objectTypes 
		SET objectTypeMetadataDump = "'.addslashes($metadataDump).'" 
		WHERE objectTypeID = '.$objectTypeID.'';
		$db->dbQuery($sql);
		
		$sql = 'ALTER TABLE '.$row['objectTypeTableName'].' 
		ADD '.convertToStudlyCaps($row['objectTypeName']).convertToStudlyCaps($objectTypeFieldName, TRUE).' TEXT';
		$db->dbQuery($sql);		
		
		$this->alert = '<div class="alert">The object type element was successfully added.</div>';
		return TRUE;
	}
	
	function editDefaultElementSet($objectTypeID)
	{
		global $db;
		
		settype($objectTypeID, 'integer');
		
		$objectTitleDescription 		= prepStr($_REQUEST['objectTitleDescription'], 2);
		$objectDescriptionDescription 	= prepStr($_REQUEST['objectDescriptionDescription'], 2);
		$objectCreatorDescription 		= prepStr($_REQUEST['objectCreatorDescription'], 2);
		$objectSubjectDescription 		= prepStr($_REQUEST['objectSubjectDescription'], 2);
		$objectDateDescription 			= prepStr($_REQUEST['objectDateDescription'], 2);
		
		$sql = 'SELECT * 
		FROM objectTypes 
		WHERE objectTypeID = '.$objectTypeID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There is no object type by that ID.</div>';
			return FALSE;
		}
		
		$sql = 'UPDATE objectTypes 
		SET objectTitleDescription = "'.$objectTitleDescription.'", 
		objectDescriptionDescription = "'.$objectDescriptionDescription.'", 
		objectCreatorDescription = "'.$objectCreatorDescription.'", 
		objectSubjectDescription = "'.$objectSubjectDescription.'", 
		objectDateDescription = "'.$objectDateDescription.'" 
		WHERE objectTypeID = '.$objectTypeID.'';
		$db->dbQuery($sql);
		
		$this->alert = '<div class="alert">The default element set has been successfully edited.</div>';

	}
	
	function editExtendedElementSet($objectTypeID)
	{
		global $db;
		
		settype($objectTypeID, 'integer');
		
		$sql = 'SELECT * 
		FROM objectTypes 
		WHERE objectTypeID = '.$objectTypeID.'';
		$result = $db->dbQuery($sql);
		
		if (!mysql_num_rows($result)) {
			$this->alert = '<div class="error">ERROR: There is no object type by that ID.</div>';
			return FALSE;
		}
		
		$row = mysql_fetch_assoc($result);
		$metadataDumpArray = unserialize($row['objectTypeMetadataDump']);
		
		$i = 1;
		foreach ($metadataDumpArray as $extendedElement) {
			// Editing extended metadata names will be difficult, as it requires a table ALTER, strict string handling, etc.
			/*
			if ($metadataDumpArray[$i - 1][0] != $_POST['name'][$i - 1]) {
				$metadataDumpArray[$i - 1][0] = prepStr($_POST['name'][$i - 1], 2);
			}
			*/
			if ($metadataDumpArray[$i - 1][1] != $_POST['description'][$i - 1]) {
				$metadataDumpArray[$i - 1][1] = prepStr($_POST['description'][$i - 1], 2);
			}
			$i++;
		}
		
		$metadataDump = serialize($metadataDumpArray);
		$sql = 'UPDATE objectTypes 
		SET objectTypeMetadataDump = "'.addslashes($metadataDump).'" 
		WHERE objectTypeID = '.$objectTypeID.'';
		$db->dbQuery($sql);		
		
		$this->alert = '<div class="alert">The extended element set has been successfully edited.</div>';
	}
}
?>