<?php
// THIS PAGE IS USED FOR TEST SCRIPTS IN ADAM'S CONTEXT.
// PLEASE DELETE TEST SCRIPTS WHEN FINISHED.

// Require the congiguration/database connect script. DO NOT DELETE!
require_once('inc/config.inc.php');

if (USER_ACCESS_LEVEL <= 1) {
echo '<p>[<a href="'.WEBSITE_URL.'">return to website</a>]</p>';
// BEGIN TEST SCRIPTS HERE.
?>


<?php
// END TEST SCRIPTS HERE.
} else {
	echo '
	<p>You must be logged in to access this page.</p>
	<p>[<a href="'.WEBSITE_URL.'">return to website</a>]</p>';
}
?>