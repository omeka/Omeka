-- phpMyAdmin SQL Dump
-- version 2.8.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 11, 2006 at 09:55 PM
-- Server version: 5.0.22
-- PHP Version: 5.1.4
-- 
-- Database: `jwa`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `categories_metafields`
-- 

CREATE TABLE `categories_metafields` (
  `category_id` int(11) unsigned NOT NULL,
  `metafield_id` int(11) unsigned NOT NULL,
  KEY `category_id` (`category_id`),
  KEY `metafield_id` (`metafield_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `categories_metafields`
-- 

INSERT INTO `categories_metafields` (`category_id`, `metafield_id`) VALUES (2, 2),
(2, 3),
(2, 4),
(3, 5),
(4, 6),
(4, 7),
(4, 8),
(4, 9),
(4, 10),
(4, 11),
(4, 12),
(5, 13),
(6, 14),
(6, 15),
(6, 16),
(6, 17),
(6, 18),
(8, 5),
(9, 19),
(9, 20),
(9, 21),
(9, 22),
(9, 23),
(9, 24),
(9, 25),
(10, 26),
(10, 27),
(10, 24),
(10, 25),
(11, 28),
(11, 25),
(11, 29),
(11, 30),
(12, 31),
(13, 32);

-- 
-- Constraints for dumped tables
-- 

-- 
-- Constraints for table `categories_metafields`
-- 
ALTER TABLE `categories_metafields`
  ADD CONSTRAINT `categories_metafields_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `categories_metafields_ibfk_2` FOREIGN KEY (`metafield_id`) REFERENCES `metafields` (`metafield_id`) ON DELETE CASCADE ON UPDATE CASCADE;
