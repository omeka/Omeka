-- phpMyAdmin SQL Dump
-- version 2.8.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 11, 2006 at 09:55 PM
-- Server version: 5.0.22
-- PHP Version: 5.1.4
-- 
-- Database: `jwa`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `metafields`
-- 

CREATE TABLE `metafields` (
  `metafield_id` int(11) unsigned NOT NULL auto_increment,
  `metafield_name` varchar(100) NOT NULL,
  `metafield_description` text NOT NULL,
  PRIMARY KEY  (`metafield_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

-- 
-- Dumping data for table `metafields`
-- 

INSERT INTO `metafields` (`metafield_id`, `metafield_name`, `metafield_description`) VALUES (2, 'Body', 'The main body of the blog post.'),
(3, 'Comments', 'Any comments made in response to the blog post, including the date.'),
(4, 'Trackbacks', 'A list of all blog postings that have referenced this blog post.'),
(5, 'Text', 'Any textual data included in the document.'),
(6, 'Email Body', 'The main body of the email, including all replied and forwarded text and headers.'),
(7, 'Subject Line', 'The content of the subject line of the email.'),
(8, 'From', 'The name and email address of the person sending the email.'),
(9, 'To', 'The name(s) and email address(es) of the person to whom the email was sent.'),
(10, 'Cc', 'The name(s) and email address(es) of the person to whom the email was carbon copied.'),
(11, 'Bcc', 'The name(s) and email address(es) of the person to whom the email was blind carbon copied.'),
(12, 'Number of Attachments', 'The number of attachments to the email.'),
(13, 'Interactive Resource Duration', 'The length in time of the interactive resource.'),
(14, 'Moving Image Duration', 'The lentgh of time of the moving image.'),
(15, 'Moving Image Resolution', 'The resolution of the moving image determined by pixel dimensions, pixels per inch or dots per inch.'),
(16, 'Moving Image Bit Depth', 'The bit depth of the moving image.'),
(17, 'Moving Image Width', 'The width of the moving image at full size.'),
(18, 'Moving Image Height', 'The height of the moving image at full size.'),
(19, 'Oral History Transcription', 'Any written text transcribed from or during the interview.'),
(20, 'Interviewer', 'The person(s) performing the interview.'),
(21, 'Interviewee', 'The person(s) being interviewed.'),
(22, 'Location', 'The location of the interview.'),
(23, 'Oral History Duration', 'The length of time of the interview.'),
(24, 'Sample Rate', 'The number of samples recorded per second.  Sample rates are measured in Hz or kHz.'),
(25, 'Bit Depth', 'The number of bits used to represent each sample in an audio file, determining the accuracy of the sample.'),
(26, 'Sound Transcription', 'Any written text transcribed from the sound.'),
(27, 'Sound Duration', 'The length of time of the sound.'),
(28, 'Resolution', 'The resolution of the still image'),
(29, 'Still Image Width', 'The width of the still image at full size.'),
(30, 'Still Image Height', 'The height of the still image at full size.'),
(31, 'HTML', 'The hypertext markup language used for building the web page.'),
(32, 'Local URL', 'The URL of the local directory containing all assets of the website.');
