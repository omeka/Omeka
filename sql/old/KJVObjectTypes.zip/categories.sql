-- phpMyAdmin SQL Dump
-- version 2.8.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 11, 2006 at 09:55 PM
-- Server version: 5.0.22
-- PHP Version: 5.1.4
-- 
-- Database: `jwa`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `categories`
-- 

CREATE TABLE `categories` (
  `category_id` int(11) unsigned NOT NULL auto_increment,
  `category_parent_id` int(11) unsigned default NULL,
  `category_name` tinytext NOT NULL,
  `category_description` text NOT NULL,
  `category_active` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

-- 
-- Dumping data for table `categories`
-- 

INSERT INTO `categories` (`category_id`, `category_parent_id`, `category_name`, `category_description`, `category_active`) VALUES (2, NULL, 'Blog', 'A resource containing frequent and chronological comments and throughts published on the web.', 1),
(3, NULL, 'Document', 'A resource containing textual data.  Note that facsimiles or images of texts are still of the genre text.', 1),
(4, NULL, 'Email', 'A resource containing textual messages and binary attachments sent electronically from one person to another or one person to many people.', 1),
(5, NULL, 'Interactive Resource', 'A resource which requires interaction from the user to be understood, executed, or experienced.', 1),
(6, NULL, 'Moving Image', 'A series of visual representations that, when shown in succession, impart an impression of motion.', 1),
(7, NULL, 'Online File', 'A file and accompanying metadata contributed to JWA through the KJV contribution form.', 1),
(8, NULL, 'Online Text', 'A story, email, blog, or any other textual data contributed to JWA through the KJV contribution form.', 1),
(9, NULL, 'Oral History', 'A resource containing historical information obtained in interviews with persons having firsthand knowledge.', 1),
(10, NULL, 'Sound', 'A resource whose content is primarily intended to be rendered as audio.', 1),
(11, NULL, 'Still Image', 'A static visual representation. Examples of still images are: paintings, drawings, graphic designs, plans and maps.  Recommended best practice is to assign the type "text" to images of textual materials.', 1),
(12, NULL, 'Web Page', 'A resource intended for publication on the World Wide Web using hypertext markup language.', 1),
(13, NULL, 'Website', 'A resource comprising of a web page or web pages and all related assets ( such as images, sound and video files, etc. ).', 1);
